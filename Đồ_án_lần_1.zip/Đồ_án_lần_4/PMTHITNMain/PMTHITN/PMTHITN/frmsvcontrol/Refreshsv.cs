﻿using PMTHITN.Class;
using PMTHITN.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMTHITN.frmsvcontrol
{
    internal class Refreshsv
    {
        private string type;
        private DatabaseHelper dbHelper; // Giả sử bạn có một lớp DatabaseHelper để xử lý truy vấn

        public Refreshsv(string type, DatabaseHelper dbHelper)
        {
            this.type = type;
            this.dbHelper = dbHelper;
        }

        public void ExecuteRefreshsv(DataGridView dgvdiemdanhsv, DataGridView dgvphanhoisv, string type,
            TextBox txtmaphien,
            TextBox txttenlopsv,
            TextBox txttenmonsv,
            TextBox txtngaytaophien,
            TextBox txtsolan,
            TextBox txttrangthai,

            TextBox txtmssv_phanhoisv,
            TextBox txthodem_phanhoisv,
            TextBox txtten_phanhoisv,
            TextBox txtlop_phanhoisv,
            TextBox txtmon_phanhoisv,
            TextBox txtngay_phanhoisv,
            RichTextBox txtnoidung_phanhoisv)
        {
            // Làm sạch các TextBox
            txtmaphien.Clear();
            txttenlopsv.Clear();
            txttenmonsv.Clear();
            txtngaytaophien.Clear();
            txtsolan.Clear();
            txttrangthai.Clear();

            txtmssv_phanhoisv.Clear();
            txthodem_phanhoisv.Clear();
            txtten_phanhoisv.Clear();
            txtlop_phanhoisv.Clear();
            txtmon_phanhoisv.Clear();
            txtngay_phanhoisv.Clear();
            txtnoidung_phanhoisv.Clear();


            string sql = string.Empty; // Khởi tạo biến sql

            // Xác định câu truy vấn SQL dựa trên loại dữ liệu
            switch (type)
            {
                case "DiemDanhsv":
                    sql = @" SELECT 
                        pdd.ID_phien AS[ID],
                        gv.Hodem AS[Họ đệm giảng viên],
                        gv.Ten AS[Tên giảng viên],
                        l.TenL AS[Tên lớp],
                mh.Tenmonhoc AS [Tên môn học],
                pdd.Ngay AS [Ngày], 
                pdd.Gio_batdau AS [Thời gian bắt đầu], 
                pdd.Gio_ketthuc AS [Thời gian kết thúc],
                pdd.SoLan AS [Lần],
                pdd.Trangthai AS [Trạng thái]
            FROM 
                PHIENDIEMDANH pdd
            JOIN
                GV gv ON pdd.ID_gv = gv.ID_gv
            JOIN 
                LOP l ON pdd.MaL = l.MaL
            JOIN 
                MONHOC mh ON pdd.MaMH = mh.MaMH
            ORDER BY 
                pdd.Ngay DESC";
                    dbHelper.LoadDuLieu(sql, dgvdiemdanhsv); // Tải dữ liệu vào dgvmenu
                    break;


                case "MonThi":
                    sql = @"
        SELECT 
            MaM AS 'Mã Môn', 
            Tenmon AS 'Tên Môn', 
            Socau AS 'Số Câu', 
            TGlambai AS 'Thời Gian Làm Bài', 
            Thoigianthi AS 'Ngày Thi' 
        FROM 
            MONTHI";
                    dbHelper.LoadDuLieu(sql, dgvdiemdanhsv); // Tải dữ liệu vào dgvmenu
                    break;

                case "Phanhoisv":
                    // Kiểm tra giá trị của thongtinsv.MSV
                    if (string.IsNullOrWhiteSpace(thongtinsv.MSV))
                    {
                        MessageBox.Show("Không tìm thấy Mã sinh viên! Vui lòng kiểm tra lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Ghi log hoặc hiển thị giá trị của thongtinsv.MSV
                    Console.WriteLine($"Mã SV: {thongtinsv.MSV}");

                    // Tạo câu lệnh SQL với tham số @MaSV
                    sql = @" SELECT 
            pdd.ID_phien AS[ID],
            gv.Hodem AS[Họ đệm giảng viên],
            gv.Ten AS[Tên giảng viên],
            l.TenL AS[Tên lớp],
            mh.Tenmonhoc AS [Tên môn học],
            pdd.Ngay AS [Ngày], 
            pdd.Gio_batdau AS [Thời gian bắt đầu], 
            pdd.Gio_ketthuc AS [Thời gian kết thúc],
            pdd.SoLan AS [Lần],
            pdd.Trangthai AS [Trạng thái]
        FROM 
            PHIENDIEMDANH pdd
        JOIN
            GV gv ON pdd.ID_gv = gv.ID_gv
        JOIN 
            LOP l ON pdd.MaL = l.MaL
        JOIN 
            MONHOC mh ON pdd.MaMH = mh.MaMH
        ORDER BY 
            pdd.Ngay DESC"; // Truy vấn cho bảng phản hồi

                    // Sử dụng SqlParameter để truyền @MaSV vào câu lệnh SQL
                    SqlParameter[] parameters = new SqlParameter[]
                    {
        new SqlParameter("@MaSV", thongtinsv.MSV)
                    };

                    // Tải dữ liệu vào dgvphanhoisv
                    dbHelper.LoadDuLieu(sql, dgvphanhoisv, parameters);
                    break;

                default:
                    MessageBox.Show("Loại dữ liệu không hợp lệ."); // Xử lý trường hợp không hợp lệ
                    return;
            }

        }
    }

}
