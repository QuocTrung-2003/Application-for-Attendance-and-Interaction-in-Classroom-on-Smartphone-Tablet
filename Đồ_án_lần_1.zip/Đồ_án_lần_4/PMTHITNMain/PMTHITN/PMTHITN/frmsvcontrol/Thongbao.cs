﻿using PMTHITN.Class;
using PMTHITN.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PMTHITN.frmsvcontrol
{
    internal class Thongbao
    {
        private DatabaseHelper databaseHelper;
        private NotifyIcon notifyIcon;
        private HashSet<string> displayedNotifications; // Lưu trữ các thông báo đã hiển thị

        public Thongbao(DatabaseHelper dbHelper, NotifyIcon notifyIcon)
        {
            this.databaseHelper = dbHelper;
            this.notifyIcon = notifyIcon;
            displayedNotifications = new HashSet<string>(); // Khởi tạo danh sách thông báo đã hiển thị
        }

        // Hàm kiểm tra thông báo mới
        public void KiemTraThongBaoMoi(string maSV)
        {
            List<string> thongBaoMoi = LayThongBaoMoi(maSV);

            foreach (var thongBao in thongBaoMoi)
            {
                // Nếu thông báo chưa được hiển thị, hiển thị nó
                if (!displayedNotifications.Contains(thongBao))
                {
                    notifyIcon.BalloonTipText = thongBao;
                    notifyIcon.ShowBalloonTip(5000); // Hiển thị tự động trong 5 giây
                    displayedNotifications.Add(thongBao); // Đánh dấu thông báo đã được hiển thị
                }
            }
        }

        // Lấy danh sách các thông báo mới dựa theo MaSV
        private List<string> LayThongBaoMoi(string maSV)
        {
            List<string> thongBaoMoi = new List<string>();
            string sql = "SELECT Noidung FROM THONGBAO WHERE MaSV = @MaSV AND Ngaytao < @CurrentDate";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@MaSV", maSV),
                new SqlParameter("@CurrentDate", DateTime.Now)
            };

            DataTable dt = databaseHelper.ExecuteQuery(sql, parameters); // Gọi hàm ExecuteQuery từ DatabaseHelper
            foreach (DataRow row in dt.Rows)
            {
                thongBaoMoi.Add(row["Noidung"].ToString());
            }

            return thongBaoMoi;
        }
    }
}
