﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMTHITN.frmsvcontrol
{
    internal class Hidebtnsv
    {
        public void SetControlVisibilityAndEnablementsv(Panel panelcauhoi, Panel panel5,

            TextBox txtmaphien,
            TextBox txttenlopsv,
            TextBox txttenmonsv,
            TextBox txtngaytaophien,
            TextBox txtsolan,
            TextBox txttrangthai,

            TextBox txtmssv_phanhoisv,
            TextBox txthodem_phanhoisv,
            TextBox txtten_phanhoisv,
            TextBox txtlop_phanhoisv,
            TextBox txtmon_phanhoisv,
            RichTextBox txtnoidung_phanhoisv,
            TextBox txtngay_phanhoisv,
            RichTextBox txtnnoidunggui_phanhoi,

            Button btnthem_phanhoi,
            Button btngui_phanhoi,
            Button btnhuy_phanhoi,
            Button btnxacnhan,
            Button btnlambai)
        {
            panelcauhoi.Visible = false;
            panel5.Visible = false;
            // Set visibility to false

            // Set enabled to false
            txtmaphien.Enabled = false;
            txttenlopsv.Enabled = false;
            txttenmonsv.Enabled = false;
            txtngaytaophien.Enabled = false;
            txtsolan.Enabled = false;
            txttrangthai.Enabled = false;

            txtmssv_phanhoisv.Enabled = false;
            txthodem_phanhoisv.Enabled = false;
            txtten_phanhoisv.Enabled = false;
            txtlop_phanhoisv.Enabled = false;
            txtmon_phanhoisv.Enabled = false;
            txtnoidung_phanhoisv.Enabled = false;
            txtngay_phanhoisv.Enabled = false;
            txtnnoidunggui_phanhoi.Visible = false;

            btnthem_phanhoi.Enabled = true;
            btngui_phanhoi.Enabled = false;
            btnhuy_phanhoi.Enabled = false;
            btnxacnhan.Enabled = false;
            btnlambai.Enabled = false;
        }
        public void CapNhatTrangThaiNut_Class(bool them, bool luu, bool huy, bool xacnhan, bool lambai,
       Button btnThem_phanhoi, Button btngui_phanhoi, Button btnHuy_phanhoi, Button btnxacnhan, Button btnlambai)
        {
            btnThem_phanhoi.Enabled = them;
            btngui_phanhoi.Enabled = luu;
            btnHuy_phanhoi.Enabled = huy;
            btnxacnhan.Enabled = xacnhan;
            btnlambai.Enabled = lambai ;
        }

    }
}
