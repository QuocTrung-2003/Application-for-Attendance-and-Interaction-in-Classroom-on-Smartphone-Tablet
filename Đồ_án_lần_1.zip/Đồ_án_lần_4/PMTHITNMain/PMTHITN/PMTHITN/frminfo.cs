﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PMTHITN.Data;

namespace PMTHITN
{
    using PMTHITN.Class;
    public partial class frminfo : MetroFramework.Forms.MetroForm
    {
        SqlConnection conn = new SqlConnection();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand cmd = new SqlCommand();
        DataTable dt = new DataTable();
        //string sql, constr;
        private DatabaseHelper dbHelper;
        public frminfo()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper("MSI\\MSSQLSERVER01", "THITRACNGHIEM");
        }

        private void frminfo_Load(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = dbHelper.GetConnection())
                {
                    // Lấy thời gian hệ thống hiện tại
                    DateTime now = DateTime.Now;

                    // Sử dụng điều kiện để kiểm tra cả ngày và giờ
                    string sql = "SELECT * FROM MONTHI WHERE Thoigianthi >= @CurrentDateTime";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@CurrentDateTime", now);

                        DataTable dt = new DataTable();
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt);
                        }

                        if (dt.Rows.Count > 0)
                        {
                            lblmonthi.Text = dt.Rows[0][2].ToString();
                            lblsocau.Text = dt.Rows[0][3].ToString();
                            lblthoigian.Text = dt.Rows[0][4].ToString() + " phút";

                            string masinhvien = thongtinsv.MSV;

                            sql = "SELECT * FROM SV WHERE MaSV = @MaSV";

                            using (SqlCommand cmdSv = new SqlCommand(sql, conn))
                            {
                                cmdSv.Parameters.AddWithValue("@MaSV", masinhvien);

                                DataTable dtSv = new DataTable();
                                using (SqlDataAdapter daSv = new SqlDataAdapter(cmdSv))
                                {
                                    daSv.Fill(dtSv);
                                }

                                if (dtSv.Rows.Count > 0)
                                {
                                    lblhoten.Text = dtSv.Rows[0][1].ToString() + " " + dtSv.Rows[0][2].ToString();
                                    lblmsv.Text = thongtinsv.MSV;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Không có môn thi nào hôm nay hoặc giờ thi chưa đến. Vui lòng kiểm tra lại lịch thi.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                    }
                } // Conn tự động đóng khi thoát using
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }


        private void btnvaothi_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ẩn form hiện tại

            // Tạo instance của form mới
            frmbaithi newForm = new frmbaithi();

            // Gán sự kiện khi form mới được đóng
            newForm.FormClosed += (s, args) =>
            {
                // Chỉ đóng form hiện tại
                this.Close();
            };

            // Hiển thị form mới
            newForm.Show();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void grbtt_Enter(object sender, EventArgs e)
        {

        }

        private void lblhoten_Click(object sender, EventArgs e)
        {

        }

        private void lblhoten_Click_1(object sender, EventArgs e)
        {

        }
        private void lblthoigian_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblmonthi_Click(object sender, EventArgs e)
        {

        }
    }
}

