﻿namespace PMTHITN
{
    partial class frmsv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmsv));
            this.tabtrogiup = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbltrogiup = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.linkthemsv = new System.Windows.Forms.LinkLabel();
            this.linktimmt = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.label13 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label12 = new System.Windows.Forms.Label();
            this.linkxoasv = new System.Windows.Forms.LinkLabel();
            this.linksuasv = new System.Windows.Forms.LinkLabel();
            this.linktimsv = new System.Windows.Forms.LinkLabel();
            this.label11 = new System.Windows.Forms.Label();
            this.linkxoamt = new System.Windows.Forms.LinkLabel();
            this.linksuamt = new System.Windows.Forms.LinkLabel();
            this.linkthemmt = new System.Windows.Forms.LinkLabel();
            this.label10 = new System.Windows.Forms.Label();
            this.linkxoach = new System.Windows.Forms.LinkLabel();
            this.linksuach = new System.Windows.Forms.LinkLabel();
            this.linkthemch = new System.Windows.Forms.LinkLabel();
            this.linktimch = new System.Windows.Forms.LinkLabel();
            this.label9 = new System.Windows.Forms.Label();
            this.tabbaocao = new System.Windows.Forms.TabPage();
            this.dgvbc_sv = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grbtim = new System.Windows.Forms.GroupBox();
            this.dpttimkiembaocao_sv = new System.Windows.Forms.DateTimePicker();
            this.lblngaytimkiembaocao_sv = new System.Windows.Forms.Label();
            this.btnbcmon = new PMTHITN.RJButton();
            this.txtMalopsv = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnbclop = new PMTHITN.RJButton();
            this.cmbtenmonsv = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.picbaithi = new System.Windows.Forms.PictureBox();
            this.picbangdiem = new System.Windows.Forms.PictureBox();
            this.tabquanly = new System.Windows.Forms.TabPage();
            this.panelcauhoi = new System.Windows.Forms.Panel();
            this.grbchitietch = new System.Windows.Forms.GroupBox();
            this.txtsolan = new System.Windows.Forms.TextBox();
            this.lblsolan = new System.Windows.Forms.Label();
            this.btnlambai = new PMTHITN.RJButton();
            this.txttrangthai = new System.Windows.Forms.TextBox();
            this.txtngaytaophien = new System.Windows.Forms.TextBox();
            this.btnExit = new PMTHITN.RJButton();
            this.btnxacnhan = new PMTHITN.RJButton();
            this.txttenlopsv = new System.Windows.Forms.TextBox();
            this.lblngaytaophien = new System.Windows.Forms.Label();
            this.txtmaphien = new System.Windows.Forms.TextBox();
            this.lblmaphien = new System.Windows.Forms.Label();
            this.lbltenmon = new System.Windows.Forms.Label();
            this.txtmach = new System.Windows.Forms.TextBox();
            this.lbltenlop = new System.Windows.Forms.Label();
            this.txttenmonsv = new System.Windows.Forms.TextBox();
            this.lbltrangthai = new System.Windows.Forms.Label();
            this.grbdiemdanh = new System.Windows.Forms.GroupBox();
            this.dgvdiemdanhsv = new System.Windows.Forms.DataGridView();
            this.grbtimch = new System.Windows.Forms.GroupBox();
            this.cmblocsv = new System.Windows.Forms.ComboBox();
            this.lbllocsv = new System.Windows.Forms.Label();
            this.txttimsv = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picmonthi = new System.Windows.Forms.PictureBox();
            this.piccauhoi = new System.Windows.Forms.PictureBox();
            this.tHITRACNGHIEMDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tHITRACNGHIEMDataSet = new PMTHITN.THITRACNGHIEMDataSet();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabphanhoi = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.grbphanhoisv_dgv = new System.Windows.Forms.GroupBox();
            this.dgvphanhoisv = new System.Windows.Forms.DataGridView();
            this.grbphanhoisv = new System.Windows.Forms.GroupBox();
            this.txtmon_phanhoisv = new System.Windows.Forms.TextBox();
            this.lblmon_phanhoisv = new System.Windows.Forms.Label();
            this.btnthem_phanhoi = new PMTHITN.RJButton();
            this.btnhuy_phanhoi = new PMTHITN.RJButton();
            this.btngui_phanhoi = new PMTHITN.RJButton();
            this.btnExit_phanhoi = new PMTHITN.RJButton();
            this.txtngay_phanhoisv = new System.Windows.Forms.TextBox();
            this.txtlop_phanhoisv = new System.Windows.Forms.TextBox();
            this.txtten_phanhoisv = new System.Windows.Forms.TextBox();
            this.txthodem_phanhoisv = new System.Windows.Forms.TextBox();
            this.txtmssv_phanhoisv = new System.Windows.Forms.TextBox();
            this.txtnoidung_phanhoisv = new System.Windows.Forms.RichTextBox();
            this.lblnoidung_phanhoi = new System.Windows.Forms.Label();
            this.lbllop_phanhoi = new System.Windows.Forms.Label();
            this.lblngay_phanhoi = new System.Windows.Forms.Label();
            this.lblten_phanhoi = new System.Windows.Forms.Label();
            this.lblhodem_phanhoi = new System.Windows.Forms.Label();
            this.lblmssv_phahoi = new System.Windows.Forms.Label();
            this.txtnoidunggui_phanhoi = new System.Windows.Forms.RichTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.grbtimphanhoi = new System.Windows.Forms.GroupBox();
            this.dtptimkiem_phanhoisv = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.txttimkiemlop_phanhoisv = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txttimkiemmon_phanhoisv = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.picsphanhoi = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.RefreshDatasv = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mONTHIBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mONTHITableAdapter = new PMTHITN.THITRACNGHIEMDataSetTableAdapters.MONTHITableAdapter();
            this.gvTableAdapter1 = new PMTHITN.THITRACNGHIEMDataSetTableAdapters.GVTableAdapter();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cAUHOIBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cAUHOITableAdapter = new PMTHITN.THITRACNGHIEMDataSetTableAdapters.CAUHOITableAdapter();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.tabtrogiup.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabbaocao.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbc_sv)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grbtim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbaithi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbangdiem)).BeginInit();
            this.tabquanly.SuspendLayout();
            this.panelcauhoi.SuspendLayout();
            this.grbchitietch.SuspendLayout();
            this.grbdiemdanh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdiemdanhsv)).BeginInit();
            this.grbtimch.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picmonthi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccauhoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSet)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabphanhoi.SuspendLayout();
            this.panel5.SuspendLayout();
            this.grbphanhoisv_dgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvphanhoisv)).BeginInit();
            this.grbphanhoisv.SuspendLayout();
            this.panel4.SuspendLayout();
            this.grbtimphanhoi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsphanhoi)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mONTHIBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAUHOIBindingSource)).BeginInit();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabtrogiup
            // 
            this.tabtrogiup.Controls.Add(this.tableLayoutPanel1);
            this.tabtrogiup.Location = new System.Drawing.Point(4, 38);
            this.tabtrogiup.Margin = new System.Windows.Forms.Padding(4);
            this.tabtrogiup.Name = "tabtrogiup";
            this.tabtrogiup.Size = new System.Drawing.Size(1894, 844);
            this.tabtrogiup.TabIndex = 2;
            this.tabtrogiup.Text = "Trợ giúp";
            this.tabtrogiup.UseVisualStyleBackColor = true;
            this.tabtrogiup.Click += new System.EventHandler(this.tabtrogiup_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.90006F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.09994F));
            this.tableLayoutPanel1.Controls.Add(this.lbltrogiup, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.89163F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 841F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1894, 844);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // lbltrogiup
            // 
            this.lbltrogiup.BackColor = System.Drawing.Color.Gainsboro;
            this.lbltrogiup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbltrogiup.Location = new System.Drawing.Point(535, 3);
            this.lbltrogiup.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltrogiup.Name = "lbltrogiup";
            this.lbltrogiup.Size = new System.Drawing.Size(1352, 838);
            this.lbltrogiup.TabIndex = 1;
            this.lbltrogiup.Click += new System.EventHandler(this.lbltrogiup_Click);
            // 
            // panel3
            // 
            this.panel3.AutoSize = true;
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Controls.Add(this.linkthemsv);
            this.panel3.Controls.Add(this.linktimmt);
            this.panel3.Controls.Add(this.linkLabel3);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.linkLabel2);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.linkxoasv);
            this.panel3.Controls.Add(this.linksuasv);
            this.panel3.Controls.Add(this.linktimsv);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.linkxoamt);
            this.panel3.Controls.Add(this.linksuamt);
            this.panel3.Controls.Add(this.linkthemmt);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.linkxoach);
            this.panel3.Controls.Add(this.linksuach);
            this.panel3.Controls.Add(this.linkthemch);
            this.panel3.Controls.Add(this.linktimch);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(7, 7);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(517, 830);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // linkthemsv
            // 
            this.linkthemsv.AutoSize = true;
            this.linkthemsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkthemsv.LinkColor = System.Drawing.Color.Black;
            this.linkthemsv.Location = new System.Drawing.Point(46, 444);
            this.linkthemsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkthemsv.Name = "linkthemsv";
            this.linkthemsv.Size = new System.Drawing.Size(79, 25);
            this.linkthemsv.TabIndex = 22;
            this.linkthemsv.TabStop = true;
            this.linkthemsv.Text = "2.Thêm";
            this.linkthemsv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkthemsv_LinkClicked);
            // 
            // linktimmt
            // 
            this.linktimmt.AutoSize = true;
            this.linktimmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linktimmt.LinkColor = System.Drawing.Color.Black;
            this.linktimmt.Location = new System.Drawing.Point(45, 208);
            this.linktimmt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linktimmt.Name = "linktimmt";
            this.linktimmt.Size = new System.Drawing.Size(107, 25);
            this.linktimmt.TabIndex = 9;
            this.linktimmt.TabStop = true;
            this.linktimmt.Text = "1.Tìm kiếm";
            this.linktimmt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linktimmt_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.LinkColor = System.Drawing.Color.Black;
            this.linkLabel3.Location = new System.Drawing.Point(45, 718);
            this.linkLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(125, 25);
            this.linkLabel3.TabIndex = 21;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "1.Xem bài thi";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(4, 672);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(263, 29);
            this.label13.TabIndex = 20;
            this.label13.Text = "V. Xem bài thi của SV\r\n";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.LinkColor = System.Drawing.Color.Black;
            this.linkLabel2.Location = new System.Drawing.Point(46, 618);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(165, 25);
            this.linkLabel2.TabIndex = 19;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "1.Xem bảng điểm";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(7, 585);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(234, 29);
            this.label12.TabIndex = 18;
            this.label12.Text = "IV. Xem bảng điểm\r\n";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // linkxoasv
            // 
            this.linkxoasv.AutoSize = true;
            this.linkxoasv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkxoasv.LinkColor = System.Drawing.Color.Black;
            this.linkxoasv.Location = new System.Drawing.Point(50, 535);
            this.linkxoasv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkxoasv.Name = "linkxoasv";
            this.linkxoasv.Size = new System.Drawing.Size(64, 25);
            this.linkxoasv.TabIndex = 17;
            this.linkxoasv.TabStop = true;
            this.linkxoasv.Text = "4.Xóa";
            this.linkxoasv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkxoasv_LinkClicked);
            // 
            // linksuasv
            // 
            this.linksuasv.AutoSize = true;
            this.linksuasv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linksuasv.LinkColor = System.Drawing.Color.Black;
            this.linksuasv.Location = new System.Drawing.Point(50, 490);
            this.linksuasv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linksuasv.Name = "linksuasv";
            this.linksuasv.Size = new System.Drawing.Size(64, 25);
            this.linksuasv.TabIndex = 16;
            this.linksuasv.TabStop = true;
            this.linksuasv.Text = "3.Sửa";
            this.linksuasv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linksuasv_LinkClicked);
            // 
            // linktimsv
            // 
            this.linktimsv.AutoSize = true;
            this.linktimsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linktimsv.LinkColor = System.Drawing.Color.Black;
            this.linktimsv.Location = new System.Drawing.Point(46, 402);
            this.linktimsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linktimsv.Name = "linktimsv";
            this.linktimsv.Size = new System.Drawing.Size(107, 25);
            this.linktimsv.TabIndex = 14;
            this.linktimsv.TabStop = true;
            this.linktimsv.Text = "1.Tìm kiếm";
            this.linktimsv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linktimsv_LinkClicked);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(7, 368);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(446, 29);
            this.label11.TabIndex = 13;
            this.label11.Text = "III. Quản lý sinh viên (Coming soon...)";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // linkxoamt
            // 
            this.linkxoamt.AutoSize = true;
            this.linkxoamt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkxoamt.LinkColor = System.Drawing.Color.Black;
            this.linkxoamt.Location = new System.Drawing.Point(46, 322);
            this.linkxoamt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkxoamt.Name = "linkxoamt";
            this.linkxoamt.Size = new System.Drawing.Size(64, 25);
            this.linkxoamt.TabIndex = 12;
            this.linkxoamt.TabStop = true;
            this.linkxoamt.Text = "4.Xóa";
            this.linkxoamt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkxoamt_LinkClicked);
            // 
            // linksuamt
            // 
            this.linksuamt.AutoSize = true;
            this.linksuamt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linksuamt.LinkColor = System.Drawing.Color.Black;
            this.linksuamt.Location = new System.Drawing.Point(46, 286);
            this.linksuamt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linksuamt.Name = "linksuamt";
            this.linksuamt.Size = new System.Drawing.Size(64, 25);
            this.linksuamt.TabIndex = 11;
            this.linksuamt.TabStop = true;
            this.linksuamt.Text = "3.Sửa";
            this.linksuamt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linksuamt_LinkClicked);
            // 
            // linkthemmt
            // 
            this.linkthemmt.AutoSize = true;
            this.linkthemmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkthemmt.LinkColor = System.Drawing.Color.Black;
            this.linkthemmt.Location = new System.Drawing.Point(45, 250);
            this.linkthemmt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkthemmt.Name = "linkthemmt";
            this.linkthemmt.Size = new System.Drawing.Size(79, 25);
            this.linkthemmt.TabIndex = 10;
            this.linkthemmt.TabStop = true;
            this.linkthemmt.Text = "2.Thêm";
            this.linkthemmt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkthemmt_LinkClicked);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(7, 174);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(214, 29);
            this.label10.TabIndex = 8;
            this.label10.Text = "II.Quản lý môn thi";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // linkxoach
            // 
            this.linkxoach.AutoSize = true;
            this.linkxoach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkxoach.LinkColor = System.Drawing.Color.Black;
            this.linkxoach.Location = new System.Drawing.Point(45, 138);
            this.linkxoach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkxoach.Name = "linkxoach";
            this.linkxoach.Size = new System.Drawing.Size(64, 25);
            this.linkxoach.TabIndex = 7;
            this.linkxoach.TabStop = true;
            this.linkxoach.Text = "4.Xóa";
            this.linkxoach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkxoach_LinkClicked);
            // 
            // linksuach
            // 
            this.linksuach.AutoSize = true;
            this.linksuach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linksuach.LinkColor = System.Drawing.Color.Black;
            this.linksuach.Location = new System.Drawing.Point(45, 106);
            this.linksuach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linksuach.Name = "linksuach";
            this.linksuach.Size = new System.Drawing.Size(64, 25);
            this.linksuach.TabIndex = 6;
            this.linksuach.TabStop = true;
            this.linksuach.Text = "3.Sửa";
            this.linksuach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linksuach_LinkClicked);
            // 
            // linkthemch
            // 
            this.linkthemch.AutoSize = true;
            this.linkthemch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkthemch.LinkColor = System.Drawing.Color.Black;
            this.linkthemch.Location = new System.Drawing.Point(45, 74);
            this.linkthemch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkthemch.Name = "linkthemch";
            this.linkthemch.Size = new System.Drawing.Size(79, 25);
            this.linkthemch.TabIndex = 5;
            this.linkthemch.TabStop = true;
            this.linkthemch.Text = "2.Thêm";
            this.linkthemch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkthemch_LinkClicked);
            // 
            // linktimch
            // 
            this.linktimch.AutoSize = true;
            this.linktimch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linktimch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.linktimch.LinkColor = System.Drawing.Color.Black;
            this.linktimch.Location = new System.Drawing.Point(46, 39);
            this.linktimch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linktimch.Name = "linktimch";
            this.linktimch.Size = new System.Drawing.Size(107, 25);
            this.linktimch.TabIndex = 4;
            this.linktimch.TabStop = true;
            this.linktimch.Text = "1.Tìm kiếm";
            this.linktimch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linktimch_LinkClicked);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(7, 5);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(244, 29);
            this.label9.TabIndex = 1;
            this.label9.Text = "I.Ngân hàng câu hỏi";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // tabbaocao
            // 
            this.tabbaocao.Controls.Add(this.panel6);
            this.tabbaocao.Controls.Add(this.dgvbc_sv);
            this.tabbaocao.Controls.Add(this.panel2);
            this.tabbaocao.Location = new System.Drawing.Point(4, 38);
            this.tabbaocao.Margin = new System.Windows.Forms.Padding(4);
            this.tabbaocao.Name = "tabbaocao";
            this.tabbaocao.Padding = new System.Windows.Forms.Padding(4);
            this.tabbaocao.Size = new System.Drawing.Size(1894, 844);
            this.tabbaocao.TabIndex = 1;
            this.tabbaocao.Text = "Báo cáo";
            this.tabbaocao.UseVisualStyleBackColor = true;
            this.tabbaocao.Click += new System.EventHandler(this.tabbaocao_Click);
            // 
            // dgvbc_sv
            // 
            this.dgvbc_sv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvbc_sv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvbc_sv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvbc_sv.BackgroundColor = System.Drawing.Color.White;
            this.dgvbc_sv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvbc_sv.Location = new System.Drawing.Point(4, 132);
            this.dgvbc_sv.Margin = new System.Windows.Forms.Padding(4);
            this.dgvbc_sv.Name = "dgvbc_sv";
            this.dgvbc_sv.RowHeadersWidth = 51;
            this.dgvbc_sv.Size = new System.Drawing.Size(1645, 762);
            this.dgvbc_sv.TabIndex = 2;
            this.dgvbc_sv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvbc_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.grbtim);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.picbaithi);
            this.panel2.Controls.Add(this.picbangdiem);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1886, 128);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(319, 91);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 25);
            this.label15.TabIndex = 7;
            this.label15.Text = "Điểm danh";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(331, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(93, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.picsbaocaodiemdanhsv_Click);
            // 
            // grbtim
            // 
            this.grbtim.Controls.Add(this.dpttimkiembaocao_sv);
            this.grbtim.Controls.Add(this.lblngaytimkiembaocao_sv);
            this.grbtim.Controls.Add(this.txtMalopsv);
            this.grbtim.Controls.Add(this.label8);
            this.grbtim.Controls.Add(this.cmbtenmonsv);
            this.grbtim.Controls.Add(this.label7);
            this.grbtim.Location = new System.Drawing.Point(482, 9);
            this.grbtim.Margin = new System.Windows.Forms.Padding(4);
            this.grbtim.Name = "grbtim";
            this.grbtim.Padding = new System.Windows.Forms.Padding(4);
            this.grbtim.Size = new System.Drawing.Size(1384, 103);
            this.grbtim.TabIndex = 5;
            this.grbtim.TabStop = false;
            this.grbtim.Text = "Bài làm";
            this.grbtim.Enter += new System.EventHandler(this.grbtim_Enter);
            // 
            // dpttimkiembaocao_sv
            // 
            this.dpttimkiembaocao_sv.CustomFormat = "";
            this.dpttimkiembaocao_sv.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpttimkiembaocao_sv.Location = new System.Drawing.Point(882, 53);
            this.dpttimkiembaocao_sv.Name = "dpttimkiembaocao_sv";
            this.dpttimkiembaocao_sv.Size = new System.Drawing.Size(172, 34);
            this.dpttimkiembaocao_sv.TabIndex = 17;
            this.dpttimkiembaocao_sv.Value = new System.DateTime(2024, 10, 5, 13, 47, 10, 0);
            this.dpttimkiembaocao_sv.ValueChanged += new System.EventHandler(this.dpttimkiembaocaosv_ValueChanged);
            // 
            // lblngaytimkiembaocao_sv
            // 
            this.lblngaytimkiembaocao_sv.AutoSize = true;
            this.lblngaytimkiembaocao_sv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblngaytimkiembaocao_sv.Location = new System.Drawing.Point(810, 25);
            this.lblngaytimkiembaocao_sv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblngaytimkiembaocao_sv.Name = "lblngaytimkiembaocao_sv";
            this.lblngaytimkiembaocao_sv.Size = new System.Drawing.Size(69, 25);
            this.lblngaytimkiembaocao_sv.TabIndex = 16;
            this.lblngaytimkiembaocao_sv.Text = "Ngày:";
            // 
            // btnbcmon
            // 
            this.btnbcmon.BackColor = System.Drawing.Color.Snow;
            this.btnbcmon.BackgroundColor = System.Drawing.Color.Snow;
            this.btnbcmon.BorderColor = System.Drawing.Color.Black;
            this.btnbcmon.BorderRadius = 20;
            this.btnbcmon.BorderSize = 2;
            this.btnbcmon.FlatAppearance.BorderSize = 0;
            this.btnbcmon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbcmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbcmon.ForeColor = System.Drawing.Color.Black;
            this.btnbcmon.Location = new System.Drawing.Point(25, 175);
            this.btnbcmon.Margin = new System.Windows.Forms.Padding(4);
            this.btnbcmon.Name = "btnbcmon";
            this.btnbcmon.Size = new System.Drawing.Size(193, 78);
            this.btnbcmon.TabIndex = 14;
            this.btnbcmon.Text = "Xuất bảng điểm theo môn";
            this.btnbcmon.TextColor = System.Drawing.Color.Black;
            this.btnbcmon.UseVisualStyleBackColor = false;
            this.btnbcmon.Click += new System.EventHandler(this.btnbcmon_Click);
            // 
            // txtMalopsv
            // 
            this.txtMalopsv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMalopsv.Location = new System.Drawing.Point(498, 53);
            this.txtMalopsv.Margin = new System.Windows.Forms.Padding(4);
            this.txtMalopsv.Name = "txtMalopsv";
            this.txtMalopsv.Size = new System.Drawing.Size(283, 30);
            this.txtMalopsv.TabIndex = 13;
            this.txtMalopsv.TextChanged += new System.EventHandler(this.txtMalopsv_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(435, 27);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 25);
            this.label8.TabIndex = 12;
            this.label8.Text = "Lớp:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // btnbclop
            // 
            this.btnbclop.BackColor = System.Drawing.Color.Snow;
            this.btnbclop.BackgroundColor = System.Drawing.Color.Snow;
            this.btnbclop.BorderColor = System.Drawing.Color.Black;
            this.btnbclop.BorderRadius = 20;
            this.btnbclop.BorderSize = 2;
            this.btnbclop.FlatAppearance.BorderSize = 0;
            this.btnbclop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbclop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbclop.ForeColor = System.Drawing.Color.Black;
            this.btnbclop.Location = new System.Drawing.Point(25, 76);
            this.btnbclop.Margin = new System.Windows.Forms.Padding(4);
            this.btnbclop.Name = "btnbclop";
            this.btnbclop.Size = new System.Drawing.Size(193, 78);
            this.btnbclop.TabIndex = 10;
            this.btnbclop.Text = "Xuất bảng điểm theo lớp";
            this.btnbclop.TextColor = System.Drawing.Color.Black;
            this.btnbclop.UseVisualStyleBackColor = false;
            this.btnbclop.Click += new System.EventHandler(this.btnbclop_Click);
            // 
            // cmbtenmonsv
            // 
            this.cmbtenmonsv.DisplayMember = "Tenmon";
            this.cmbtenmonsv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtenmonsv.FormattingEnabled = true;
            this.cmbtenmonsv.Items.AddRange(new object[] {
            "Tin"});
            this.cmbtenmonsv.Location = new System.Drawing.Point(266, 51);
            this.cmbtenmonsv.Margin = new System.Windows.Forms.Padding(4);
            this.cmbtenmonsv.Name = "cmbtenmonsv";
            this.cmbtenmonsv.Size = new System.Drawing.Size(132, 31);
            this.cmbtenmonsv.TabIndex = 7;
            this.cmbtenmonsv.ValueMember = "Tenmon";
            this.cmbtenmonsv.SelectedIndexChanged += new System.EventHandler(this.cmbtenmon_SelectedIndexChanged_1);
            this.cmbtenmonsv.TextChanged += new System.EventHandler(this.cmbtenmonsv_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(192, 27);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "Môn:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(166, 91);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 42);
            this.label5.TabIndex = 4;
            this.label5.Text = "Bài kiểm tra";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 91);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 45);
            this.label6.TabIndex = 3;
            this.label6.Text = "Bảng điểm";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // picbaithi
            // 
            this.picbaithi.BackColor = System.Drawing.Color.White;
            this.picbaithi.Image = ((System.Drawing.Image)(resources.GetObject("picbaithi.Image")));
            this.picbaithi.Location = new System.Drawing.Point(186, 9);
            this.picbaithi.Margin = new System.Windows.Forms.Padding(4);
            this.picbaithi.Name = "picbaithi";
            this.picbaithi.Size = new System.Drawing.Size(93, 78);
            this.picbaithi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbaithi.TabIndex = 2;
            this.picbaithi.TabStop = false;
            this.picbaithi.Click += new System.EventHandler(this.picbaithisv_Click);
            // 
            // picbangdiem
            // 
            this.picbangdiem.BackColor = System.Drawing.Color.White;
            this.picbangdiem.Image = ((System.Drawing.Image)(resources.GetObject("picbangdiem.Image")));
            this.picbangdiem.Location = new System.Drawing.Point(33, 9);
            this.picbangdiem.Margin = new System.Windows.Forms.Padding(4);
            this.picbangdiem.Name = "picbangdiem";
            this.picbangdiem.Size = new System.Drawing.Size(96, 78);
            this.picbangdiem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbangdiem.TabIndex = 0;
            this.picbangdiem.TabStop = false;
            this.picbangdiem.Click += new System.EventHandler(this.picbangdiemsv_Click);
            // 
            // tabquanly
            // 
            this.tabquanly.BackColor = System.Drawing.Color.White;
            this.tabquanly.Controls.Add(this.panelcauhoi);
            this.tabquanly.Controls.Add(this.panel1);
            this.tabquanly.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabquanly.Location = new System.Drawing.Point(4, 38);
            this.tabquanly.Margin = new System.Windows.Forms.Padding(4);
            this.tabquanly.Name = "tabquanly";
            this.tabquanly.Padding = new System.Windows.Forms.Padding(4);
            this.tabquanly.Size = new System.Drawing.Size(1894, 844);
            this.tabquanly.TabIndex = 0;
            this.tabquanly.Text = "Quản lý";
            this.tabquanly.Click += new System.EventHandler(this.tabquanly_Click);
            // 
            // panelcauhoi
            // 
            this.panelcauhoi.AutoSize = true;
            this.panelcauhoi.BackColor = System.Drawing.Color.Transparent;
            this.panelcauhoi.Controls.Add(this.grbchitietch);
            this.panelcauhoi.Controls.Add(this.grbdiemdanh);
            this.panelcauhoi.Controls.Add(this.grbtimch);
            this.panelcauhoi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelcauhoi.Location = new System.Drawing.Point(4, 161);
            this.panelcauhoi.Margin = new System.Windows.Forms.Padding(4);
            this.panelcauhoi.Name = "panelcauhoi";
            this.panelcauhoi.Size = new System.Drawing.Size(1886, 679);
            this.panelcauhoi.TabIndex = 1;
            this.panelcauhoi.Paint += new System.Windows.Forms.PaintEventHandler(this.panelcauhoi_Paint);
            // 
            // grbchitietch
            // 
            this.grbchitietch.BackColor = System.Drawing.Color.Transparent;
            this.grbchitietch.Controls.Add(this.txtsolan);
            this.grbchitietch.Controls.Add(this.lblsolan);
            this.grbchitietch.Controls.Add(this.btnlambai);
            this.grbchitietch.Controls.Add(this.txttrangthai);
            this.grbchitietch.Controls.Add(this.txtngaytaophien);
            this.grbchitietch.Controls.Add(this.btnExit);
            this.grbchitietch.Controls.Add(this.btnxacnhan);
            this.grbchitietch.Controls.Add(this.txttenlopsv);
            this.grbchitietch.Controls.Add(this.lblngaytaophien);
            this.grbchitietch.Controls.Add(this.txtmaphien);
            this.grbchitietch.Controls.Add(this.lblmaphien);
            this.grbchitietch.Controls.Add(this.lbltenmon);
            this.grbchitietch.Controls.Add(this.txtmach);
            this.grbchitietch.Controls.Add(this.lbltenlop);
            this.grbchitietch.Controls.Add(this.txttenmonsv);
            this.grbchitietch.Controls.Add(this.lbltrangthai);
            this.grbchitietch.Dock = System.Windows.Forms.DockStyle.Right;
            this.grbchitietch.Location = new System.Drawing.Point(1064, 0);
            this.grbchitietch.Margin = new System.Windows.Forms.Padding(4);
            this.grbchitietch.Name = "grbchitietch";
            this.grbchitietch.Padding = new System.Windows.Forms.Padding(4);
            this.grbchitietch.Size = new System.Drawing.Size(822, 679);
            this.grbchitietch.TabIndex = 2;
            this.grbchitietch.TabStop = false;
            this.grbchitietch.Text = "Chi tiết";
            this.grbchitietch.Enter += new System.EventHandler(this.grbchitietch_Enter);
            // 
            // txtsolan
            // 
            this.txtsolan.Location = new System.Drawing.Point(381, 338);
            this.txtsolan.Name = "txtsolan";
            this.txtsolan.Size = new System.Drawing.Size(82, 34);
            this.txtsolan.TabIndex = 61;
            // 
            // lblsolan
            // 
            this.lblsolan.AutoSize = true;
            this.lblsolan.Location = new System.Drawing.Point(70, 343);
            this.lblsolan.Name = "lblsolan";
            this.lblsolan.Size = new System.Drawing.Size(58, 29);
            this.lblsolan.TabIndex = 60;
            this.lblsolan.Text = "Lần:";
            // 
            // btnlambai
            // 
            this.btnlambai.BackColor = System.Drawing.Color.White;
            this.btnlambai.BackgroundColor = System.Drawing.Color.White;
            this.btnlambai.BorderColor = System.Drawing.Color.Black;
            this.btnlambai.BorderRadius = 20;
            this.btnlambai.BorderSize = 2;
            this.btnlambai.FlatAppearance.BorderSize = 0;
            this.btnlambai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlambai.ForeColor = System.Drawing.Color.Black;
            this.btnlambai.Location = new System.Drawing.Point(334, 514);
            this.btnlambai.Name = "btnlambai";
            this.btnlambai.Size = new System.Drawing.Size(199, 58);
            this.btnlambai.TabIndex = 59;
            this.btnlambai.Text = "Làm bài";
            this.btnlambai.TextColor = System.Drawing.Color.Black;
            this.btnlambai.UseVisualStyleBackColor = false;
            this.btnlambai.Click += new System.EventHandler(this.btnlambai_Click);
            // 
            // txttrangthai
            // 
            this.txttrangthai.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txttrangthai.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttrangthai.Location = new System.Drawing.Point(378, 394);
            this.txttrangthai.Margin = new System.Windows.Forms.Padding(4);
            this.txttrangthai.Name = "txttrangthai";
            this.txttrangthai.Size = new System.Drawing.Size(85, 33);
            this.txttrangthai.TabIndex = 57;
            // 
            // txtngaytaophien
            // 
            this.txtngaytaophien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtngaytaophien.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtngaytaophien.Location = new System.Drawing.Point(378, 286);
            this.txtngaytaophien.Margin = new System.Windows.Forms.Padding(4);
            this.txtngaytaophien.Name = "txtngaytaophien";
            this.txtngaytaophien.Size = new System.Drawing.Size(340, 33);
            this.txtngaytaophien.TabIndex = 56;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.BackgroundColor = System.Drawing.Color.White;
            this.btnExit.BorderColor = System.Drawing.Color.Black;
            this.btnExit.BorderRadius = 20;
            this.btnExit.BorderSize = 2;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(692, 588);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(107, 62);
            this.btnExit.TabIndex = 55;
            this.btnExit.Text = "Thoát";
            this.btnExit.TextColor = System.Drawing.Color.Black;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnxacnhan
            // 
            this.btnxacnhan.BackColor = System.Drawing.Color.White;
            this.btnxacnhan.BackgroundColor = System.Drawing.Color.White;
            this.btnxacnhan.BorderColor = System.Drawing.Color.Black;
            this.btnxacnhan.BorderRadius = 20;
            this.btnxacnhan.BorderSize = 2;
            this.btnxacnhan.FlatAppearance.BorderSize = 0;
            this.btnxacnhan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnxacnhan.ForeColor = System.Drawing.Color.Black;
            this.btnxacnhan.Location = new System.Drawing.Point(275, 511);
            this.btnxacnhan.Name = "btnxacnhan";
            this.btnxacnhan.Size = new System.Drawing.Size(294, 61);
            this.btnxacnhan.TabIndex = 54;
            this.btnxacnhan.Text = "Xác nhận điểm danh";
            this.btnxacnhan.TextColor = System.Drawing.Color.Black;
            this.btnxacnhan.UseVisualStyleBackColor = false;
            this.btnxacnhan.Click += new System.EventHandler(this.btnxacnhan_Click);
            // 
            // txttenlopsv
            // 
            this.txttenlopsv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txttenlopsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttenlopsv.Location = new System.Drawing.Point(378, 170);
            this.txttenlopsv.Margin = new System.Windows.Forms.Padding(4);
            this.txttenlopsv.Name = "txttenlopsv";
            this.txttenlopsv.Size = new System.Drawing.Size(340, 30);
            this.txttenlopsv.TabIndex = 1;
            this.txttenlopsv.TextChanged += new System.EventHandler(this.txtmamon_TextChanged);
            // 
            // lblngaytaophien
            // 
            this.lblngaytaophien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblngaytaophien.AutoSize = true;
            this.lblngaytaophien.BackColor = System.Drawing.Color.Transparent;
            this.lblngaytaophien.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblngaytaophien.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblngaytaophien.Location = new System.Drawing.Point(64, 290);
            this.lblngaytaophien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblngaytaophien.Name = "lblngaytaophien";
            this.lblngaytaophien.Size = new System.Drawing.Size(180, 29);
            this.lblngaytaophien.TabIndex = 35;
            this.lblngaytaophien.Text = "Ngày tạo phiên:";
            this.lblngaytaophien.Click += new System.EventHandler(this.lbltgthi_Click);
            // 
            // txtmaphien
            // 
            this.txtmaphien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmaphien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmaphien.Location = new System.Drawing.Point(381, 115);
            this.txtmaphien.Margin = new System.Windows.Forms.Padding(4);
            this.txtmaphien.Name = "txtmaphien";
            this.txtmaphien.Size = new System.Drawing.Size(340, 30);
            this.txtmaphien.TabIndex = 31;
            this.txtmaphien.TextChanged += new System.EventHandler(this.txtsocau_TextChanged);
            // 
            // lblmaphien
            // 
            this.lblmaphien.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmaphien.AutoSize = true;
            this.lblmaphien.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmaphien.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblmaphien.Location = new System.Drawing.Point(68, 119);
            this.lblmaphien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmaphien.Name = "lblmaphien";
            this.lblmaphien.Size = new System.Drawing.Size(118, 29);
            this.lblmaphien.TabIndex = 30;
            this.lblmaphien.Text = "Mã phiên:";
            this.lblmaphien.Click += new System.EventHandler(this.lblsocau_Click);
            // 
            // lbltenmon
            // 
            this.lbltenmon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbltenmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltenmon.Location = new System.Drawing.Point(64, 229);
            this.lbltenmon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltenmon.Name = "lbltenmon";
            this.lbltenmon.Size = new System.Drawing.Size(167, 52);
            this.lbltenmon.TabIndex = 4;
            this.lbltenmon.Text = "Tên môn:";
            this.lbltenmon.Click += new System.EventHandler(this.lbltenmon_Click);
            // 
            // txtmach
            // 
            this.txtmach.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmach.Location = new System.Drawing.Point(378, 170);
            this.txtmach.Margin = new System.Windows.Forms.Padding(4);
            this.txtmach.Name = "txtmach";
            this.txtmach.Size = new System.Drawing.Size(134, 30);
            this.txtmach.TabIndex = 2;
            this.txtmach.TextChanged += new System.EventHandler(this.txtmach_TextChanged);
            // 
            // lbltenlop
            // 
            this.lbltenlop.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbltenlop.AutoSize = true;
            this.lbltenlop.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltenlop.Location = new System.Drawing.Point(65, 174);
            this.lbltenlop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltenlop.Name = "lbltenlop";
            this.lbltenlop.Size = new System.Drawing.Size(102, 29);
            this.lbltenlop.TabIndex = 1;
            this.lbltenlop.Text = "Tên lớp:";
            this.lbltenlop.Click += new System.EventHandler(this.lblmamon_Click);
            // 
            // txttenmonsv
            // 
            this.txttenmonsv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txttenmonsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttenmonsv.Location = new System.Drawing.Point(378, 232);
            this.txttenmonsv.Margin = new System.Windows.Forms.Padding(4);
            this.txttenmonsv.Name = "txttenmonsv";
            this.txttenmonsv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txttenmonsv.Size = new System.Drawing.Size(340, 30);
            this.txttenmonsv.TabIndex = 6;
            this.txttenmonsv.TextChanged += new System.EventHandler(this.txttenmon_TextChanged);
            // 
            // lbltrangthai
            // 
            this.lbltrangthai.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbltrangthai.AutoSize = true;
            this.lbltrangthai.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrangthai.Location = new System.Drawing.Point(69, 394);
            this.lbltrangthai.Name = "lbltrangthai";
            this.lbltrangthai.Size = new System.Drawing.Size(127, 29);
            this.lbltrangthai.TabIndex = 50;
            this.lbltrangthai.Text = "Trạng thái:";
            // 
            // grbdiemdanh
            // 
            this.grbdiemdanh.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbdiemdanh.Controls.Add(this.dgvdiemdanhsv);
            this.grbdiemdanh.Location = new System.Drawing.Point(14, 102);
            this.grbdiemdanh.Margin = new System.Windows.Forms.Padding(4);
            this.grbdiemdanh.Name = "grbdiemdanh";
            this.grbdiemdanh.Padding = new System.Windows.Forms.Padding(4);
            this.grbdiemdanh.Size = new System.Drawing.Size(1042, 573);
            this.grbdiemdanh.TabIndex = 1;
            this.grbdiemdanh.TabStop = false;
            this.grbdiemdanh.Text = "Phiên điểm danh";
            this.grbdiemdanh.Enter += new System.EventHandler(this.grbcauhoi_Enter);
            // 
            // dgvdiemdanhsv
            // 
            this.dgvdiemdanhsv.AllowUserToDeleteRows = false;
            this.dgvdiemdanhsv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvdiemdanhsv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvdiemdanhsv.BackgroundColor = System.Drawing.Color.White;
            this.dgvdiemdanhsv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdiemdanhsv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvdiemdanhsv.Location = new System.Drawing.Point(4, 31);
            this.dgvdiemdanhsv.Margin = new System.Windows.Forms.Padding(4);
            this.dgvdiemdanhsv.Name = "dgvdiemdanhsv";
            this.dgvdiemdanhsv.ReadOnly = true;
            this.dgvdiemdanhsv.RowHeadersWidth = 51;
            this.dgvdiemdanhsv.Size = new System.Drawing.Size(1034, 538);
            this.dgvdiemdanhsv.TabIndex = 0;
            this.dgvdiemdanhsv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvdiemdanhsv_CellClick);
            this.dgvdiemdanhsv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvdiemdanhsv_CellContentClick);
            // 
            // grbtimch
            // 
            this.grbtimch.Controls.Add(this.cmblocsv);
            this.grbtimch.Controls.Add(this.lbllocsv);
            this.grbtimch.Controls.Add(this.txttimsv);
            this.grbtimch.Dock = System.Windows.Forms.DockStyle.Left;
            this.grbtimch.Location = new System.Drawing.Point(0, 0);
            this.grbtimch.Margin = new System.Windows.Forms.Padding(4);
            this.grbtimch.Name = "grbtimch";
            this.grbtimch.Padding = new System.Windows.Forms.Padding(4);
            this.grbtimch.Size = new System.Drawing.Size(851, 679);
            this.grbtimch.TabIndex = 0;
            this.grbtimch.TabStop = false;
            this.grbtimch.Text = "Tìm kiếm";
            this.grbtimch.Enter += new System.EventHandler(this.grbtimch_Enter);
            // 
            // cmblocsv
            // 
            this.cmblocsv.FormattingEnabled = true;
            this.cmblocsv.Location = new System.Drawing.Point(546, 30);
            this.cmblocsv.Margin = new System.Windows.Forms.Padding(4);
            this.cmblocsv.Name = "cmblocsv";
            this.cmblocsv.Size = new System.Drawing.Size(160, 37);
            this.cmblocsv.TabIndex = 2;
            this.cmblocsv.SelectedIndexChanged += new System.EventHandler(this.cmblocsv_SelectedIndexChanged);
            // 
            // lbllocsv
            // 
            this.lbllocsv.AutoSize = true;
            this.lbllocsv.Location = new System.Drawing.Point(429, 36);
            this.lbllocsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbllocsv.Name = "lbllocsv";
            this.lbllocsv.Size = new System.Drawing.Size(97, 29);
            this.lbllocsv.TabIndex = 1;
            this.lbllocsv.Text = "Môn thi:";
            this.lbllocsv.Click += new System.EventHandler(this.lblloc_Click);
            // 
            // txttimsv
            // 
            this.txttimsv.Location = new System.Drawing.Point(64, 38);
            this.txttimsv.Margin = new System.Windows.Forms.Padding(4);
            this.txttimsv.Name = "txttimsv";
            this.txttimsv.Size = new System.Drawing.Size(333, 34);
            this.txttimsv.TabIndex = 0;
            this.txttimsv.TextChanged += new System.EventHandler(this.txttimsv_TextChanged);
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.picmonthi);
            this.panel1.Controls.Add(this.piccauhoi);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1886, 120);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(194, 93);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bài tập";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(33, 94);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Điểm danh";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // picmonthi
            // 
            this.picmonthi.BackColor = System.Drawing.Color.White;
            this.picmonthi.Image = ((System.Drawing.Image)(resources.GetObject("picmonthi.Image")));
            this.picmonthi.Location = new System.Drawing.Point(190, 14);
            this.picmonthi.Margin = new System.Windows.Forms.Padding(4);
            this.picmonthi.Name = "picmonthi";
            this.picmonthi.Size = new System.Drawing.Size(82, 74);
            this.picmonthi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picmonthi.TabIndex = 2;
            this.picmonthi.TabStop = false;
            this.picmonthi.Click += new System.EventHandler(this.picmonthi_Click);
            // 
            // piccauhoi
            // 
            this.piccauhoi.BackColor = System.Drawing.Color.White;
            this.piccauhoi.Image = ((System.Drawing.Image)(resources.GetObject("piccauhoi.Image")));
            this.piccauhoi.Location = new System.Drawing.Point(50, 14);
            this.piccauhoi.Margin = new System.Windows.Forms.Padding(4);
            this.piccauhoi.Name = "piccauhoi";
            this.piccauhoi.Size = new System.Drawing.Size(82, 76);
            this.piccauhoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.piccauhoi.TabIndex = 0;
            this.piccauhoi.TabStop = false;
            this.piccauhoi.Click += new System.EventHandler(this.piccauhoi_Click);
            // 
            // tHITRACNGHIEMDataSetBindingSource
            // 
            this.tHITRACNGHIEMDataSetBindingSource.DataSource = this.tHITRACNGHIEMDataSet;
            this.tHITRACNGHIEMDataSetBindingSource.Position = 0;
            this.tHITRACNGHIEMDataSetBindingSource.CurrentChanged += new System.EventHandler(this.tHITRACNGHIEMDataSetBindingSource_CurrentChanged);
            // 
            // tHITRACNGHIEMDataSet
            // 
            this.tHITRACNGHIEMDataSet.DataSetName = "THITRACNGHIEMDataSet";
            this.tHITRACNGHIEMDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabquanly);
            this.tabControl1.Controls.Add(this.tabbaocao);
            this.tabControl1.Controls.Add(this.tabphanhoi);
            this.tabControl1.Controls.Add(this.tabtrogiup);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(20, 60);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1902, 886);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabphanhoi
            // 
            this.tabphanhoi.Controls.Add(this.panel5);
            this.tabphanhoi.Controls.Add(this.panel4);
            this.tabphanhoi.Location = new System.Drawing.Point(4, 38);
            this.tabphanhoi.Name = "tabphanhoi";
            this.tabphanhoi.Size = new System.Drawing.Size(1894, 844);
            this.tabphanhoi.TabIndex = 3;
            this.tabphanhoi.Text = "Phản hồi";
            this.tabphanhoi.UseVisualStyleBackColor = true;
            this.tabphanhoi.Click += new System.EventHandler(this.tabphanhoi_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.grbphanhoisv_dgv);
            this.panel5.Controls.Add(this.grbphanhoisv);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 119);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1894, 725);
            this.panel5.TabIndex = 2;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // grbphanhoisv_dgv
            // 
            this.grbphanhoisv_dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbphanhoisv_dgv.Controls.Add(this.dgvphanhoisv);
            this.grbphanhoisv_dgv.Location = new System.Drawing.Point(3, 0);
            this.grbphanhoisv_dgv.Name = "grbphanhoisv_dgv";
            this.grbphanhoisv_dgv.Size = new System.Drawing.Size(948, 719);
            this.grbphanhoisv_dgv.TabIndex = 1;
            this.grbphanhoisv_dgv.TabStop = false;
            this.grbphanhoisv_dgv.Text = "groupBox1";
            this.grbphanhoisv_dgv.Enter += new System.EventHandler(this.grbphanhoidgv_Enter);
            // 
            // dgvphanhoisv
            // 
            this.dgvphanhoisv.AllowUserToDeleteRows = false;
            this.dgvphanhoisv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvphanhoisv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvphanhoisv.BackgroundColor = System.Drawing.Color.White;
            this.dgvphanhoisv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvphanhoisv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvphanhoisv.Location = new System.Drawing.Point(3, 30);
            this.dgvphanhoisv.Margin = new System.Windows.Forms.Padding(4);
            this.dgvphanhoisv.Name = "dgvphanhoisv";
            this.dgvphanhoisv.ReadOnly = true;
            this.dgvphanhoisv.RowHeadersWidth = 51;
            this.dgvphanhoisv.Size = new System.Drawing.Size(942, 686);
            this.dgvphanhoisv.TabIndex = 1;
            this.dgvphanhoisv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_phanhoi_CellClick);
            // 
            // grbphanhoisv
            // 
            this.grbphanhoisv.Controls.Add(this.txtmon_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.lblmon_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.btnthem_phanhoi);
            this.grbphanhoisv.Controls.Add(this.btnhuy_phanhoi);
            this.grbphanhoisv.Controls.Add(this.btngui_phanhoi);
            this.grbphanhoisv.Controls.Add(this.btnExit_phanhoi);
            this.grbphanhoisv.Controls.Add(this.txtngay_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.txtlop_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.txtten_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.txthodem_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.txtmssv_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.txtnoidung_phanhoisv);
            this.grbphanhoisv.Controls.Add(this.lblnoidung_phanhoi);
            this.grbphanhoisv.Controls.Add(this.lbllop_phanhoi);
            this.grbphanhoisv.Controls.Add(this.lblngay_phanhoi);
            this.grbphanhoisv.Controls.Add(this.lblten_phanhoi);
            this.grbphanhoisv.Controls.Add(this.lblhodem_phanhoi);
            this.grbphanhoisv.Controls.Add(this.lblmssv_phahoi);
            this.grbphanhoisv.Controls.Add(this.txtnoidunggui_phanhoi);
            this.grbphanhoisv.Dock = System.Windows.Forms.DockStyle.Right;
            this.grbphanhoisv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbphanhoisv.Location = new System.Drawing.Point(957, 0);
            this.grbphanhoisv.Name = "grbphanhoisv";
            this.grbphanhoisv.Size = new System.Drawing.Size(937, 725);
            this.grbphanhoisv.TabIndex = 1;
            this.grbphanhoisv.TabStop = false;
            this.grbphanhoisv.Text = "Chi tiết thông tin";
            this.grbphanhoisv.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtmon_phanhoisv
            // 
            this.txtmon_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmon_phanhoisv.Location = new System.Drawing.Point(282, 246);
            this.txtmon_phanhoisv.Name = "txtmon_phanhoisv";
            this.txtmon_phanhoisv.Size = new System.Drawing.Size(204, 30);
            this.txtmon_phanhoisv.TabIndex = 69;
            // 
            // lblmon_phanhoisv
            // 
            this.lblmon_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmon_phanhoisv.AutoSize = true;
            this.lblmon_phanhoisv.Location = new System.Drawing.Point(134, 251);
            this.lblmon_phanhoisv.Name = "lblmon_phanhoisv";
            this.lblmon_phanhoisv.Size = new System.Drawing.Size(57, 25);
            this.lblmon_phanhoisv.TabIndex = 68;
            this.lblmon_phanhoisv.Text = "Môn:";
            // 
            // btnthem_phanhoi
            // 
            this.btnthem_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnthem_phanhoi.BackColor = System.Drawing.Color.White;
            this.btnthem_phanhoi.BackgroundColor = System.Drawing.Color.White;
            this.btnthem_phanhoi.BorderColor = System.Drawing.Color.Black;
            this.btnthem_phanhoi.BorderRadius = 20;
            this.btnthem_phanhoi.BorderSize = 2;
            this.btnthem_phanhoi.FlatAppearance.BorderSize = 0;
            this.btnthem_phanhoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnthem_phanhoi.ForeColor = System.Drawing.Color.Black;
            this.btnthem_phanhoi.Location = new System.Drawing.Point(138, 633);
            this.btnthem_phanhoi.Name = "btnthem_phanhoi";
            this.btnthem_phanhoi.Size = new System.Drawing.Size(107, 62);
            this.btnthem_phanhoi.TabIndex = 66;
            this.btnthem_phanhoi.Text = "Thêm";
            this.btnthem_phanhoi.TextColor = System.Drawing.Color.Black;
            this.btnthem_phanhoi.UseVisualStyleBackColor = false;
            this.btnthem_phanhoi.Click += new System.EventHandler(this.btnthem_phanhoi_Click);
            // 
            // btnhuy_phanhoi
            // 
            this.btnhuy_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnhuy_phanhoi.BackColor = System.Drawing.Color.White;
            this.btnhuy_phanhoi.BackgroundColor = System.Drawing.Color.White;
            this.btnhuy_phanhoi.BorderColor = System.Drawing.Color.Black;
            this.btnhuy_phanhoi.BorderRadius = 20;
            this.btnhuy_phanhoi.BorderSize = 2;
            this.btnhuy_phanhoi.FlatAppearance.BorderSize = 0;
            this.btnhuy_phanhoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnhuy_phanhoi.ForeColor = System.Drawing.Color.Black;
            this.btnhuy_phanhoi.Location = new System.Drawing.Point(649, 632);
            this.btnhuy_phanhoi.Name = "btnhuy_phanhoi";
            this.btnhuy_phanhoi.Size = new System.Drawing.Size(107, 62);
            this.btnhuy_phanhoi.TabIndex = 65;
            this.btnhuy_phanhoi.Text = "Hủy";
            this.btnhuy_phanhoi.TextColor = System.Drawing.Color.Black;
            this.btnhuy_phanhoi.UseVisualStyleBackColor = false;
            this.btnhuy_phanhoi.Click += new System.EventHandler(this.btnhuy_phanhoi_Click);
            // 
            // btngui_phanhoi
            // 
            this.btngui_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btngui_phanhoi.BackColor = System.Drawing.Color.White;
            this.btngui_phanhoi.BackgroundColor = System.Drawing.Color.White;
            this.btngui_phanhoi.BorderColor = System.Drawing.Color.Black;
            this.btngui_phanhoi.BorderRadius = 20;
            this.btngui_phanhoi.BorderSize = 2;
            this.btngui_phanhoi.FlatAppearance.BorderSize = 0;
            this.btngui_phanhoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngui_phanhoi.ForeColor = System.Drawing.Color.Black;
            this.btngui_phanhoi.Location = new System.Drawing.Point(460, 559);
            this.btngui_phanhoi.Name = "btngui_phanhoi";
            this.btngui_phanhoi.Size = new System.Drawing.Size(107, 62);
            this.btngui_phanhoi.TabIndex = 62;
            this.btngui_phanhoi.Text = "Gửi";
            this.btngui_phanhoi.TextColor = System.Drawing.Color.Black;
            this.btngui_phanhoi.UseVisualStyleBackColor = false;
            this.btngui_phanhoi.Click += new System.EventHandler(this.btngui_phanhoi_Click);
            // 
            // btnExit_phanhoi
            // 
            this.btnExit_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExit_phanhoi.BackColor = System.Drawing.Color.White;
            this.btnExit_phanhoi.BackgroundColor = System.Drawing.Color.White;
            this.btnExit_phanhoi.BorderColor = System.Drawing.Color.Black;
            this.btnExit_phanhoi.BorderRadius = 20;
            this.btnExit_phanhoi.BorderSize = 2;
            this.btnExit_phanhoi.FlatAppearance.BorderSize = 0;
            this.btnExit_phanhoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit_phanhoi.ForeColor = System.Drawing.Color.Black;
            this.btnExit_phanhoi.Location = new System.Drawing.Point(763, 633);
            this.btnExit_phanhoi.Name = "btnExit_phanhoi";
            this.btnExit_phanhoi.Size = new System.Drawing.Size(107, 62);
            this.btnExit_phanhoi.TabIndex = 61;
            this.btnExit_phanhoi.Text = "Thoát";
            this.btnExit_phanhoi.TextColor = System.Drawing.Color.Black;
            this.btnExit_phanhoi.UseVisualStyleBackColor = false;
            // 
            // txtngay_phanhoisv
            // 
            this.txtngay_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtngay_phanhoisv.Location = new System.Drawing.Point(282, 293);
            this.txtngay_phanhoisv.Name = "txtngay_phanhoisv";
            this.txtngay_phanhoisv.Size = new System.Drawing.Size(338, 30);
            this.txtngay_phanhoisv.TabIndex = 20;
            // 
            // txtlop_phanhoisv
            // 
            this.txtlop_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtlop_phanhoisv.Location = new System.Drawing.Point(282, 199);
            this.txtlop_phanhoisv.Name = "txtlop_phanhoisv";
            this.txtlop_phanhoisv.Size = new System.Drawing.Size(204, 30);
            this.txtlop_phanhoisv.TabIndex = 11;
            // 
            // txtten_phanhoisv
            // 
            this.txtten_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtten_phanhoisv.Location = new System.Drawing.Point(282, 146);
            this.txtten_phanhoisv.Name = "txtten_phanhoisv";
            this.txtten_phanhoisv.Size = new System.Drawing.Size(204, 30);
            this.txtten_phanhoisv.TabIndex = 10;
            // 
            // txthodem_phanhoisv
            // 
            this.txthodem_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txthodem_phanhoisv.Location = new System.Drawing.Point(282, 94);
            this.txthodem_phanhoisv.Name = "txthodem_phanhoisv";
            this.txthodem_phanhoisv.Size = new System.Drawing.Size(338, 30);
            this.txthodem_phanhoisv.TabIndex = 9;
            // 
            // txtmssv_phanhoisv
            // 
            this.txtmssv_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmssv_phanhoisv.Location = new System.Drawing.Point(282, 37);
            this.txtmssv_phanhoisv.Name = "txtmssv_phanhoisv";
            this.txtmssv_phanhoisv.Size = new System.Drawing.Size(338, 30);
            this.txtmssv_phanhoisv.TabIndex = 8;
            // 
            // txtnoidung_phanhoisv
            // 
            this.txtnoidung_phanhoisv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtnoidung_phanhoisv.BackColor = System.Drawing.Color.White;
            this.txtnoidung_phanhoisv.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoidung_phanhoisv.Location = new System.Drawing.Point(138, 384);
            this.txtnoidung_phanhoisv.Name = "txtnoidung_phanhoisv";
            this.txtnoidung_phanhoisv.Size = new System.Drawing.Size(759, 163);
            this.txtnoidung_phanhoisv.TabIndex = 7;
            this.txtnoidung_phanhoisv.Text = "";
            // 
            // lblnoidung_phanhoi
            // 
            this.lblnoidung_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblnoidung_phanhoi.AutoSize = true;
            this.lblnoidung_phanhoi.Location = new System.Drawing.Point(132, 350);
            this.lblnoidung_phanhoi.Name = "lblnoidung_phanhoi";
            this.lblnoidung_phanhoi.Size = new System.Drawing.Size(96, 25);
            this.lblnoidung_phanhoi.TabIndex = 6;
            this.lblnoidung_phanhoi.Text = "Nội dung:";
            // 
            // lbllop_phanhoi
            // 
            this.lbllop_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbllop_phanhoi.AutoSize = true;
            this.lbllop_phanhoi.Location = new System.Drawing.Point(134, 201);
            this.lbllop_phanhoi.Name = "lbllop_phanhoi";
            this.lbllop_phanhoi.Size = new System.Drawing.Size(51, 25);
            this.lbllop_phanhoi.TabIndex = 5;
            this.lbllop_phanhoi.Text = "Lớp:";
            // 
            // lblngay_phanhoi
            // 
            this.lblngay_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblngay_phanhoi.AutoSize = true;
            this.lblngay_phanhoi.Location = new System.Drawing.Point(132, 295);
            this.lblngay_phanhoi.Name = "lblngay_phanhoi";
            this.lblngay_phanhoi.Size = new System.Drawing.Size(64, 25);
            this.lblngay_phanhoi.TabIndex = 4;
            this.lblngay_phanhoi.Text = "Ngày:";
            // 
            // lblten_phanhoi
            // 
            this.lblten_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblten_phanhoi.AutoSize = true;
            this.lblten_phanhoi.Location = new System.Drawing.Point(132, 149);
            this.lblten_phanhoi.Name = "lblten_phanhoi";
            this.lblten_phanhoi.Size = new System.Drawing.Size(53, 25);
            this.lblten_phanhoi.TabIndex = 2;
            this.lblten_phanhoi.Text = "Tên:";
            // 
            // lblhodem_phanhoi
            // 
            this.lblhodem_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblhodem_phanhoi.AutoSize = true;
            this.lblhodem_phanhoi.Location = new System.Drawing.Point(131, 96);
            this.lblhodem_phanhoi.Name = "lblhodem_phanhoi";
            this.lblhodem_phanhoi.Size = new System.Drawing.Size(86, 25);
            this.lblhodem_phanhoi.TabIndex = 1;
            this.lblhodem_phanhoi.Text = "Họ đệm:";
            // 
            // lblmssv_phahoi
            // 
            this.lblmssv_phahoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmssv_phahoi.AutoSize = true;
            this.lblmssv_phahoi.Location = new System.Drawing.Point(132, 42);
            this.lblmssv_phahoi.Name = "lblmssv_phahoi";
            this.lblmssv_phahoi.Size = new System.Drawing.Size(77, 25);
            this.lblmssv_phahoi.TabIndex = 0;
            this.lblmssv_phahoi.Text = "MSSV:";
            // 
            // txtnoidunggui_phanhoi
            // 
            this.txtnoidunggui_phanhoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtnoidunggui_phanhoi.Location = new System.Drawing.Point(136, 130);
            this.txtnoidunggui_phanhoi.Name = "txtnoidunggui_phanhoi";
            this.txtnoidunggui_phanhoi.Size = new System.Drawing.Size(761, 396);
            this.txtnoidunggui_phanhoi.TabIndex = 67;
            this.txtnoidunggui_phanhoi.Text = "";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Controls.Add(this.grbtimphanhoi);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.picsphanhoi);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1894, 119);
            this.panel4.TabIndex = 0;
            // 
            // grbtimphanhoi
            // 
            this.grbtimphanhoi.Controls.Add(this.dtptimkiem_phanhoisv);
            this.grbtimphanhoi.Controls.Add(this.label20);
            this.grbtimphanhoi.Controls.Add(this.txttimkiemlop_phanhoisv);
            this.grbtimphanhoi.Controls.Add(this.label17);
            this.grbtimphanhoi.Controls.Add(this.txttimkiemmon_phanhoisv);
            this.grbtimphanhoi.Controls.Add(this.label18);
            this.grbtimphanhoi.Location = new System.Drawing.Point(208, 4);
            this.grbtimphanhoi.Margin = new System.Windows.Forms.Padding(4);
            this.grbtimphanhoi.Name = "grbtimphanhoi";
            this.grbtimphanhoi.Padding = new System.Windows.Forms.Padding(4);
            this.grbtimphanhoi.Size = new System.Drawing.Size(776, 103);
            this.grbtimphanhoi.TabIndex = 6;
            this.grbtimphanhoi.TabStop = false;
            this.grbtimphanhoi.Text = "Tìm kiếm";
            // 
            // dtptimkiem_phanhoisv
            // 
            this.dtptimkiem_phanhoisv.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptimkiem_phanhoisv.Location = new System.Drawing.Point(582, 43);
            this.dtptimkiem_phanhoisv.Name = "dtptimkiem_phanhoisv";
            this.dtptimkiem_phanhoisv.Size = new System.Drawing.Size(172, 34);
            this.dtptimkiem_phanhoisv.TabIndex = 15;
            this.dtptimkiem_phanhoisv.Value = new System.DateTime(2024, 9, 25, 13, 51, 17, 0);
            this.dtptimkiem_phanhoisv.ValueChanged += new System.EventHandler(this.dtptimkiem_phanhoisv_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(490, 48);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 25);
            this.label20.TabIndex = 14;
            this.label20.Text = "Ngày:";
            // 
            // txttimkiemlop_phanhoisv
            // 
            this.txttimkiemlop_phanhoisv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttimkiemlop_phanhoisv.Location = new System.Drawing.Point(356, 46);
            this.txttimkiemlop_phanhoisv.Margin = new System.Windows.Forms.Padding(4);
            this.txttimkiemlop_phanhoisv.Name = "txttimkiemlop_phanhoisv";
            this.txttimkiemlop_phanhoisv.Size = new System.Drawing.Size(107, 30);
            this.txttimkiemlop_phanhoisv.TabIndex = 13;
            this.txttimkiemlop_phanhoisv.TextChanged += new System.EventHandler(this.txttimkiemlop_phanhoisv_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(293, 46);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 25);
            this.label17.TabIndex = 12;
            this.label17.Text = "Lớp:";
            // 
            // txttimkiemmon_phanhoisv
            // 
            this.txttimkiemmon_phanhoisv.DisplayMember = "Tenmon";
            this.txttimkiemmon_phanhoisv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttimkiemmon_phanhoisv.FormattingEnabled = true;
            this.txttimkiemmon_phanhoisv.Items.AddRange(new object[] {
            "Tin"});
            this.txttimkiemmon_phanhoisv.Location = new System.Drawing.Point(153, 46);
            this.txttimkiemmon_phanhoisv.Margin = new System.Windows.Forms.Padding(4);
            this.txttimkiemmon_phanhoisv.Name = "txttimkiemmon_phanhoisv";
            this.txttimkiemmon_phanhoisv.Size = new System.Drawing.Size(132, 31);
            this.txttimkiemmon_phanhoisv.TabIndex = 7;
            this.txttimkiemmon_phanhoisv.ValueMember = "Tenmon";
            this.txttimkiemmon_phanhoisv.SelectedIndexChanged += new System.EventHandler(this.txttimkiemmon_phanhoisv_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(46, 46);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(105, 25);
            this.label18.TabIndex = 6;
            this.label18.Text = "Môn Học:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(69, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 25);
            this.label16.TabIndex = 1;
            this.label16.Text = "Phản hồi";
            // 
            // picsphanhoi
            // 
            this.picsphanhoi.BackColor = System.Drawing.Color.White;
            this.picsphanhoi.Image = ((System.Drawing.Image)(resources.GetObject("picsphanhoi.Image")));
            this.picsphanhoi.Location = new System.Drawing.Point(66, 12);
            this.picsphanhoi.Name = "picsphanhoi";
            this.picsphanhoi.Size = new System.Drawing.Size(100, 69);
            this.picsphanhoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picsphanhoi.TabIndex = 0;
            this.picsphanhoi.TabStop = false;
            this.picsphanhoi.Click += new System.EventHandler(this.picsphanhoi_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RefreshDatasv,
            this.ExitToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(128, 52);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // RefreshDatasv
            // 
            this.RefreshDatasv.Name = "RefreshDatasv";
            this.RefreshDatasv.Size = new System.Drawing.Size(127, 24);
            this.RefreshDatasv.Text = "Refresh";
            this.RefreshDatasv.Click += new System.EventHandler(this.RefreshDatasv_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(127, 24);
            this.ExitToolStripMenuItem.Text = "Exit";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.thoátChươngTrìnhToolStripMenuItem_Click);
            // 
            // mONTHIBindingSource
            // 
            this.mONTHIBindingSource.DataSource = this.tHITRACNGHIEMDataSetBindingSource;
            this.mONTHIBindingSource.Position = 0;
            this.mONTHIBindingSource.CurrentChanged += new System.EventHandler(this.mONTHIBindingSource_CurrentChanged);
            // 
            // mONTHITableAdapter
            // 
            this.mONTHITableAdapter.ClearBeforeFill = true;
            // 
            // gvTableAdapter1
            // 
            this.gvTableAdapter1.ClearBeforeFill = true;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(61, 4);
            // 
            // cAUHOIBindingSource
            // 
            this.cAUHOIBindingSource.DataMember = "CAUHOI";
            this.cAUHOIBindingSource.DataSource = this.tHITRACNGHIEMDataSetBindingSource;
            // 
            // cAUHOITableAdapter
            // 
            this.cAUHOITableAdapter.ClearBeforeFill = true;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.BalloonTipShown += new System.EventHandler(this.notifyIcon1_BalloonTipShown);
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.Color.SkyBlue;
            this.panel6.Controls.Add(this.btnbclop);
            this.panel6.Controls.Add(this.btnbcmon);
            this.panel6.Location = new System.Drawing.Point(1651, 132);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(239, 763);
            this.panel6.TabIndex = 3;
            // 
            // frmsv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1942, 966);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmsv";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmsv_Load);
            this.tabtrogiup.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabbaocao.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvbc_sv)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grbtim.ResumeLayout(false);
            this.grbtim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbaithi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbangdiem)).EndInit();
            this.tabquanly.ResumeLayout(false);
            this.tabquanly.PerformLayout();
            this.panelcauhoi.ResumeLayout(false);
            this.grbchitietch.ResumeLayout(false);
            this.grbchitietch.PerformLayout();
            this.grbdiemdanh.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvdiemdanhsv)).EndInit();
            this.grbtimch.ResumeLayout(false);
            this.grbtimch.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picmonthi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccauhoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSet)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabphanhoi.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.grbphanhoisv_dgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvphanhoisv)).EndInit();
            this.grbphanhoisv.ResumeLayout(false);
            this.grbphanhoisv.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.grbtimphanhoi.ResumeLayout(false);
            this.grbtimphanhoi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsphanhoi)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mONTHIBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAUHOIBindingSource)).EndInit();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabtrogiup;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel linkthemsv;
        private System.Windows.Forms.LinkLabel linktimmt;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.LinkLabel linkxoasv;
        private System.Windows.Forms.LinkLabel linksuasv;
        private System.Windows.Forms.LinkLabel linktimsv;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.LinkLabel linkxoamt;
        private System.Windows.Forms.LinkLabel linksuamt;
        private System.Windows.Forms.LinkLabel linkthemmt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.LinkLabel linkxoach;
        private System.Windows.Forms.LinkLabel linksuach;
        private System.Windows.Forms.LinkLabel linkthemch;
        private System.Windows.Forms.LinkLabel linktimch;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbltrogiup;
        private System.Windows.Forms.TabPage tabbaocao;
        private System.Windows.Forms.DataGridView dgvbc_sv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox grbtim;
        private RJButton btnbclop;
        private System.Windows.Forms.ComboBox cmbtenmonsv;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox picbaithi;
        private System.Windows.Forms.PictureBox picbangdiem;
        private System.Windows.Forms.TabPage tabquanly;
        private System.Windows.Forms.Panel panelcauhoi;
        private System.Windows.Forms.GroupBox grbchitietch;
        private System.Windows.Forms.TextBox txtmaphien;
        private System.Windows.Forms.Label lblmaphien;
        private System.Windows.Forms.TextBox txttenmonsv;
        private System.Windows.Forms.Label lbltenmon;
        private System.Windows.Forms.TextBox txtmach;
        private System.Windows.Forms.TextBox txttenlopsv;
        private System.Windows.Forms.Label lbltenlop;
        private System.Windows.Forms.GroupBox grbdiemdanh;
        private System.Windows.Forms.DataGridView dgvdiemdanhsv;
        private System.Windows.Forms.GroupBox grbtimch;
        private System.Windows.Forms.ComboBox cmblocsv;
        private System.Windows.Forms.Label lbllocsv;
        private System.Windows.Forms.TextBox txttimsv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picmonthi;
        private System.Windows.Forms.PictureBox piccauhoi;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMalopsv;
        private RJButton btnbcmon;
        private System.Windows.Forms.BindingSource tHITRACNGHIEMDataSetBindingSource;
        private THITRACNGHIEMDataSet tHITRACNGHIEMDataSet;
        private System.Windows.Forms.BindingSource mONTHIBindingSource;
        private THITRACNGHIEMDataSetTableAdapters.MONTHITableAdapter mONTHITableAdapter;
        private System.Windows.Forms.TabControl tabControl1;
        private THITRACNGHIEMDataSetTableAdapters.GVTableAdapter gvTableAdapter1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.BindingSource cAUHOIBindingSource;
        private THITRACNGHIEMDataSetTableAdapters.CAUHOITableAdapter cAUHOITableAdapter;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.TabPage tabphanhoi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbltrangthai;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox grbphanhoisv;
        private System.Windows.Forms.Label lblnoidung_phanhoi;
        private System.Windows.Forms.Label lblngay_phanhoi;
        private System.Windows.Forms.Label lblmssv_phahoi;
        private System.Windows.Forms.TextBox txtmssv_phanhoisv;
        private System.Windows.Forms.RichTextBox txtnoidung_phanhoisv;
        private System.Windows.Forms.ToolStripMenuItem RefreshDatasv;
        private RJButton btnxacnhan;
        private RJButton btnExit;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox picsphanhoi;
        private System.Windows.Forms.GroupBox grbtimphanhoi;
        private System.Windows.Forms.TextBox txttimkiemlop_phanhoisv;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox txttimkiemmon_phanhoisv;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtngay_phanhoisv;
        private System.Windows.Forms.DateTimePicker dtptimkiem_phanhoisv;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox grbphanhoisv_dgv;
        private System.Windows.Forms.DataGridView dgvphanhoisv;
        private System.Windows.Forms.Label lblngaytaophien;
        private System.Windows.Forms.TextBox txttrangthai;
        private System.Windows.Forms.TextBox txtngaytaophien;
        private RJButton btnlambai;
        private System.Windows.Forms.TextBox txtsolan;
        private System.Windows.Forms.Label lblsolan;
        private RJButton btnthem_phanhoi;
        private RJButton btnhuy_phanhoi;
        private RJButton btngui_phanhoi;
        private RJButton btnExit_phanhoi;
        private System.Windows.Forms.TextBox txtlop_phanhoisv;
        private System.Windows.Forms.TextBox txtten_phanhoisv;
        private System.Windows.Forms.TextBox txthodem_phanhoisv;
        private System.Windows.Forms.Label lbllop_phanhoi;
        private System.Windows.Forms.Label lblten_phanhoi;
        private System.Windows.Forms.Label lblhodem_phanhoi;
        private System.Windows.Forms.RichTextBox txtnoidunggui_phanhoi;
        private System.Windows.Forms.DateTimePicker dpttimkiembaocao_sv;
        private System.Windows.Forms.Label lblngaytimkiembaocao_sv;
        private System.Windows.Forms.TextBox txtmon_phanhoisv;
        private System.Windows.Forms.Label lblmon_phanhoisv;
        private System.Windows.Forms.Panel panel6;
    }
}