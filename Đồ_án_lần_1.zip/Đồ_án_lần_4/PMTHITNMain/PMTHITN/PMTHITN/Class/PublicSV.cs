﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace PMTHITN.Class
{
    public struct thongtinsv
    {   
        public static string MSV;
        public static string MATKHAU;
    }
    public struct thongtingv
    {
        public static string MGV;
        public static string MATKHAU;
    }
    public struct dulieu
    {
        public static int TONGSOCAU;
        public static string MAMONTHI;
    }
    public struct dethi
    {
        public static SqlDataAdapter DAP;
    }
    public class PublicSV
    {

    }
    public struct Report
    {
        public static string MaSV;
        public static string MaL;
        public static string TenM;
    }
}
