﻿namespace PMTHITN
{
    partial class frmbaithi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.ckbdatco40 = new System.Windows.Forms.CheckBox();
            this.ckbdatco39 = new System.Windows.Forms.CheckBox();
            this.ckbdatco38 = new System.Windows.Forms.CheckBox();
            this.ckbdatco37 = new System.Windows.Forms.CheckBox();
            this.ckbdatco36 = new System.Windows.Forms.CheckBox();
            this.ckbdatco35 = new System.Windows.Forms.CheckBox();
            this.ckbdatco34 = new System.Windows.Forms.CheckBox();
            this.ckbdatco33 = new System.Windows.Forms.CheckBox();
            this.ckbdatco32 = new System.Windows.Forms.CheckBox();
            this.ckbdatco31 = new System.Windows.Forms.CheckBox();
            this.ckbdatco30 = new System.Windows.Forms.CheckBox();
            this.ckbdatco29 = new System.Windows.Forms.CheckBox();
            this.ckbdatco28 = new System.Windows.Forms.CheckBox();
            this.ckbdatco27 = new System.Windows.Forms.CheckBox();
            this.ckbdatco26 = new System.Windows.Forms.CheckBox();
            this.ckbdatco25 = new System.Windows.Forms.CheckBox();
            this.ckbdatco24 = new System.Windows.Forms.CheckBox();
            this.ckbdatco23 = new System.Windows.Forms.CheckBox();
            this.ckbdatco22 = new System.Windows.Forms.CheckBox();
            this.ckbdatco21 = new System.Windows.Forms.CheckBox();
            this.ckbdatco19 = new System.Windows.Forms.CheckBox();
            this.ckbdatco20 = new System.Windows.Forms.CheckBox();
            this.ckbdatco18 = new System.Windows.Forms.CheckBox();
            this.lblthongbaohetgio = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ckbdatco17 = new System.Windows.Forms.CheckBox();
            this.ckbdatco3 = new System.Windows.Forms.CheckBox();
            this.ckbdatco16 = new System.Windows.Forms.CheckBox();
            this.ckbdatco13 = new System.Windows.Forms.CheckBox();
            this.ckbdatco15 = new System.Windows.Forms.CheckBox();
            this.ckbdatco14 = new System.Windows.Forms.CheckBox();
            this.ckbdatco12 = new System.Windows.Forms.CheckBox();
            this.ckbdatco11 = new System.Windows.Forms.CheckBox();
            this.ckbdatco10 = new System.Windows.Forms.CheckBox();
            this.ckbdatco9 = new System.Windows.Forms.CheckBox();
            this.ckbdatco8 = new System.Windows.Forms.CheckBox();
            this.ckbdatco7 = new System.Windows.Forms.CheckBox();
            this.ckbdatco6 = new System.Windows.Forms.CheckBox();
            this.ckbdatco5 = new System.Windows.Forms.CheckBox();
            this.ckbdatco4 = new System.Windows.Forms.CheckBox();
            this.ckbdatco2 = new System.Windows.Forms.CheckBox();
            this.ckbdatco1 = new System.Windows.Forms.CheckBox();
            this.grbnoidung = new System.Windows.Forms.GroupBox();
            this.lblnoidungcauhoi = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.lblthoigian = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.lblsocau = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblmonthi = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblgiay = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblphut = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblmsv = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.lblhoten = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.tableLayoutPanelcaform = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelcot2 = new System.Windows.Forms.TableLayoutPanel();
            this.tbl40 = new System.Windows.Forms.TableLayoutPanel();
            this.rd44d = new System.Windows.Forms.RadioButton();
            this.rd44a = new System.Windows.Forms.RadioButton();
            this.panel67 = new System.Windows.Forms.Panel();
            this.lbl40 = new System.Windows.Forms.Label();
            this.rd44c = new System.Windows.Forms.RadioButton();
            this.rd44b = new System.Windows.Forms.RadioButton();
            this.tbl39 = new System.Windows.Forms.TableLayoutPanel();
            this.rd43d = new System.Windows.Forms.RadioButton();
            this.rd43c = new System.Windows.Forms.RadioButton();
            this.rd43b = new System.Windows.Forms.RadioButton();
            this.rd43a = new System.Windows.Forms.RadioButton();
            this.panel68 = new System.Windows.Forms.Panel();
            this.lbl39 = new System.Windows.Forms.Label();
            this.tbl42 = new System.Windows.Forms.TableLayoutPanel();
            this.rd42d = new System.Windows.Forms.RadioButton();
            this.rd42c = new System.Windows.Forms.RadioButton();
            this.rd42b = new System.Windows.Forms.RadioButton();
            this.rd42a = new System.Windows.Forms.RadioButton();
            this.panel69 = new System.Windows.Forms.Panel();
            this.lbl38 = new System.Windows.Forms.Label();
            this.tbl37 = new System.Windows.Forms.TableLayoutPanel();
            this.rd41d = new System.Windows.Forms.RadioButton();
            this.rd41c = new System.Windows.Forms.RadioButton();
            this.rd41b = new System.Windows.Forms.RadioButton();
            this.rd41a = new System.Windows.Forms.RadioButton();
            this.panel70 = new System.Windows.Forms.Panel();
            this.lbl37 = new System.Windows.Forms.Label();
            this.tbl36 = new System.Windows.Forms.TableLayoutPanel();
            this.rd40d = new System.Windows.Forms.RadioButton();
            this.rd40c = new System.Windows.Forms.RadioButton();
            this.rd40b = new System.Windows.Forms.RadioButton();
            this.rd40a = new System.Windows.Forms.RadioButton();
            this.panel71 = new System.Windows.Forms.Panel();
            this.lbl36 = new System.Windows.Forms.Label();
            this.tbl35 = new System.Windows.Forms.TableLayoutPanel();
            this.rd39d = new System.Windows.Forms.RadioButton();
            this.rd39c = new System.Windows.Forms.RadioButton();
            this.rd39b = new System.Windows.Forms.RadioButton();
            this.rd39a = new System.Windows.Forms.RadioButton();
            this.panel72 = new System.Windows.Forms.Panel();
            this.lbl35 = new System.Windows.Forms.Label();
            this.tbl38 = new System.Windows.Forms.TableLayoutPanel();
            this.rd38d = new System.Windows.Forms.RadioButton();
            this.rd38c = new System.Windows.Forms.RadioButton();
            this.rd38b = new System.Windows.Forms.RadioButton();
            this.rd38a = new System.Windows.Forms.RadioButton();
            this.panel73 = new System.Windows.Forms.Panel();
            this.lbl34 = new System.Windows.Forms.Label();
            this.tbl33 = new System.Windows.Forms.TableLayoutPanel();
            this.rd37d = new System.Windows.Forms.RadioButton();
            this.rd37c = new System.Windows.Forms.RadioButton();
            this.rd37b = new System.Windows.Forms.RadioButton();
            this.rd37 = new System.Windows.Forms.RadioButton();
            this.panel74 = new System.Windows.Forms.Panel();
            this.lbl33 = new System.Windows.Forms.Label();
            this.tbl32 = new System.Windows.Forms.TableLayoutPanel();
            this.rd36d = new System.Windows.Forms.RadioButton();
            this.rd36c = new System.Windows.Forms.RadioButton();
            this.rd36b = new System.Windows.Forms.RadioButton();
            this.rd36aa = new System.Windows.Forms.RadioButton();
            this.panel75 = new System.Windows.Forms.Panel();
            this.lbl32 = new System.Windows.Forms.Label();
            this.tbl31 = new System.Windows.Forms.TableLayoutPanel();
            this.rd35d = new System.Windows.Forms.RadioButton();
            this.rd35c = new System.Windows.Forms.RadioButton();
            this.rd35b = new System.Windows.Forms.RadioButton();
            this.rd35a = new System.Windows.Forms.RadioButton();
            this.panel76 = new System.Windows.Forms.Panel();
            this.lbl31 = new System.Windows.Forms.Label();
            this.tbl34 = new System.Windows.Forms.TableLayoutPanel();
            this.rd34d = new System.Windows.Forms.RadioButton();
            this.rd34c = new System.Windows.Forms.RadioButton();
            this.rd34b = new System.Windows.Forms.RadioButton();
            this.rd34a = new System.Windows.Forms.RadioButton();
            this.panel77 = new System.Windows.Forms.Panel();
            this.lbl30 = new System.Windows.Forms.Label();
            this.tbl29 = new System.Windows.Forms.TableLayoutPanel();
            this.rd33d = new System.Windows.Forms.RadioButton();
            this.rd33c = new System.Windows.Forms.RadioButton();
            this.rd33b = new System.Windows.Forms.RadioButton();
            this.rd33a = new System.Windows.Forms.RadioButton();
            this.panel78 = new System.Windows.Forms.Panel();
            this.lbl29 = new System.Windows.Forms.Label();
            this.tbl28 = new System.Windows.Forms.TableLayoutPanel();
            this.rd32d = new System.Windows.Forms.RadioButton();
            this.rd32c = new System.Windows.Forms.RadioButton();
            this.rd32b = new System.Windows.Forms.RadioButton();
            this.rd32a = new System.Windows.Forms.RadioButton();
            this.panel79 = new System.Windows.Forms.Panel();
            this.lbl28 = new System.Windows.Forms.Label();
            this.tbl27 = new System.Windows.Forms.TableLayoutPanel();
            this.rd31d = new System.Windows.Forms.RadioButton();
            this.rd31c = new System.Windows.Forms.RadioButton();
            this.rd31b = new System.Windows.Forms.RadioButton();
            this.rd31a = new System.Windows.Forms.RadioButton();
            this.panel80 = new System.Windows.Forms.Panel();
            this.lbl27 = new System.Windows.Forms.Label();
            this.tbl30 = new System.Windows.Forms.TableLayoutPanel();
            this.rd30d = new System.Windows.Forms.RadioButton();
            this.rd30c = new System.Windows.Forms.RadioButton();
            this.rd30b = new System.Windows.Forms.RadioButton();
            this.rd30a = new System.Windows.Forms.RadioButton();
            this.panel81 = new System.Windows.Forms.Panel();
            this.lbl26 = new System.Windows.Forms.Label();
            this.tbl25 = new System.Windows.Forms.TableLayoutPanel();
            this.rd29d = new System.Windows.Forms.RadioButton();
            this.rd29c = new System.Windows.Forms.RadioButton();
            this.rd29b = new System.Windows.Forms.RadioButton();
            this.rd29a = new System.Windows.Forms.RadioButton();
            this.panel82 = new System.Windows.Forms.Panel();
            this.lbl25 = new System.Windows.Forms.Label();
            this.tbl24 = new System.Windows.Forms.TableLayoutPanel();
            this.rd28d = new System.Windows.Forms.RadioButton();
            this.rd28c = new System.Windows.Forms.RadioButton();
            this.rd28b = new System.Windows.Forms.RadioButton();
            this.rd28a = new System.Windows.Forms.RadioButton();
            this.panel83 = new System.Windows.Forms.Panel();
            this.lbl24 = new System.Windows.Forms.Label();
            this.tbl23 = new System.Windows.Forms.TableLayoutPanel();
            this.rd27d = new System.Windows.Forms.RadioButton();
            this.rd27c = new System.Windows.Forms.RadioButton();
            this.rd27b = new System.Windows.Forms.RadioButton();
            this.rd27a = new System.Windows.Forms.RadioButton();
            this.panel84 = new System.Windows.Forms.Panel();
            this.lbl23 = new System.Windows.Forms.Label();
            this.tbl22 = new System.Windows.Forms.TableLayoutPanel();
            this.rd26d = new System.Windows.Forms.RadioButton();
            this.rd26c = new System.Windows.Forms.RadioButton();
            this.rd26b = new System.Windows.Forms.RadioButton();
            this.rd26a = new System.Windows.Forms.RadioButton();
            this.panel85 = new System.Windows.Forms.Panel();
            this.lbl22 = new System.Windows.Forms.Label();
            this.tbl21 = new System.Windows.Forms.TableLayoutPanel();
            this.rd25d = new System.Windows.Forms.RadioButton();
            this.rd25c = new System.Windows.Forms.RadioButton();
            this.rd25b = new System.Windows.Forms.RadioButton();
            this.rd25a = new System.Windows.Forms.RadioButton();
            this.panel86 = new System.Windows.Forms.Panel();
            this.lbl21 = new System.Windows.Forms.Label();
            this.panel87 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel79 = new System.Windows.Forms.TableLayoutPanel();
            this.panel88 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel89 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel90 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel91 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.panel93 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanelcot1 = new System.Windows.Forms.TableLayoutPanel();
            this.tbl20 = new System.Windows.Forms.TableLayoutPanel();
            this.rd20d = new System.Windows.Forms.RadioButton();
            this.rd20c = new System.Windows.Forms.RadioButton();
            this.rd20b = new System.Windows.Forms.RadioButton();
            this.rd20a = new System.Windows.Forms.RadioButton();
            this.panel27 = new System.Windows.Forms.Panel();
            this.lbl20 = new System.Windows.Forms.Label();
            this.tbl19 = new System.Windows.Forms.TableLayoutPanel();
            this.rd19d = new System.Windows.Forms.RadioButton();
            this.rd19c = new System.Windows.Forms.RadioButton();
            this.rd19b = new System.Windows.Forms.RadioButton();
            this.rd19a = new System.Windows.Forms.RadioButton();
            this.panel26 = new System.Windows.Forms.Panel();
            this.lbl19 = new System.Windows.Forms.Label();
            this.tbl18 = new System.Windows.Forms.TableLayoutPanel();
            this.rd18d = new System.Windows.Forms.RadioButton();
            this.rd18c = new System.Windows.Forms.RadioButton();
            this.rd18b = new System.Windows.Forms.RadioButton();
            this.rd18a = new System.Windows.Forms.RadioButton();
            this.panel25 = new System.Windows.Forms.Panel();
            this.lbl18 = new System.Windows.Forms.Label();
            this.tbl17 = new System.Windows.Forms.TableLayoutPanel();
            this.rd17d = new System.Windows.Forms.RadioButton();
            this.rd17c = new System.Windows.Forms.RadioButton();
            this.rd17b = new System.Windows.Forms.RadioButton();
            this.rd17a = new System.Windows.Forms.RadioButton();
            this.panel24 = new System.Windows.Forms.Panel();
            this.lbl17 = new System.Windows.Forms.Label();
            this.tbl16 = new System.Windows.Forms.TableLayoutPanel();
            this.rd16d = new System.Windows.Forms.RadioButton();
            this.rd16c = new System.Windows.Forms.RadioButton();
            this.rd16b = new System.Windows.Forms.RadioButton();
            this.rd16a = new System.Windows.Forms.RadioButton();
            this.panel23 = new System.Windows.Forms.Panel();
            this.lbl16 = new System.Windows.Forms.Label();
            this.tbl15 = new System.Windows.Forms.TableLayoutPanel();
            this.rd15d = new System.Windows.Forms.RadioButton();
            this.rd15c = new System.Windows.Forms.RadioButton();
            this.rd15b = new System.Windows.Forms.RadioButton();
            this.rd15a = new System.Windows.Forms.RadioButton();
            this.panel22 = new System.Windows.Forms.Panel();
            this.lbl15 = new System.Windows.Forms.Label();
            this.tbl14 = new System.Windows.Forms.TableLayoutPanel();
            this.rd14d = new System.Windows.Forms.RadioButton();
            this.rd14c = new System.Windows.Forms.RadioButton();
            this.rd14b = new System.Windows.Forms.RadioButton();
            this.rd14a = new System.Windows.Forms.RadioButton();
            this.panel21 = new System.Windows.Forms.Panel();
            this.lbl14 = new System.Windows.Forms.Label();
            this.tbl13 = new System.Windows.Forms.TableLayoutPanel();
            this.rd13d = new System.Windows.Forms.RadioButton();
            this.rd13c = new System.Windows.Forms.RadioButton();
            this.rd13b = new System.Windows.Forms.RadioButton();
            this.rd13a = new System.Windows.Forms.RadioButton();
            this.panel20 = new System.Windows.Forms.Panel();
            this.lbl13 = new System.Windows.Forms.Label();
            this.tbl12 = new System.Windows.Forms.TableLayoutPanel();
            this.rd12d = new System.Windows.Forms.RadioButton();
            this.rd12c = new System.Windows.Forms.RadioButton();
            this.rd12b = new System.Windows.Forms.RadioButton();
            this.rd12a = new System.Windows.Forms.RadioButton();
            this.panel19 = new System.Windows.Forms.Panel();
            this.lbl12 = new System.Windows.Forms.Label();
            this.tbl11 = new System.Windows.Forms.TableLayoutPanel();
            this.rd11d = new System.Windows.Forms.RadioButton();
            this.rd11c = new System.Windows.Forms.RadioButton();
            this.rd11b = new System.Windows.Forms.RadioButton();
            this.rd11a = new System.Windows.Forms.RadioButton();
            this.panel18 = new System.Windows.Forms.Panel();
            this.lbl11 = new System.Windows.Forms.Label();
            this.tbl10 = new System.Windows.Forms.TableLayoutPanel();
            this.rd10d = new System.Windows.Forms.RadioButton();
            this.rd10c = new System.Windows.Forms.RadioButton();
            this.rd10b = new System.Windows.Forms.RadioButton();
            this.rd10a = new System.Windows.Forms.RadioButton();
            this.panel17 = new System.Windows.Forms.Panel();
            this.lbl10 = new System.Windows.Forms.Label();
            this.tbl9 = new System.Windows.Forms.TableLayoutPanel();
            this.rd9d = new System.Windows.Forms.RadioButton();
            this.rd9c = new System.Windows.Forms.RadioButton();
            this.rd9b = new System.Windows.Forms.RadioButton();
            this.rd9a = new System.Windows.Forms.RadioButton();
            this.panel16 = new System.Windows.Forms.Panel();
            this.lbl9 = new System.Windows.Forms.Label();
            this.tbl8 = new System.Windows.Forms.TableLayoutPanel();
            this.rd8d = new System.Windows.Forms.RadioButton();
            this.rd8c = new System.Windows.Forms.RadioButton();
            this.rd8b = new System.Windows.Forms.RadioButton();
            this.rd8a = new System.Windows.Forms.RadioButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lbl8 = new System.Windows.Forms.Label();
            this.tbl7 = new System.Windows.Forms.TableLayoutPanel();
            this.rd7d = new System.Windows.Forms.RadioButton();
            this.rd7c = new System.Windows.Forms.RadioButton();
            this.rd7b = new System.Windows.Forms.RadioButton();
            this.rd7a = new System.Windows.Forms.RadioButton();
            this.panel14 = new System.Windows.Forms.Panel();
            this.lbl7 = new System.Windows.Forms.Label();
            this.tbl6 = new System.Windows.Forms.TableLayoutPanel();
            this.rd6d = new System.Windows.Forms.RadioButton();
            this.rd6c = new System.Windows.Forms.RadioButton();
            this.rd6b = new System.Windows.Forms.RadioButton();
            this.rd6a = new System.Windows.Forms.RadioButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lbl6 = new System.Windows.Forms.Label();
            this.tbl5 = new System.Windows.Forms.TableLayoutPanel();
            this.rd5d = new System.Windows.Forms.RadioButton();
            this.rd5c = new System.Windows.Forms.RadioButton();
            this.rd5b = new System.Windows.Forms.RadioButton();
            this.rd5a = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbl5 = new System.Windows.Forms.Label();
            this.tbl4 = new System.Windows.Forms.TableLayoutPanel();
            this.rd4d = new System.Windows.Forms.RadioButton();
            this.rd4c = new System.Windows.Forms.RadioButton();
            this.rd4b = new System.Windows.Forms.RadioButton();
            this.rd4a = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbl4 = new System.Windows.Forms.Label();
            this.tbl3 = new System.Windows.Forms.TableLayoutPanel();
            this.rd3d = new System.Windows.Forms.RadioButton();
            this.rd3c = new System.Windows.Forms.RadioButton();
            this.rd3b = new System.Windows.Forms.RadioButton();
            this.rd3a = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl3 = new System.Windows.Forms.Label();
            this.tbl2 = new System.Windows.Forms.TableLayoutPanel();
            this.rd2d = new System.Windows.Forms.RadioButton();
            this.rd2c = new System.Windows.Forms.RadioButton();
            this.rd2b = new System.Windows.Forms.RadioButton();
            this.rd2a = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl2 = new System.Windows.Forms.Label();
            this.tbl1 = new System.Windows.Forms.TableLayoutPanel();
            this.rd1d = new System.Windows.Forms.RadioButton();
            this.rd1c = new System.Windows.Forms.RadioButton();
            this.rd1b = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl1 = new System.Windows.Forms.Label();
            this.rd1a = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btndone = new PMTHITN.RJButton();
            this.btnnext = new PMTHITN.RJButton();
            this.btnback = new PMTHITN.RJButton();
            this.panel1.SuspendLayout();
            this.grbnoidung.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanelcaform.SuspendLayout();
            this.tableLayoutPanelcot2.SuspendLayout();
            this.tbl40.SuspendLayout();
            this.panel67.SuspendLayout();
            this.tbl39.SuspendLayout();
            this.panel68.SuspendLayout();
            this.tbl42.SuspendLayout();
            this.panel69.SuspendLayout();
            this.tbl37.SuspendLayout();
            this.panel70.SuspendLayout();
            this.tbl36.SuspendLayout();
            this.panel71.SuspendLayout();
            this.tbl35.SuspendLayout();
            this.panel72.SuspendLayout();
            this.tbl38.SuspendLayout();
            this.panel73.SuspendLayout();
            this.tbl33.SuspendLayout();
            this.panel74.SuspendLayout();
            this.tbl32.SuspendLayout();
            this.panel75.SuspendLayout();
            this.tbl31.SuspendLayout();
            this.panel76.SuspendLayout();
            this.tbl34.SuspendLayout();
            this.panel77.SuspendLayout();
            this.tbl29.SuspendLayout();
            this.panel78.SuspendLayout();
            this.tbl28.SuspendLayout();
            this.panel79.SuspendLayout();
            this.tbl27.SuspendLayout();
            this.panel80.SuspendLayout();
            this.tbl30.SuspendLayout();
            this.panel81.SuspendLayout();
            this.tbl25.SuspendLayout();
            this.panel82.SuspendLayout();
            this.tbl24.SuspendLayout();
            this.panel83.SuspendLayout();
            this.tbl23.SuspendLayout();
            this.panel84.SuspendLayout();
            this.tbl22.SuspendLayout();
            this.panel85.SuspendLayout();
            this.tbl21.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel87.SuspendLayout();
            this.tableLayoutPanel79.SuspendLayout();
            this.panel88.SuspendLayout();
            this.panel89.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel93.SuspendLayout();
            this.tableLayoutPanelcot1.SuspendLayout();
            this.tbl20.SuspendLayout();
            this.panel27.SuspendLayout();
            this.tbl19.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tbl18.SuspendLayout();
            this.panel25.SuspendLayout();
            this.tbl17.SuspendLayout();
            this.panel24.SuspendLayout();
            this.tbl16.SuspendLayout();
            this.panel23.SuspendLayout();
            this.tbl15.SuspendLayout();
            this.panel22.SuspendLayout();
            this.tbl14.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tbl13.SuspendLayout();
            this.panel20.SuspendLayout();
            this.tbl12.SuspendLayout();
            this.panel19.SuspendLayout();
            this.tbl11.SuspendLayout();
            this.panel18.SuspendLayout();
            this.tbl10.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tbl9.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tbl8.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tbl7.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tbl6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tbl5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tbl4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tbl3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tbl2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tbl1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel32.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel1.Controls.Add(this.ckbdatco40);
            this.panel1.Controls.Add(this.ckbdatco39);
            this.panel1.Controls.Add(this.ckbdatco38);
            this.panel1.Controls.Add(this.ckbdatco37);
            this.panel1.Controls.Add(this.ckbdatco36);
            this.panel1.Controls.Add(this.ckbdatco35);
            this.panel1.Controls.Add(this.ckbdatco34);
            this.panel1.Controls.Add(this.ckbdatco33);
            this.panel1.Controls.Add(this.ckbdatco32);
            this.panel1.Controls.Add(this.ckbdatco31);
            this.panel1.Controls.Add(this.ckbdatco30);
            this.panel1.Controls.Add(this.ckbdatco29);
            this.panel1.Controls.Add(this.ckbdatco28);
            this.panel1.Controls.Add(this.ckbdatco27);
            this.panel1.Controls.Add(this.ckbdatco26);
            this.panel1.Controls.Add(this.ckbdatco25);
            this.panel1.Controls.Add(this.ckbdatco24);
            this.panel1.Controls.Add(this.ckbdatco23);
            this.panel1.Controls.Add(this.ckbdatco22);
            this.panel1.Controls.Add(this.ckbdatco21);
            this.panel1.Controls.Add(this.ckbdatco19);
            this.panel1.Controls.Add(this.ckbdatco20);
            this.panel1.Controls.Add(this.ckbdatco18);
            this.panel1.Controls.Add(this.lblthongbaohetgio);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.ckbdatco17);
            this.panel1.Controls.Add(this.ckbdatco3);
            this.panel1.Controls.Add(this.ckbdatco16);
            this.panel1.Controls.Add(this.ckbdatco13);
            this.panel1.Controls.Add(this.ckbdatco15);
            this.panel1.Controls.Add(this.ckbdatco14);
            this.panel1.Controls.Add(this.ckbdatco12);
            this.panel1.Controls.Add(this.ckbdatco11);
            this.panel1.Controls.Add(this.ckbdatco10);
            this.panel1.Controls.Add(this.ckbdatco9);
            this.panel1.Controls.Add(this.ckbdatco8);
            this.panel1.Controls.Add(this.ckbdatco7);
            this.panel1.Controls.Add(this.ckbdatco6);
            this.panel1.Controls.Add(this.ckbdatco5);
            this.panel1.Controls.Add(this.ckbdatco4);
            this.panel1.Controls.Add(this.ckbdatco2);
            this.panel1.Controls.Add(this.ckbdatco1);
            this.panel1.Controls.Add(this.btndone);
            this.panel1.Controls.Add(this.btnnext);
            this.panel1.Controls.Add(this.grbnoidung);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.btnback);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1168, 913);
            this.panel1.TabIndex = 35;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // ckbdatco40
            // 
            this.ckbdatco40.AutoSize = true;
            this.ckbdatco40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco40.Location = new System.Drawing.Point(1066, 211);
            this.ckbdatco40.Name = "ckbdatco40";
            this.ckbdatco40.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco40.TabIndex = 79;
            this.ckbdatco40.Text = "Đặt cờ";
            this.ckbdatco40.UseVisualStyleBackColor = false;
            this.ckbdatco40.CheckedChanged += new System.EventHandler(this.ckbdatco40_CheckedChanged);
            // 
            // ckbdatco39
            // 
            this.ckbdatco39.AutoSize = true;
            this.ckbdatco39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco39.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco39.Name = "ckbdatco39";
            this.ckbdatco39.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco39.TabIndex = 78;
            this.ckbdatco39.Text = "Đặt cờ";
            this.ckbdatco39.UseVisualStyleBackColor = false;
            this.ckbdatco39.CheckedChanged += new System.EventHandler(this.ckbdatco39_CheckedChanged);
            // 
            // ckbdatco38
            // 
            this.ckbdatco38.AutoSize = true;
            this.ckbdatco38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco38.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco38.Name = "ckbdatco38";
            this.ckbdatco38.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco38.TabIndex = 77;
            this.ckbdatco38.Text = "Đặt cờ";
            this.ckbdatco38.UseVisualStyleBackColor = false;
            this.ckbdatco38.CheckedChanged += new System.EventHandler(this.ckbdatco38_CheckedChanged);
            // 
            // ckbdatco37
            // 
            this.ckbdatco37.AutoSize = true;
            this.ckbdatco37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco37.Location = new System.Drawing.Point(1065, 214);
            this.ckbdatco37.Name = "ckbdatco37";
            this.ckbdatco37.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco37.TabIndex = 76;
            this.ckbdatco37.Text = "Đặt cờ";
            this.ckbdatco37.UseVisualStyleBackColor = false;
            this.ckbdatco37.CheckedChanged += new System.EventHandler(this.ckbdatco37_CheckedChanged);
            // 
            // ckbdatco36
            // 
            this.ckbdatco36.AutoSize = true;
            this.ckbdatco36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco36.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco36.Name = "ckbdatco36";
            this.ckbdatco36.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco36.TabIndex = 75;
            this.ckbdatco36.Text = "Đặt cờ";
            this.ckbdatco36.UseVisualStyleBackColor = false;
            this.ckbdatco36.CheckedChanged += new System.EventHandler(this.ckbdatco36_CheckedChanged);
            // 
            // ckbdatco35
            // 
            this.ckbdatco35.AutoSize = true;
            this.ckbdatco35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco35.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco35.Name = "ckbdatco35";
            this.ckbdatco35.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco35.TabIndex = 74;
            this.ckbdatco35.Text = "Đặt cờ";
            this.ckbdatco35.UseVisualStyleBackColor = false;
            this.ckbdatco35.CheckedChanged += new System.EventHandler(this.ckbdatco35_CheckedChanged);
            // 
            // ckbdatco34
            // 
            this.ckbdatco34.AutoSize = true;
            this.ckbdatco34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco34.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco34.Name = "ckbdatco34";
            this.ckbdatco34.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco34.TabIndex = 73;
            this.ckbdatco34.Text = "Đặt cờ";
            this.ckbdatco34.UseVisualStyleBackColor = false;
            this.ckbdatco34.CheckedChanged += new System.EventHandler(this.ckbdatco34_CheckedChanged);
            // 
            // ckbdatco33
            // 
            this.ckbdatco33.AutoSize = true;
            this.ckbdatco33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco33.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco33.Name = "ckbdatco33";
            this.ckbdatco33.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco33.TabIndex = 72;
            this.ckbdatco33.Text = "Đặt cờ";
            this.ckbdatco33.UseVisualStyleBackColor = false;
            this.ckbdatco33.CheckedChanged += new System.EventHandler(this.ckbdatco33_CheckedChanged);
            // 
            // ckbdatco32
            // 
            this.ckbdatco32.AutoSize = true;
            this.ckbdatco32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco32.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco32.Name = "ckbdatco32";
            this.ckbdatco32.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco32.TabIndex = 71;
            this.ckbdatco32.Text = "Đặt cờ";
            this.ckbdatco32.UseVisualStyleBackColor = false;
            this.ckbdatco32.CheckedChanged += new System.EventHandler(this.ckbdatco32_CheckedChanged);
            // 
            // ckbdatco31
            // 
            this.ckbdatco31.AutoSize = true;
            this.ckbdatco31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco31.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco31.Name = "ckbdatco31";
            this.ckbdatco31.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco31.TabIndex = 70;
            this.ckbdatco31.Text = "Đặt cờ";
            this.ckbdatco31.UseVisualStyleBackColor = false;
            this.ckbdatco31.CheckedChanged += new System.EventHandler(this.ckbdatco31_CheckedChanged);
            // 
            // ckbdatco30
            // 
            this.ckbdatco30.AutoSize = true;
            this.ckbdatco30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco30.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco30.Name = "ckbdatco30";
            this.ckbdatco30.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco30.TabIndex = 69;
            this.ckbdatco30.Text = "Đặt cờ";
            this.ckbdatco30.UseVisualStyleBackColor = false;
            this.ckbdatco30.CheckedChanged += new System.EventHandler(this.ckbdatco30_CheckedChanged);
            // 
            // ckbdatco29
            // 
            this.ckbdatco29.AutoSize = true;
            this.ckbdatco29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco29.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco29.Name = "ckbdatco29";
            this.ckbdatco29.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco29.TabIndex = 68;
            this.ckbdatco29.Text = "Đặt cờ";
            this.ckbdatco29.UseVisualStyleBackColor = false;
            this.ckbdatco29.CheckedChanged += new System.EventHandler(this.ckbdatco29_CheckedChanged);
            // 
            // ckbdatco28
            // 
            this.ckbdatco28.AutoSize = true;
            this.ckbdatco28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco28.Location = new System.Drawing.Point(1065, 214);
            this.ckbdatco28.Name = "ckbdatco28";
            this.ckbdatco28.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco28.TabIndex = 67;
            this.ckbdatco28.Text = "Đặt cờ";
            this.ckbdatco28.UseVisualStyleBackColor = false;
            this.ckbdatco28.CheckedChanged += new System.EventHandler(this.ckbdatco28_CheckedChanged);
            // 
            // ckbdatco27
            // 
            this.ckbdatco27.AutoSize = true;
            this.ckbdatco27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco27.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco27.Name = "ckbdatco27";
            this.ckbdatco27.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco27.TabIndex = 66;
            this.ckbdatco27.Text = "Đặt cờ";
            this.ckbdatco27.UseVisualStyleBackColor = false;
            this.ckbdatco27.CheckedChanged += new System.EventHandler(this.ckbdatco27_CheckedChanged);
            // 
            // ckbdatco26
            // 
            this.ckbdatco26.AutoSize = true;
            this.ckbdatco26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco26.Location = new System.Drawing.Point(1065, 210);
            this.ckbdatco26.Name = "ckbdatco26";
            this.ckbdatco26.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco26.TabIndex = 65;
            this.ckbdatco26.Text = "Đặt cờ";
            this.ckbdatco26.UseVisualStyleBackColor = false;
            this.ckbdatco26.CheckedChanged += new System.EventHandler(this.ckbdatco26_CheckedChanged);
            // 
            // ckbdatco25
            // 
            this.ckbdatco25.AutoSize = true;
            this.ckbdatco25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco25.Location = new System.Drawing.Point(1065, 214);
            this.ckbdatco25.Name = "ckbdatco25";
            this.ckbdatco25.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco25.TabIndex = 64;
            this.ckbdatco25.Text = "Đặt cờ";
            this.ckbdatco25.UseVisualStyleBackColor = false;
            this.ckbdatco25.CheckedChanged += new System.EventHandler(this.ckbdatco25_CheckedChanged);
            // 
            // ckbdatco24
            // 
            this.ckbdatco24.AutoSize = true;
            this.ckbdatco24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco24.Location = new System.Drawing.Point(1065, 214);
            this.ckbdatco24.Name = "ckbdatco24";
            this.ckbdatco24.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco24.TabIndex = 63;
            this.ckbdatco24.Text = "Đặt cờ";
            this.ckbdatco24.UseVisualStyleBackColor = false;
            this.ckbdatco24.CheckedChanged += new System.EventHandler(this.ckbdatco24_CheckedChanged);
            // 
            // ckbdatco23
            // 
            this.ckbdatco23.AutoSize = true;
            this.ckbdatco23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco23.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco23.Name = "ckbdatco23";
            this.ckbdatco23.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco23.TabIndex = 62;
            this.ckbdatco23.Text = "Đặt cờ";
            this.ckbdatco23.UseVisualStyleBackColor = false;
            this.ckbdatco23.CheckedChanged += new System.EventHandler(this.ckbdatco23_CheckedChanged);
            // 
            // ckbdatco22
            // 
            this.ckbdatco22.AutoSize = true;
            this.ckbdatco22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco22.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco22.Name = "ckbdatco22";
            this.ckbdatco22.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco22.TabIndex = 61;
            this.ckbdatco22.Text = "Đặt cờ";
            this.ckbdatco22.UseVisualStyleBackColor = false;
            this.ckbdatco22.CheckedChanged += new System.EventHandler(this.ckbdatco22_CheckedChanged);
            // 
            // ckbdatco21
            // 
            this.ckbdatco21.AutoSize = true;
            this.ckbdatco21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco21.Location = new System.Drawing.Point(1065, 214);
            this.ckbdatco21.Name = "ckbdatco21";
            this.ckbdatco21.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco21.TabIndex = 60;
            this.ckbdatco21.Text = "Đặt cờ";
            this.ckbdatco21.UseVisualStyleBackColor = false;
            this.ckbdatco21.CheckedChanged += new System.EventHandler(this.ckbdatco21_CheckedChanged);
            // 
            // ckbdatco19
            // 
            this.ckbdatco19.AutoSize = true;
            this.ckbdatco19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco19.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco19.Name = "ckbdatco19";
            this.ckbdatco19.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco19.TabIndex = 59;
            this.ckbdatco19.Text = "Đặt cờ";
            this.ckbdatco19.UseVisualStyleBackColor = false;
            this.ckbdatco19.CheckedChanged += new System.EventHandler(this.ckbdatco19_CheckedChanged);
            // 
            // ckbdatco20
            // 
            this.ckbdatco20.AutoSize = true;
            this.ckbdatco20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco20.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco20.Name = "ckbdatco20";
            this.ckbdatco20.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco20.TabIndex = 58;
            this.ckbdatco20.Text = "Đặt cờ";
            this.ckbdatco20.UseVisualStyleBackColor = false;
            this.ckbdatco20.CheckedChanged += new System.EventHandler(this.ckbdatco20_CheckedChanged);
            // 
            // ckbdatco18
            // 
            this.ckbdatco18.AutoSize = true;
            this.ckbdatco18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco18.Location = new System.Drawing.Point(1065, 212);
            this.ckbdatco18.Name = "ckbdatco18";
            this.ckbdatco18.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco18.TabIndex = 57;
            this.ckbdatco18.Text = "Đặt cờ";
            this.ckbdatco18.UseVisualStyleBackColor = false;
            this.ckbdatco18.CheckedChanged += new System.EventHandler(this.ckbdatco18_CheckedChanged);
            // 
            // lblthongbaohetgio
            // 
            this.lblthongbaohetgio.AutoSize = true;
            this.lblthongbaohetgio.BackColor = System.Drawing.Color.Transparent;
            this.lblthongbaohetgio.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblthongbaohetgio.ForeColor = System.Drawing.Color.Black;
            this.lblthongbaohetgio.Location = new System.Drawing.Point(292, 197);
            this.lblthongbaohetgio.Name = "lblthongbaohetgio";
            this.lblthongbaohetgio.Size = new System.Drawing.Size(519, 32);
            this.lblthongbaohetgio.TabIndex = 56;
            this.lblthongbaohetgio.Text = "Chỉ còn 5 phút nữa là hết giờ làm bài!";
            this.lblthongbaohetgio.Visible = false;
            this.lblthongbaohetgio.Click += new System.EventHandler(this.lblthongbaohetgio_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(976, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 55;
            this.label2.Text = "Chọn câu";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // ckbdatco17
            // 
            this.ckbdatco17.AutoSize = true;
            this.ckbdatco17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco17.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco17.Name = "ckbdatco17";
            this.ckbdatco17.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco17.TabIndex = 54;
            this.ckbdatco17.Text = "Đặt cờ";
            this.ckbdatco17.UseVisualStyleBackColor = false;
            this.ckbdatco17.CheckedChanged += new System.EventHandler(this.ckbdatco17_CheckedChanged);
            // 
            // ckbdatco3
            // 
            this.ckbdatco3.AutoSize = true;
            this.ckbdatco3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco3.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco3.Name = "ckbdatco3";
            this.ckbdatco3.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco3.TabIndex = 40;
            this.ckbdatco3.Text = "Đặt cờ";
            this.ckbdatco3.UseVisualStyleBackColor = false;
            this.ckbdatco3.CheckedChanged += new System.EventHandler(this.ckbdatco3_CheckedChanged);
            // 
            // ckbdatco16
            // 
            this.ckbdatco16.AutoSize = true;
            this.ckbdatco16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco16.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco16.Name = "ckbdatco16";
            this.ckbdatco16.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco16.TabIndex = 53;
            this.ckbdatco16.Text = "Đặt cờ";
            this.ckbdatco16.UseVisualStyleBackColor = false;
            this.ckbdatco16.CheckedChanged += new System.EventHandler(this.ckbdatco16_CheckedChanged);
            // 
            // ckbdatco13
            // 
            this.ckbdatco13.AutoSize = true;
            this.ckbdatco13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco13.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco13.Name = "ckbdatco13";
            this.ckbdatco13.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco13.TabIndex = 50;
            this.ckbdatco13.Text = "Đặt cờ";
            this.ckbdatco13.UseVisualStyleBackColor = false;
            this.ckbdatco13.CheckedChanged += new System.EventHandler(this.ckbdatco13_CheckedChanged);
            // 
            // ckbdatco15
            // 
            this.ckbdatco15.AutoSize = true;
            this.ckbdatco15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco15.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco15.Name = "ckbdatco15";
            this.ckbdatco15.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco15.TabIndex = 52;
            this.ckbdatco15.Text = "Đặt cờ";
            this.ckbdatco15.UseVisualStyleBackColor = false;
            this.ckbdatco15.CheckedChanged += new System.EventHandler(this.ckbdatco15_CheckedChanged);
            // 
            // ckbdatco14
            // 
            this.ckbdatco14.AutoSize = true;
            this.ckbdatco14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco14.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco14.Name = "ckbdatco14";
            this.ckbdatco14.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco14.TabIndex = 51;
            this.ckbdatco14.Text = "Đặt cờ";
            this.ckbdatco14.UseVisualStyleBackColor = false;
            this.ckbdatco14.CheckedChanged += new System.EventHandler(this.ckbdatco14_CheckedChanged);
            // 
            // ckbdatco12
            // 
            this.ckbdatco12.AutoSize = true;
            this.ckbdatco12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco12.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco12.Name = "ckbdatco12";
            this.ckbdatco12.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco12.TabIndex = 49;
            this.ckbdatco12.Text = "Đặt cờ";
            this.ckbdatco12.UseVisualStyleBackColor = false;
            this.ckbdatco12.CheckedChanged += new System.EventHandler(this.ckbdatco12_CheckedChanged);
            // 
            // ckbdatco11
            // 
            this.ckbdatco11.AutoSize = true;
            this.ckbdatco11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco11.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco11.Name = "ckbdatco11";
            this.ckbdatco11.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco11.TabIndex = 48;
            this.ckbdatco11.Text = "Đặt cờ";
            this.ckbdatco11.UseVisualStyleBackColor = false;
            this.ckbdatco11.CheckedChanged += new System.EventHandler(this.ckbdatco11_CheckedChanged);
            // 
            // ckbdatco10
            // 
            this.ckbdatco10.AutoSize = true;
            this.ckbdatco10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco10.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco10.Name = "ckbdatco10";
            this.ckbdatco10.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco10.TabIndex = 47;
            this.ckbdatco10.Text = "Đặt cờ";
            this.ckbdatco10.UseVisualStyleBackColor = false;
            this.ckbdatco10.CheckedChanged += new System.EventHandler(this.ckbdatco10_CheckedChanged);
            // 
            // ckbdatco9
            // 
            this.ckbdatco9.AutoSize = true;
            this.ckbdatco9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco9.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco9.Name = "ckbdatco9";
            this.ckbdatco9.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco9.TabIndex = 46;
            this.ckbdatco9.Text = "Đặt cờ";
            this.ckbdatco9.UseVisualStyleBackColor = false;
            this.ckbdatco9.CheckedChanged += new System.EventHandler(this.ckbdatco9_CheckedChanged);
            // 
            // ckbdatco8
            // 
            this.ckbdatco8.AutoSize = true;
            this.ckbdatco8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco8.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco8.Name = "ckbdatco8";
            this.ckbdatco8.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco8.TabIndex = 45;
            this.ckbdatco8.Text = "Đặt cờ";
            this.ckbdatco8.UseVisualStyleBackColor = false;
            this.ckbdatco8.CheckedChanged += new System.EventHandler(this.ckbdatco8_CheckedChanged);
            // 
            // ckbdatco7
            // 
            this.ckbdatco7.AutoSize = true;
            this.ckbdatco7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco7.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco7.Name = "ckbdatco7";
            this.ckbdatco7.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco7.TabIndex = 44;
            this.ckbdatco7.Text = "Đặt cờ";
            this.ckbdatco7.UseVisualStyleBackColor = false;
            this.ckbdatco7.CheckedChanged += new System.EventHandler(this.ckbdatco7_CheckedChanged);
            // 
            // ckbdatco6
            // 
            this.ckbdatco6.AutoSize = true;
            this.ckbdatco6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco6.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco6.Name = "ckbdatco6";
            this.ckbdatco6.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco6.TabIndex = 43;
            this.ckbdatco6.Text = "Đặt cờ";
            this.ckbdatco6.UseVisualStyleBackColor = false;
            this.ckbdatco6.CheckedChanged += new System.EventHandler(this.ckbdatco6_CheckedChanged);
            // 
            // ckbdatco5
            // 
            this.ckbdatco5.AutoSize = true;
            this.ckbdatco5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco5.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco5.Name = "ckbdatco5";
            this.ckbdatco5.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco5.TabIndex = 42;
            this.ckbdatco5.Text = "Đặt cờ";
            this.ckbdatco5.UseVisualStyleBackColor = false;
            this.ckbdatco5.CheckedChanged += new System.EventHandler(this.ckbdatco5_CheckedChanged);
            // 
            // ckbdatco4
            // 
            this.ckbdatco4.AutoSize = true;
            this.ckbdatco4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco4.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco4.Name = "ckbdatco4";
            this.ckbdatco4.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco4.TabIndex = 41;
            this.ckbdatco4.Text = "Đặt cờ";
            this.ckbdatco4.UseVisualStyleBackColor = false;
            this.ckbdatco4.CheckedChanged += new System.EventHandler(this.ckbdatco4_CheckedChanged);
            // 
            // ckbdatco2
            // 
            this.ckbdatco2.AutoSize = true;
            this.ckbdatco2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco2.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco2.Name = "ckbdatco2";
            this.ckbdatco2.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco2.TabIndex = 39;
            this.ckbdatco2.Text = "Đặt cờ";
            this.ckbdatco2.UseVisualStyleBackColor = false;
            this.ckbdatco2.CheckedChanged += new System.EventHandler(this.ckbdatco2_CheckedChanged);
            // 
            // ckbdatco1
            // 
            this.ckbdatco1.AutoSize = true;
            this.ckbdatco1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ckbdatco1.Location = new System.Drawing.Point(1065, 211);
            this.ckbdatco1.Name = "ckbdatco1";
            this.ckbdatco1.Size = new System.Drawing.Size(67, 20);
            this.ckbdatco1.TabIndex = 1;
            this.ckbdatco1.Text = "Đặt cờ";
            this.ckbdatco1.UseVisualStyleBackColor = false;
            this.ckbdatco1.CheckedChanged += new System.EventHandler(this.ckbdatco_CheckedChanged);
            // 
            // grbnoidung
            // 
            this.grbnoidung.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.grbnoidung.Controls.Add(this.lblnoidungcauhoi);
            this.grbnoidung.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.grbnoidung.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grbnoidung.Location = new System.Drawing.Point(11, 239);
            this.grbnoidung.Margin = new System.Windows.Forms.Padding(4);
            this.grbnoidung.Name = "grbnoidung";
            this.grbnoidung.Padding = new System.Windows.Forms.Padding(4);
            this.grbnoidung.Size = new System.Drawing.Size(1122, 588);
            this.grbnoidung.TabIndex = 38;
            this.grbnoidung.TabStop = false;
            this.grbnoidung.Text = "Câu số";
            this.grbnoidung.Enter += new System.EventHandler(this.grbnoidung_Enter_1);
            // 
            // lblnoidungcauhoi
            // 
            this.lblnoidungcauhoi.BackColor = System.Drawing.Color.White;
            this.lblnoidungcauhoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblnoidungcauhoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnoidungcauhoi.ForeColor = System.Drawing.Color.Black;
            this.lblnoidungcauhoi.Location = new System.Drawing.Point(4, 27);
            this.lblnoidungcauhoi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnoidungcauhoi.Name = "lblnoidungcauhoi";
            this.lblnoidungcauhoi.Size = new System.Drawing.Size(1114, 557);
            this.lblnoidungcauhoi.TabIndex = 0;
            this.lblnoidungcauhoi.Text = "Nội dung câu hỏi";
            this.lblnoidungcauhoi.Click += new System.EventHandler(this.lblnoidungcauhoi_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label45);
            this.groupBox3.Controls.Add(this.label44);
            this.groupBox3.Controls.Add(this.lblthoigian);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.lblsocau);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.lblmonthi);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox3.Location = new System.Drawing.Point(493, 10);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(373, 158);
            this.groupBox3.TabIndex = 37;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "THÔNG TIN MÔN";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(222, 118);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(39, 29);
            this.label45.TabIndex = 15;
            this.label45.Text = "00";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(212, 118);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(19, 29);
            this.label44.TabIndex = 14;
            this.label44.Text = ":";
            // 
            // lblthoigian
            // 
            this.lblthoigian.AutoSize = true;
            this.lblthoigian.BackColor = System.Drawing.Color.Transparent;
            this.lblthoigian.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblthoigian.ForeColor = System.Drawing.Color.White;
            this.lblthoigian.Location = new System.Drawing.Point(178, 118);
            this.lblthoigian.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblthoigian.Name = "lblthoigian";
            this.lblthoigian.Size = new System.Drawing.Size(39, 29);
            this.lblthoigian.TabIndex = 13;
            this.lblthoigian.Text = "00";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(20, 118);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(120, 29);
            this.label34.TabIndex = 12;
            this.label34.Text = "Thời gian:";
            // 
            // lblsocau
            // 
            this.lblsocau.AutoSize = true;
            this.lblsocau.BackColor = System.Drawing.Color.Transparent;
            this.lblsocau.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsocau.ForeColor = System.Drawing.Color.White;
            this.lblsocau.Location = new System.Drawing.Point(178, 76);
            this.lblsocau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsocau.Name = "lblsocau";
            this.lblsocau.Size = new System.Drawing.Size(39, 29);
            this.lblsocau.TabIndex = 10;
            this.lblsocau.Text = "00";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(20, 76);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(152, 29);
            this.label29.TabIndex = 8;
            this.label29.Text = "Tổng số câu:";
            // 
            // lblmonthi
            // 
            this.lblmonthi.AutoSize = true;
            this.lblmonthi.BackColor = System.Drawing.Color.Transparent;
            this.lblmonthi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmonthi.ForeColor = System.Drawing.Color.White;
            this.lblmonthi.Location = new System.Drawing.Point(140, 34);
            this.lblmonthi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmonthi.Name = "lblmonthi";
            this.lblmonthi.Size = new System.Drawing.Size(103, 29);
            this.lblmonthi.TabIndex = 11;
            this.lblmonthi.Text = "Tenmon";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(20, 34);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(66, 29);
            this.label40.TabIndex = 9;
            this.label40.Text = "Môn:";
            this.label40.Click += new System.EventHandler(this.label40_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblgiay);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.lblphut);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox2.Location = new System.Drawing.Point(855, 12);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(278, 156);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "THỜI GIAN CÒN LẠI";
            // 
            // lblgiay
            // 
            this.lblgiay.AutoSize = true;
            this.lblgiay.BackColor = System.Drawing.Color.Transparent;
            this.lblgiay.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgiay.Location = new System.Drawing.Point(169, 62);
            this.lblgiay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblgiay.Name = "lblgiay";
            this.lblgiay.Size = new System.Drawing.Size(77, 54);
            this.lblgiay.TabIndex = 10;
            this.lblgiay.Text = "00";
            this.lblgiay.Click += new System.EventHandler(this.lblgiay_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(116, 59);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 54);
            this.label3.TabIndex = 9;
            this.label3.Text = ":";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblphut
            // 
            this.lblphut.AutoSize = true;
            this.lblphut.BackColor = System.Drawing.Color.Transparent;
            this.lblphut.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphut.Location = new System.Drawing.Point(18, 62);
            this.lblphut.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblphut.Name = "lblphut";
            this.lblphut.Size = new System.Drawing.Size(77, 54);
            this.lblphut.TabIndex = 8;
            this.lblphut.Text = "00";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblmsv);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.lblhoten);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(18, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(455, 158);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN SINH VIÊN";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lblmsv
            // 
            this.lblmsv.AutoSize = true;
            this.lblmsv.BackColor = System.Drawing.Color.Transparent;
            this.lblmsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsv.ForeColor = System.Drawing.Color.White;
            this.lblmsv.Location = new System.Drawing.Point(94, 41);
            this.lblmsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmsv.Name = "lblmsv";
            this.lblmsv.Size = new System.Drawing.Size(77, 29);
            this.lblmsv.TabIndex = 11;
            this.lblmsv.Text = "MaSV";
            this.lblmsv.Click += new System.EventHandler(this.lblmsv_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(14, 39);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(70, 29);
            this.label37.TabIndex = 10;
            this.label37.Text = "MSV:";
            // 
            // lblhoten
            // 
            this.lblhoten.AutoSize = true;
            this.lblhoten.BackColor = System.Drawing.Color.Transparent;
            this.lblhoten.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhoten.ForeColor = System.Drawing.Color.White;
            this.lblhoten.Location = new System.Drawing.Point(108, 84);
            this.lblhoten.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblhoten.Name = "lblhoten";
            this.lblhoten.Size = new System.Drawing.Size(87, 29);
            this.lblhoten.TabIndex = 8;
            this.lblhoten.Text = "TenSV";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(14, 84);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(99, 29);
            this.label41.TabIndex = 6;
            this.label41.Text = "Họ Tên:";
            // 
            // tableLayoutPanelcaform
            // 
            this.tableLayoutPanelcaform.ColumnCount = 3;
            this.tableLayoutPanelcaform.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.93225F));
            this.tableLayoutPanelcaform.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.06775F));
            this.tableLayoutPanelcaform.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 335F));
            this.tableLayoutPanelcaform.Controls.Add(this.tableLayoutPanelcot2, 0, 0);
            this.tableLayoutPanelcaform.Controls.Add(this.tableLayoutPanelcot1, 0, 0);
            this.tableLayoutPanelcaform.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanelcaform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelcaform.Location = new System.Drawing.Point(20, 60);
            this.tableLayoutPanelcaform.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanelcaform.Name = "tableLayoutPanelcaform";
            this.tableLayoutPanelcaform.RowCount = 1;
            this.tableLayoutPanelcaform.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelcaform.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 917F));
            this.tableLayoutPanelcaform.Size = new System.Drawing.Size(1902, 917);
            this.tableLayoutPanelcaform.TabIndex = 36;
            // 
            // tableLayoutPanelcot2
            // 
            this.tableLayoutPanelcot2.BackColor = System.Drawing.Color.Gainsboro;
            this.tableLayoutPanelcot2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanelcot2.ColumnCount = 1;
            this.tableLayoutPanelcot2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 364F));
            this.tableLayoutPanelcot2.Controls.Add(this.tbl40, 0, 20);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl39, 0, 19);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl42, 0, 18);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl37, 0, 17);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl36, 0, 16);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl35, 0, 15);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl38, 0, 14);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl33, 0, 13);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl32, 0, 12);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl31, 0, 11);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl34, 0, 10);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl29, 0, 9);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl28, 0, 8);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl27, 0, 7);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl30, 0, 6);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl25, 0, 5);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl24, 0, 4);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl23, 0, 3);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl22, 0, 2);
            this.tableLayoutPanelcot2.Controls.Add(this.tbl21, 0, 1);
            this.tableLayoutPanelcot2.Controls.Add(this.panel87, 0, 0);
            this.tableLayoutPanelcot2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelcot2.Location = new System.Drawing.Point(1570, 4);
            this.tableLayoutPanelcot2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanelcot2.Name = "tableLayoutPanelcot2";
            this.tableLayoutPanelcot2.RowCount = 22;
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 14F));
            this.tableLayoutPanelcot2.Size = new System.Drawing.Size(328, 909);
            this.tableLayoutPanelcot2.TabIndex = 37;
            // 
            // tbl40
            // 
            this.tbl40.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl40.ColumnCount = 5;
            this.tbl40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.14286F));
            this.tbl40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.85714F));
            this.tbl40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tbl40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tbl40.Controls.Add(this.rd44d, 4, 0);
            this.tbl40.Controls.Add(this.rd44a, 1, 0);
            this.tbl40.Controls.Add(this.panel67, 0, 0);
            this.tbl40.Controls.Add(this.rd44c, 2, 0);
            this.tbl40.Controls.Add(this.rd44b, 3, 0);
            this.tbl40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl40.Location = new System.Drawing.Point(5, 841);
            this.tbl40.Margin = new System.Windows.Forms.Padding(4);
            this.tbl40.Name = "tbl40";
            this.tbl40.RowCount = 1;
            this.tbl40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl40.Size = new System.Drawing.Size(356, 26);
            this.tbl40.TabIndex = 20;
            // 
            // rd44d
            // 
            this.rd44d.AutoSize = true;
            this.rd44d.Location = new System.Drawing.Point(255, 5);
            this.rd44d.Margin = new System.Windows.Forms.Padding(4);
            this.rd44d.Name = "rd44d";
            this.rd44d.Size = new System.Drawing.Size(17, 16);
            this.rd44d.TabIndex = 4;
            this.rd44d.TabStop = true;
            this.rd44d.Tag = "D";
            this.rd44d.UseVisualStyleBackColor = true;
            // 
            // rd44a
            // 
            this.rd44a.AutoSize = true;
            this.rd44a.Location = new System.Drawing.Point(82, 5);
            this.rd44a.Margin = new System.Windows.Forms.Padding(4);
            this.rd44a.Name = "rd44a";
            this.rd44a.Size = new System.Drawing.Size(17, 16);
            this.rd44a.TabIndex = 0;
            this.rd44a.TabStop = true;
            this.rd44a.Tag = "A";
            this.rd44a.UseVisualStyleBackColor = true;
            // 
            // panel67
            // 
            this.panel67.Controls.Add(this.lbl40);
            this.panel67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel67.Location = new System.Drawing.Point(5, 5);
            this.panel67.Margin = new System.Windows.Forms.Padding(4);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(68, 16);
            this.panel67.TabIndex = 5;
            // 
            // lbl40
            // 
            this.lbl40.AutoSize = true;
            this.lbl40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl40.Location = new System.Drawing.Point(4, 2);
            this.lbl40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl40.Name = "lbl40";
            this.lbl40.Size = new System.Drawing.Size(64, 17);
            this.lbl40.TabIndex = 1;
            this.lbl40.Text = "Câu 40:";
            this.lbl40.Click += new System.EventHandler(this.lbl40_Click);
            // 
            // rd44c
            // 
            this.rd44c.AutoSize = true;
            this.rd44c.Location = new System.Drawing.Point(140, 5);
            this.rd44c.Margin = new System.Windows.Forms.Padding(4);
            this.rd44c.Name = "rd44c";
            this.rd44c.Size = new System.Drawing.Size(17, 16);
            this.rd44c.TabIndex = 3;
            this.rd44c.TabStop = true;
            this.rd44c.Tag = "C";
            this.rd44c.UseVisualStyleBackColor = true;
            // 
            // rd44b
            // 
            this.rd44b.AutoSize = true;
            this.rd44b.Location = new System.Drawing.Point(194, 5);
            this.rd44b.Margin = new System.Windows.Forms.Padding(4);
            this.rd44b.Name = "rd44b";
            this.rd44b.Size = new System.Drawing.Size(17, 16);
            this.rd44b.TabIndex = 2;
            this.rd44b.TabStop = true;
            this.rd44b.Tag = "B";
            this.rd44b.UseVisualStyleBackColor = true;
            // 
            // tbl39
            // 
            this.tbl39.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl39.ColumnCount = 5;
            this.tbl39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.14286F));
            this.tbl39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.85714F));
            this.tbl39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tbl39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tbl39.Controls.Add(this.rd43d, 4, 0);
            this.tbl39.Controls.Add(this.rd43c, 3, 0);
            this.tbl39.Controls.Add(this.rd43b, 2, 0);
            this.tbl39.Controls.Add(this.rd43a, 1, 0);
            this.tbl39.Controls.Add(this.panel68, 0, 0);
            this.tbl39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl39.Location = new System.Drawing.Point(5, 806);
            this.tbl39.Margin = new System.Windows.Forms.Padding(4);
            this.tbl39.Name = "tbl39";
            this.tbl39.RowCount = 1;
            this.tbl39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl39.Size = new System.Drawing.Size(356, 26);
            this.tbl39.TabIndex = 19;
            // 
            // rd43d
            // 
            this.rd43d.AutoSize = true;
            this.rd43d.Location = new System.Drawing.Point(255, 5);
            this.rd43d.Margin = new System.Windows.Forms.Padding(4);
            this.rd43d.Name = "rd43d";
            this.rd43d.Size = new System.Drawing.Size(17, 16);
            this.rd43d.TabIndex = 4;
            this.rd43d.TabStop = true;
            this.rd43d.Tag = "D";
            this.rd43d.UseVisualStyleBackColor = true;
            // 
            // rd43c
            // 
            this.rd43c.AutoSize = true;
            this.rd43c.Location = new System.Drawing.Point(194, 5);
            this.rd43c.Margin = new System.Windows.Forms.Padding(4);
            this.rd43c.Name = "rd43c";
            this.rd43c.Size = new System.Drawing.Size(17, 16);
            this.rd43c.TabIndex = 3;
            this.rd43c.TabStop = true;
            this.rd43c.Tag = "C";
            this.rd43c.UseVisualStyleBackColor = true;
            // 
            // rd43b
            // 
            this.rd43b.AutoSize = true;
            this.rd43b.Location = new System.Drawing.Point(140, 5);
            this.rd43b.Margin = new System.Windows.Forms.Padding(4);
            this.rd43b.Name = "rd43b";
            this.rd43b.Size = new System.Drawing.Size(17, 16);
            this.rd43b.TabIndex = 2;
            this.rd43b.TabStop = true;
            this.rd43b.Tag = "B";
            this.rd43b.UseVisualStyleBackColor = true;
            // 
            // rd43a
            // 
            this.rd43a.AutoSize = true;
            this.rd43a.Location = new System.Drawing.Point(82, 5);
            this.rd43a.Margin = new System.Windows.Forms.Padding(4);
            this.rd43a.Name = "rd43a";
            this.rd43a.Size = new System.Drawing.Size(17, 16);
            this.rd43a.TabIndex = 0;
            this.rd43a.TabStop = true;
            this.rd43a.Tag = "A";
            this.rd43a.UseVisualStyleBackColor = true;
            // 
            // panel68
            // 
            this.panel68.Controls.Add(this.lbl39);
            this.panel68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel68.Location = new System.Drawing.Point(5, 5);
            this.panel68.Margin = new System.Windows.Forms.Padding(4);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(68, 16);
            this.panel68.TabIndex = 5;
            // 
            // lbl39
            // 
            this.lbl39.AutoSize = true;
            this.lbl39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl39.Location = new System.Drawing.Point(4, 2);
            this.lbl39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl39.Name = "lbl39";
            this.lbl39.Size = new System.Drawing.Size(64, 17);
            this.lbl39.TabIndex = 1;
            this.lbl39.Text = "Câu 39:";
            this.lbl39.Click += new System.EventHandler(this.lbl39_Click);
            // 
            // tbl42
            // 
            this.tbl42.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl42.ColumnCount = 5;
            this.tbl42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.16993F));
            this.tbl42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.83007F));
            this.tbl42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tbl42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tbl42.Controls.Add(this.rd42d, 4, 0);
            this.tbl42.Controls.Add(this.rd42c, 3, 0);
            this.tbl42.Controls.Add(this.rd42b, 2, 0);
            this.tbl42.Controls.Add(this.rd42a, 1, 0);
            this.tbl42.Controls.Add(this.panel69, 0, 0);
            this.tbl42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl42.Location = new System.Drawing.Point(5, 771);
            this.tbl42.Margin = new System.Windows.Forms.Padding(4);
            this.tbl42.Name = "tbl42";
            this.tbl42.RowCount = 1;
            this.tbl42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl42.Size = new System.Drawing.Size(356, 26);
            this.tbl42.TabIndex = 18;
            // 
            // rd42d
            // 
            this.rd42d.AutoSize = true;
            this.rd42d.Location = new System.Drawing.Point(255, 5);
            this.rd42d.Margin = new System.Windows.Forms.Padding(4);
            this.rd42d.Name = "rd42d";
            this.rd42d.Size = new System.Drawing.Size(17, 16);
            this.rd42d.TabIndex = 4;
            this.rd42d.TabStop = true;
            this.rd42d.Tag = "D";
            this.rd42d.UseVisualStyleBackColor = true;
            // 
            // rd42c
            // 
            this.rd42c.AutoSize = true;
            this.rd42c.Location = new System.Drawing.Point(194, 5);
            this.rd42c.Margin = new System.Windows.Forms.Padding(4);
            this.rd42c.Name = "rd42c";
            this.rd42c.Size = new System.Drawing.Size(17, 16);
            this.rd42c.TabIndex = 3;
            this.rd42c.TabStop = true;
            this.rd42c.Tag = "C";
            this.rd42c.UseVisualStyleBackColor = true;
            // 
            // rd42b
            // 
            this.rd42b.AutoSize = true;
            this.rd42b.Location = new System.Drawing.Point(139, 5);
            this.rd42b.Margin = new System.Windows.Forms.Padding(4);
            this.rd42b.Name = "rd42b";
            this.rd42b.Size = new System.Drawing.Size(17, 16);
            this.rd42b.TabIndex = 2;
            this.rd42b.TabStop = true;
            this.rd42b.Tag = "B";
            this.rd42b.UseVisualStyleBackColor = true;
            // 
            // rd42a
            // 
            this.rd42a.AutoSize = true;
            this.rd42a.Location = new System.Drawing.Point(83, 5);
            this.rd42a.Margin = new System.Windows.Forms.Padding(4);
            this.rd42a.Name = "rd42a";
            this.rd42a.Size = new System.Drawing.Size(17, 16);
            this.rd42a.TabIndex = 0;
            this.rd42a.TabStop = true;
            this.rd42a.Tag = "A";
            this.rd42a.UseVisualStyleBackColor = true;
            // 
            // panel69
            // 
            this.panel69.Controls.Add(this.lbl38);
            this.panel69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel69.Location = new System.Drawing.Point(5, 5);
            this.panel69.Margin = new System.Windows.Forms.Padding(4);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(69, 16);
            this.panel69.TabIndex = 5;
            // 
            // lbl38
            // 
            this.lbl38.AutoSize = true;
            this.lbl38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl38.Location = new System.Drawing.Point(4, 2);
            this.lbl38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(64, 17);
            this.lbl38.TabIndex = 1;
            this.lbl38.Text = "Câu 38:";
            this.lbl38.Click += new System.EventHandler(this.lbl38_Click);
            // 
            // tbl37
            // 
            this.tbl37.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl37.ColumnCount = 5;
            this.tbl37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.9404F));
            this.tbl37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.0596F));
            this.tbl37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tbl37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tbl37.Controls.Add(this.rd41d, 4, 0);
            this.tbl37.Controls.Add(this.rd41c, 3, 0);
            this.tbl37.Controls.Add(this.rd41b, 2, 0);
            this.tbl37.Controls.Add(this.rd41a, 1, 0);
            this.tbl37.Controls.Add(this.panel70, 0, 0);
            this.tbl37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl37.Location = new System.Drawing.Point(5, 736);
            this.tbl37.Margin = new System.Windows.Forms.Padding(4);
            this.tbl37.Name = "tbl37";
            this.tbl37.RowCount = 1;
            this.tbl37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl37.Size = new System.Drawing.Size(356, 26);
            this.tbl37.TabIndex = 17;
            // 
            // rd41d
            // 
            this.rd41d.AutoSize = true;
            this.rd41d.Location = new System.Drawing.Point(255, 5);
            this.rd41d.Margin = new System.Windows.Forms.Padding(4);
            this.rd41d.Name = "rd41d";
            this.rd41d.Size = new System.Drawing.Size(17, 16);
            this.rd41d.TabIndex = 4;
            this.rd41d.TabStop = true;
            this.rd41d.Tag = "D";
            this.rd41d.UseVisualStyleBackColor = true;
            // 
            // rd41c
            // 
            this.rd41c.AutoSize = true;
            this.rd41c.Location = new System.Drawing.Point(195, 5);
            this.rd41c.Margin = new System.Windows.Forms.Padding(4);
            this.rd41c.Name = "rd41c";
            this.rd41c.Size = new System.Drawing.Size(17, 16);
            this.rd41c.TabIndex = 3;
            this.rd41c.TabStop = true;
            this.rd41c.Tag = "C";
            this.rd41c.UseVisualStyleBackColor = true;
            // 
            // rd41b
            // 
            this.rd41b.AutoSize = true;
            this.rd41b.Location = new System.Drawing.Point(137, 5);
            this.rd41b.Margin = new System.Windows.Forms.Padding(4);
            this.rd41b.Name = "rd41b";
            this.rd41b.Size = new System.Drawing.Size(17, 16);
            this.rd41b.TabIndex = 2;
            this.rd41b.TabStop = true;
            this.rd41b.Tag = "B";
            this.rd41b.UseVisualStyleBackColor = true;
            // 
            // rd41a
            // 
            this.rd41a.AutoSize = true;
            this.rd41a.Location = new System.Drawing.Point(83, 5);
            this.rd41a.Margin = new System.Windows.Forms.Padding(4);
            this.rd41a.Name = "rd41a";
            this.rd41a.Size = new System.Drawing.Size(17, 16);
            this.rd41a.TabIndex = 0;
            this.rd41a.TabStop = true;
            this.rd41a.Tag = "A";
            this.rd41a.UseVisualStyleBackColor = true;
            // 
            // panel70
            // 
            this.panel70.Controls.Add(this.lbl37);
            this.panel70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel70.Location = new System.Drawing.Point(5, 5);
            this.panel70.Margin = new System.Windows.Forms.Padding(4);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(69, 16);
            this.panel70.TabIndex = 5;
            // 
            // lbl37
            // 
            this.lbl37.AutoSize = true;
            this.lbl37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl37.Location = new System.Drawing.Point(4, 0);
            this.lbl37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(64, 17);
            this.lbl37.TabIndex = 1;
            this.lbl37.Text = "Câu 37:";
            this.lbl37.Click += new System.EventHandler(this.lbl37_Click);
            // 
            // tbl36
            // 
            this.tbl36.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl36.ColumnCount = 5;
            this.tbl36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.51634F));
            this.tbl36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.48366F));
            this.tbl36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tbl36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tbl36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tbl36.Controls.Add(this.rd40d, 4, 0);
            this.tbl36.Controls.Add(this.rd40c, 3, 0);
            this.tbl36.Controls.Add(this.rd40b, 2, 0);
            this.tbl36.Controls.Add(this.rd40a, 1, 0);
            this.tbl36.Controls.Add(this.panel71, 0, 0);
            this.tbl36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl36.Location = new System.Drawing.Point(5, 701);
            this.tbl36.Margin = new System.Windows.Forms.Padding(4);
            this.tbl36.Name = "tbl36";
            this.tbl36.RowCount = 1;
            this.tbl36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl36.Size = new System.Drawing.Size(356, 26);
            this.tbl36.TabIndex = 16;
            // 
            // rd40d
            // 
            this.rd40d.AutoSize = true;
            this.rd40d.Location = new System.Drawing.Point(255, 5);
            this.rd40d.Margin = new System.Windows.Forms.Padding(4);
            this.rd40d.Name = "rd40d";
            this.rd40d.Size = new System.Drawing.Size(17, 16);
            this.rd40d.TabIndex = 4;
            this.rd40d.TabStop = true;
            this.rd40d.Tag = "D";
            this.rd40d.UseVisualStyleBackColor = true;
            // 
            // rd40c
            // 
            this.rd40c.AutoSize = true;
            this.rd40c.Location = new System.Drawing.Point(196, 5);
            this.rd40c.Margin = new System.Windows.Forms.Padding(4);
            this.rd40c.Name = "rd40c";
            this.rd40c.Size = new System.Drawing.Size(17, 16);
            this.rd40c.TabIndex = 3;
            this.rd40c.TabStop = true;
            this.rd40c.Tag = "C";
            this.rd40c.UseVisualStyleBackColor = true;
            // 
            // rd40b
            // 
            this.rd40b.AutoSize = true;
            this.rd40b.Location = new System.Drawing.Point(139, 5);
            this.rd40b.Margin = new System.Windows.Forms.Padding(4);
            this.rd40b.Name = "rd40b";
            this.rd40b.Size = new System.Drawing.Size(17, 16);
            this.rd40b.TabIndex = 2;
            this.rd40b.TabStop = true;
            this.rd40b.Tag = "B";
            this.rd40b.UseVisualStyleBackColor = true;
            // 
            // rd40a
            // 
            this.rd40a.AutoSize = true;
            this.rd40a.Location = new System.Drawing.Point(82, 5);
            this.rd40a.Margin = new System.Windows.Forms.Padding(4);
            this.rd40a.Name = "rd40a";
            this.rd40a.Size = new System.Drawing.Size(17, 16);
            this.rd40a.TabIndex = 0;
            this.rd40a.TabStop = true;
            this.rd40a.Tag = "A";
            this.rd40a.UseVisualStyleBackColor = true;
            // 
            // panel71
            // 
            this.panel71.Controls.Add(this.lbl36);
            this.panel71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel71.Location = new System.Drawing.Point(5, 5);
            this.panel71.Margin = new System.Windows.Forms.Padding(4);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(68, 16);
            this.panel71.TabIndex = 5;
            // 
            // lbl36
            // 
            this.lbl36.AutoSize = true;
            this.lbl36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl36.Location = new System.Drawing.Point(4, 0);
            this.lbl36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(64, 17);
            this.lbl36.TabIndex = 1;
            this.lbl36.Text = "Câu 36:";
            this.lbl36.Click += new System.EventHandler(this.lbl36_Click);
            // 
            // tbl35
            // 
            this.tbl35.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl35.ColumnCount = 5;
            this.tbl35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.55263F));
            this.tbl35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.44737F));
            this.tbl35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tbl35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tbl35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tbl35.Controls.Add(this.rd39d, 4, 0);
            this.tbl35.Controls.Add(this.rd39c, 3, 0);
            this.tbl35.Controls.Add(this.rd39b, 2, 0);
            this.tbl35.Controls.Add(this.rd39a, 1, 0);
            this.tbl35.Controls.Add(this.panel72, 0, 0);
            this.tbl35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl35.Location = new System.Drawing.Point(5, 666);
            this.tbl35.Margin = new System.Windows.Forms.Padding(4);
            this.tbl35.Name = "tbl35";
            this.tbl35.RowCount = 1;
            this.tbl35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl35.Size = new System.Drawing.Size(356, 26);
            this.tbl35.TabIndex = 15;
            this.tbl35.Paint += new System.Windows.Forms.PaintEventHandler(this.tbl35_Paint);
            // 
            // rd39d
            // 
            this.rd39d.AutoSize = true;
            this.rd39d.Location = new System.Drawing.Point(255, 5);
            this.rd39d.Margin = new System.Windows.Forms.Padding(4);
            this.rd39d.Name = "rd39d";
            this.rd39d.Size = new System.Drawing.Size(17, 16);
            this.rd39d.TabIndex = 4;
            this.rd39d.TabStop = true;
            this.rd39d.Tag = "D";
            this.rd39d.UseVisualStyleBackColor = true;
            // 
            // rd39c
            // 
            this.rd39c.AutoSize = true;
            this.rd39c.Location = new System.Drawing.Point(196, 5);
            this.rd39c.Margin = new System.Windows.Forms.Padding(4);
            this.rd39c.Name = "rd39c";
            this.rd39c.Size = new System.Drawing.Size(17, 16);
            this.rd39c.TabIndex = 3;
            this.rd39c.TabStop = true;
            this.rd39c.Tag = "C";
            this.rd39c.UseVisualStyleBackColor = true;
            // 
            // rd39b
            // 
            this.rd39b.AutoSize = true;
            this.rd39b.Location = new System.Drawing.Point(138, 5);
            this.rd39b.Margin = new System.Windows.Forms.Padding(4);
            this.rd39b.Name = "rd39b";
            this.rd39b.Size = new System.Drawing.Size(17, 16);
            this.rd39b.TabIndex = 2;
            this.rd39b.TabStop = true;
            this.rd39b.Tag = "B";
            this.rd39b.UseVisualStyleBackColor = true;
            // 
            // rd39a
            // 
            this.rd39a.AutoSize = true;
            this.rd39a.Location = new System.Drawing.Point(83, 5);
            this.rd39a.Margin = new System.Windows.Forms.Padding(4);
            this.rd39a.Name = "rd39a";
            this.rd39a.Size = new System.Drawing.Size(17, 16);
            this.rd39a.TabIndex = 0;
            this.rd39a.TabStop = true;
            this.rd39a.Tag = "A";
            this.rd39a.UseVisualStyleBackColor = true;
            // 
            // panel72
            // 
            this.panel72.Controls.Add(this.lbl35);
            this.panel72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel72.Location = new System.Drawing.Point(5, 5);
            this.panel72.Margin = new System.Windows.Forms.Padding(4);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(69, 16);
            this.panel72.TabIndex = 5;
            // 
            // lbl35
            // 
            this.lbl35.AutoSize = true;
            this.lbl35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl35.Location = new System.Drawing.Point(4, 2);
            this.lbl35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(64, 17);
            this.lbl35.TabIndex = 1;
            this.lbl35.Text = "Câu 35:";
            this.lbl35.Click += new System.EventHandler(this.lbl35_Click);
            // 
            // tbl38
            // 
            this.tbl38.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl38.ColumnCount = 5;
            this.tbl38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.27814F));
            this.tbl38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.72186F));
            this.tbl38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tbl38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tbl38.Controls.Add(this.rd38d, 4, 0);
            this.tbl38.Controls.Add(this.rd38c, 3, 0);
            this.tbl38.Controls.Add(this.rd38b, 2, 0);
            this.tbl38.Controls.Add(this.rd38a, 1, 0);
            this.tbl38.Controls.Add(this.panel73, 0, 0);
            this.tbl38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl38.Location = new System.Drawing.Point(5, 631);
            this.tbl38.Margin = new System.Windows.Forms.Padding(4);
            this.tbl38.Name = "tbl38";
            this.tbl38.RowCount = 1;
            this.tbl38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl38.Size = new System.Drawing.Size(356, 26);
            this.tbl38.TabIndex = 14;
            // 
            // rd38d
            // 
            this.rd38d.AutoSize = true;
            this.rd38d.Location = new System.Drawing.Point(255, 5);
            this.rd38d.Margin = new System.Windows.Forms.Padding(4);
            this.rd38d.Name = "rd38d";
            this.rd38d.Size = new System.Drawing.Size(17, 16);
            this.rd38d.TabIndex = 4;
            this.rd38d.TabStop = true;
            this.rd38d.Tag = "D";
            this.rd38d.UseVisualStyleBackColor = true;
            // 
            // rd38c
            // 
            this.rd38c.AutoSize = true;
            this.rd38c.Location = new System.Drawing.Point(195, 5);
            this.rd38c.Margin = new System.Windows.Forms.Padding(4);
            this.rd38c.Name = "rd38c";
            this.rd38c.Size = new System.Drawing.Size(17, 16);
            this.rd38c.TabIndex = 3;
            this.rd38c.TabStop = true;
            this.rd38c.Tag = "C";
            this.rd38c.UseVisualStyleBackColor = true;
            // 
            // rd38b
            // 
            this.rd38b.AutoSize = true;
            this.rd38b.Location = new System.Drawing.Point(137, 5);
            this.rd38b.Margin = new System.Windows.Forms.Padding(4);
            this.rd38b.Name = "rd38b";
            this.rd38b.Size = new System.Drawing.Size(17, 16);
            this.rd38b.TabIndex = 2;
            this.rd38b.TabStop = true;
            this.rd38b.Tag = "B";
            this.rd38b.UseVisualStyleBackColor = true;
            // 
            // rd38a
            // 
            this.rd38a.AutoSize = true;
            this.rd38a.Location = new System.Drawing.Point(82, 5);
            this.rd38a.Margin = new System.Windows.Forms.Padding(4);
            this.rd38a.Name = "rd38a";
            this.rd38a.Size = new System.Drawing.Size(17, 16);
            this.rd38a.TabIndex = 0;
            this.rd38a.TabStop = true;
            this.rd38a.Tag = "A";
            this.rd38a.UseVisualStyleBackColor = true;
            // 
            // panel73
            // 
            this.panel73.Controls.Add(this.lbl34);
            this.panel73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel73.Location = new System.Drawing.Point(5, 5);
            this.panel73.Margin = new System.Windows.Forms.Padding(4);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(68, 16);
            this.panel73.TabIndex = 5;
            // 
            // lbl34
            // 
            this.lbl34.AutoSize = true;
            this.lbl34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl34.Location = new System.Drawing.Point(4, 2);
            this.lbl34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(64, 17);
            this.lbl34.TabIndex = 1;
            this.lbl34.Text = "Câu 34:";
            this.lbl34.Click += new System.EventHandler(this.lbl34_Click);
            // 
            // tbl33
            // 
            this.tbl33.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl33.ColumnCount = 5;
            this.tbl33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.33333F));
            this.tbl33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.66667F));
            this.tbl33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tbl33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tbl33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 104F));
            this.tbl33.Controls.Add(this.rd37d, 4, 0);
            this.tbl33.Controls.Add(this.rd37c, 3, 0);
            this.tbl33.Controls.Add(this.rd37b, 2, 0);
            this.tbl33.Controls.Add(this.rd37, 1, 0);
            this.tbl33.Controls.Add(this.panel74, 0, 0);
            this.tbl33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl33.Location = new System.Drawing.Point(5, 596);
            this.tbl33.Margin = new System.Windows.Forms.Padding(4);
            this.tbl33.Name = "tbl33";
            this.tbl33.RowCount = 1;
            this.tbl33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl33.Size = new System.Drawing.Size(356, 26);
            this.tbl33.TabIndex = 13;
            // 
            // rd37d
            // 
            this.rd37d.AutoSize = true;
            this.rd37d.Location = new System.Drawing.Point(254, 5);
            this.rd37d.Margin = new System.Windows.Forms.Padding(4);
            this.rd37d.Name = "rd37d";
            this.rd37d.Size = new System.Drawing.Size(17, 16);
            this.rd37d.TabIndex = 4;
            this.rd37d.TabStop = true;
            this.rd37d.Tag = "D";
            this.rd37d.UseVisualStyleBackColor = true;
            // 
            // rd37c
            // 
            this.rd37c.AutoSize = true;
            this.rd37c.Location = new System.Drawing.Point(195, 5);
            this.rd37c.Margin = new System.Windows.Forms.Padding(4);
            this.rd37c.Name = "rd37c";
            this.rd37c.Size = new System.Drawing.Size(17, 16);
            this.rd37c.TabIndex = 3;
            this.rd37c.TabStop = true;
            this.rd37c.Tag = "C";
            this.rd37c.UseVisualStyleBackColor = true;
            // 
            // rd37b
            // 
            this.rd37b.AutoSize = true;
            this.rd37b.Location = new System.Drawing.Point(136, 5);
            this.rd37b.Margin = new System.Windows.Forms.Padding(4);
            this.rd37b.Name = "rd37b";
            this.rd37b.Size = new System.Drawing.Size(17, 16);
            this.rd37b.TabIndex = 2;
            this.rd37b.TabStop = true;
            this.rd37b.Tag = "B";
            this.rd37b.UseVisualStyleBackColor = true;
            // 
            // rd37
            // 
            this.rd37.AutoSize = true;
            this.rd37.Location = new System.Drawing.Point(83, 5);
            this.rd37.Margin = new System.Windows.Forms.Padding(4);
            this.rd37.Name = "rd37";
            this.rd37.Size = new System.Drawing.Size(17, 16);
            this.rd37.TabIndex = 0;
            this.rd37.TabStop = true;
            this.rd37.Tag = "A";
            this.rd37.UseVisualStyleBackColor = true;
            // 
            // panel74
            // 
            this.panel74.Controls.Add(this.lbl33);
            this.panel74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel74.Location = new System.Drawing.Point(5, 5);
            this.panel74.Margin = new System.Windows.Forms.Padding(4);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(69, 16);
            this.panel74.TabIndex = 5;
            // 
            // lbl33
            // 
            this.lbl33.AutoSize = true;
            this.lbl33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl33.Location = new System.Drawing.Point(4, 0);
            this.lbl33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(64, 17);
            this.lbl33.TabIndex = 1;
            this.lbl33.Text = "Câu 33:";
            this.lbl33.Click += new System.EventHandler(this.lbl33_Click);
            // 
            // tbl32
            // 
            this.tbl32.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl32.ColumnCount = 5;
            this.tbl32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.13986F));
            this.tbl32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.86014F));
            this.tbl32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tbl32.Controls.Add(this.rd36d, 4, 0);
            this.tbl32.Controls.Add(this.rd36c, 3, 0);
            this.tbl32.Controls.Add(this.rd36b, 2, 0);
            this.tbl32.Controls.Add(this.rd36aa, 1, 0);
            this.tbl32.Controls.Add(this.panel75, 0, 0);
            this.tbl32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl32.Location = new System.Drawing.Point(5, 561);
            this.tbl32.Margin = new System.Windows.Forms.Padding(4);
            this.tbl32.Name = "tbl32";
            this.tbl32.RowCount = 1;
            this.tbl32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl32.Size = new System.Drawing.Size(356, 26);
            this.tbl32.TabIndex = 12;
            // 
            // rd36d
            // 
            this.rd36d.AutoSize = true;
            this.rd36d.Location = new System.Drawing.Point(270, 5);
            this.rd36d.Margin = new System.Windows.Forms.Padding(4);
            this.rd36d.Name = "rd36d";
            this.rd36d.Size = new System.Drawing.Size(17, 16);
            this.rd36d.TabIndex = 4;
            this.rd36d.TabStop = true;
            this.rd36d.Tag = "D";
            this.rd36d.UseVisualStyleBackColor = true;
            // 
            // rd36c
            // 
            this.rd36c.AutoSize = true;
            this.rd36c.Location = new System.Drawing.Point(210, 5);
            this.rd36c.Margin = new System.Windows.Forms.Padding(4);
            this.rd36c.Name = "rd36c";
            this.rd36c.Size = new System.Drawing.Size(17, 16);
            this.rd36c.TabIndex = 3;
            this.rd36c.TabStop = true;
            this.rd36c.Tag = "C";
            this.rd36c.UseVisualStyleBackColor = true;
            // 
            // rd36b
            // 
            this.rd36b.AutoSize = true;
            this.rd36b.Location = new System.Drawing.Point(150, 5);
            this.rd36b.Margin = new System.Windows.Forms.Padding(4);
            this.rd36b.Name = "rd36b";
            this.rd36b.Size = new System.Drawing.Size(17, 16);
            this.rd36b.TabIndex = 2;
            this.rd36b.TabStop = true;
            this.rd36b.Tag = "B";
            this.rd36b.UseVisualStyleBackColor = true;
            // 
            // rd36aa
            // 
            this.rd36aa.AutoSize = true;
            this.rd36aa.Location = new System.Drawing.Point(92, 5);
            this.rd36aa.Margin = new System.Windows.Forms.Padding(4);
            this.rd36aa.Name = "rd36aa";
            this.rd36aa.Size = new System.Drawing.Size(17, 16);
            this.rd36aa.TabIndex = 0;
            this.rd36aa.TabStop = true;
            this.rd36aa.Tag = "A";
            this.rd36aa.UseVisualStyleBackColor = true;
            // 
            // panel75
            // 
            this.panel75.Controls.Add(this.lbl32);
            this.panel75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel75.Location = new System.Drawing.Point(5, 5);
            this.panel75.Margin = new System.Windows.Forms.Padding(4);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(78, 16);
            this.panel75.TabIndex = 5;
            // 
            // lbl32
            // 
            this.lbl32.AutoSize = true;
            this.lbl32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl32.Location = new System.Drawing.Point(4, 0);
            this.lbl32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(64, 17);
            this.lbl32.TabIndex = 1;
            this.lbl32.Text = "Câu 32:";
            this.lbl32.Click += new System.EventHandler(this.lbl32_Click);
            // 
            // tbl31
            // 
            this.tbl31.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl31.ColumnCount = 5;
            this.tbl31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.72222F));
            this.tbl31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.27778F));
            this.tbl31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 87F));
            this.tbl31.Controls.Add(this.rd35d, 4, 0);
            this.tbl31.Controls.Add(this.rd35c, 3, 0);
            this.tbl31.Controls.Add(this.rd35b, 2, 0);
            this.tbl31.Controls.Add(this.rd35a, 1, 0);
            this.tbl31.Controls.Add(this.panel76, 0, 0);
            this.tbl31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl31.Location = new System.Drawing.Point(5, 526);
            this.tbl31.Margin = new System.Windows.Forms.Padding(4);
            this.tbl31.Name = "tbl31";
            this.tbl31.RowCount = 1;
            this.tbl31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl31.Size = new System.Drawing.Size(356, 26);
            this.tbl31.TabIndex = 11;
            // 
            // rd35d
            // 
            this.rd35d.AutoSize = true;
            this.rd35d.Location = new System.Drawing.Point(272, 5);
            this.rd35d.Margin = new System.Windows.Forms.Padding(4);
            this.rd35d.Name = "rd35d";
            this.rd35d.Size = new System.Drawing.Size(17, 16);
            this.rd35d.TabIndex = 4;
            this.rd35d.TabStop = true;
            this.rd35d.Tag = "D";
            this.rd35d.UseVisualStyleBackColor = true;
            // 
            // rd35c
            // 
            this.rd35c.AutoSize = true;
            this.rd35c.Location = new System.Drawing.Point(211, 5);
            this.rd35c.Margin = new System.Windows.Forms.Padding(4);
            this.rd35c.Name = "rd35c";
            this.rd35c.Size = new System.Drawing.Size(17, 16);
            this.rd35c.TabIndex = 3;
            this.rd35c.TabStop = true;
            this.rd35c.Tag = "C";
            this.rd35c.UseVisualStyleBackColor = true;
            // 
            // rd35b
            // 
            this.rd35b.AutoSize = true;
            this.rd35b.Location = new System.Drawing.Point(151, 5);
            this.rd35b.Margin = new System.Windows.Forms.Padding(4);
            this.rd35b.Name = "rd35b";
            this.rd35b.Size = new System.Drawing.Size(17, 16);
            this.rd35b.TabIndex = 2;
            this.rd35b.TabStop = true;
            this.rd35b.Tag = "B";
            this.rd35b.UseVisualStyleBackColor = true;
            // 
            // rd35a
            // 
            this.rd35a.AutoSize = true;
            this.rd35a.Location = new System.Drawing.Point(92, 5);
            this.rd35a.Margin = new System.Windows.Forms.Padding(4);
            this.rd35a.Name = "rd35a";
            this.rd35a.Size = new System.Drawing.Size(17, 16);
            this.rd35a.TabIndex = 0;
            this.rd35a.TabStop = true;
            this.rd35a.Tag = "A";
            this.rd35a.UseVisualStyleBackColor = true;
            // 
            // panel76
            // 
            this.panel76.Controls.Add(this.lbl31);
            this.panel76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel76.Location = new System.Drawing.Point(5, 5);
            this.panel76.Margin = new System.Windows.Forms.Padding(4);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(78, 16);
            this.panel76.TabIndex = 5;
            // 
            // lbl31
            // 
            this.lbl31.AutoSize = true;
            this.lbl31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl31.Location = new System.Drawing.Point(4, 0);
            this.lbl31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(69, 17);
            this.lbl31.TabIndex = 1;
            this.lbl31.Text = " Câu 31:";
            this.lbl31.Click += new System.EventHandler(this.lbl31_Click);
            // 
            // tbl34
            // 
            this.tbl34.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl34.ColumnCount = 5;
            this.tbl34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.44056F));
            this.tbl34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.55944F));
            this.tbl34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tbl34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tbl34.Controls.Add(this.rd34d, 4, 0);
            this.tbl34.Controls.Add(this.rd34c, 3, 0);
            this.tbl34.Controls.Add(this.rd34b, 2, 0);
            this.tbl34.Controls.Add(this.rd34a, 1, 0);
            this.tbl34.Controls.Add(this.panel77, 0, 0);
            this.tbl34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl34.Location = new System.Drawing.Point(5, 491);
            this.tbl34.Margin = new System.Windows.Forms.Padding(4);
            this.tbl34.Name = "tbl34";
            this.tbl34.RowCount = 1;
            this.tbl34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl34.Size = new System.Drawing.Size(356, 26);
            this.tbl34.TabIndex = 10;
            // 
            // rd34d
            // 
            this.rd34d.AutoSize = true;
            this.rd34d.Location = new System.Drawing.Point(273, 5);
            this.rd34d.Margin = new System.Windows.Forms.Padding(4);
            this.rd34d.Name = "rd34d";
            this.rd34d.Size = new System.Drawing.Size(17, 16);
            this.rd34d.TabIndex = 4;
            this.rd34d.TabStop = true;
            this.rd34d.Tag = "D";
            this.rd34d.UseVisualStyleBackColor = true;
            // 
            // rd34c
            // 
            this.rd34c.AutoSize = true;
            this.rd34c.Location = new System.Drawing.Point(213, 5);
            this.rd34c.Margin = new System.Windows.Forms.Padding(4);
            this.rd34c.Name = "rd34c";
            this.rd34c.Size = new System.Drawing.Size(17, 16);
            this.rd34c.TabIndex = 3;
            this.rd34c.TabStop = true;
            this.rd34c.Tag = "C";
            this.rd34c.UseVisualStyleBackColor = true;
            // 
            // rd34b
            // 
            this.rd34b.AutoSize = true;
            this.rd34b.Location = new System.Drawing.Point(150, 5);
            this.rd34b.Margin = new System.Windows.Forms.Padding(4);
            this.rd34b.Name = "rd34b";
            this.rd34b.Size = new System.Drawing.Size(17, 16);
            this.rd34b.TabIndex = 2;
            this.rd34b.TabStop = true;
            this.rd34b.Tag = "B";
            this.rd34b.UseVisualStyleBackColor = true;
            // 
            // rd34a
            // 
            this.rd34a.AutoSize = true;
            this.rd34a.Location = new System.Drawing.Point(91, 5);
            this.rd34a.Margin = new System.Windows.Forms.Padding(4);
            this.rd34a.Name = "rd34a";
            this.rd34a.Size = new System.Drawing.Size(17, 16);
            this.rd34a.TabIndex = 0;
            this.rd34a.TabStop = true;
            this.rd34a.Tag = "A";
            this.rd34a.UseVisualStyleBackColor = true;
            // 
            // panel77
            // 
            this.panel77.Controls.Add(this.lbl30);
            this.panel77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel77.Location = new System.Drawing.Point(5, 5);
            this.panel77.Margin = new System.Windows.Forms.Padding(4);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(77, 16);
            this.panel77.TabIndex = 5;
            // 
            // lbl30
            // 
            this.lbl30.AutoSize = true;
            this.lbl30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl30.Location = new System.Drawing.Point(4, 0);
            this.lbl30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(64, 17);
            this.lbl30.TabIndex = 1;
            this.lbl30.Text = "Câu 30:";
            this.lbl30.Click += new System.EventHandler(this.lbl30_Click);
            // 
            // tbl29
            // 
            this.tbl29.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl29.ColumnCount = 5;
            this.tbl29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.85915F));
            this.tbl29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.14085F));
            this.tbl29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tbl29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tbl29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 104F));
            this.tbl29.Controls.Add(this.rd33d, 4, 0);
            this.tbl29.Controls.Add(this.rd33c, 3, 0);
            this.tbl29.Controls.Add(this.rd33b, 2, 0);
            this.tbl29.Controls.Add(this.rd33a, 1, 0);
            this.tbl29.Controls.Add(this.panel78, 0, 0);
            this.tbl29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl29.Location = new System.Drawing.Point(5, 456);
            this.tbl29.Margin = new System.Windows.Forms.Padding(4);
            this.tbl29.Name = "tbl29";
            this.tbl29.RowCount = 1;
            this.tbl29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl29.Size = new System.Drawing.Size(356, 26);
            this.tbl29.TabIndex = 9;
            // 
            // rd33d
            // 
            this.rd33d.AutoSize = true;
            this.rd33d.Location = new System.Drawing.Point(254, 5);
            this.rd33d.Margin = new System.Windows.Forms.Padding(4);
            this.rd33d.Name = "rd33d";
            this.rd33d.Size = new System.Drawing.Size(17, 16);
            this.rd33d.TabIndex = 4;
            this.rd33d.TabStop = true;
            this.rd33d.Tag = "D";
            this.rd33d.UseVisualStyleBackColor = true;
            // 
            // rd33c
            // 
            this.rd33c.AutoSize = true;
            this.rd33c.Location = new System.Drawing.Point(195, 5);
            this.rd33c.Margin = new System.Windows.Forms.Padding(4);
            this.rd33c.Name = "rd33c";
            this.rd33c.Size = new System.Drawing.Size(17, 16);
            this.rd33c.TabIndex = 3;
            this.rd33c.TabStop = true;
            this.rd33c.Tag = "C";
            this.rd33c.UseVisualStyleBackColor = true;
            // 
            // rd33b
            // 
            this.rd33b.AutoSize = true;
            this.rd33b.Location = new System.Drawing.Point(132, 5);
            this.rd33b.Margin = new System.Windows.Forms.Padding(4);
            this.rd33b.Name = "rd33b";
            this.rd33b.Size = new System.Drawing.Size(17, 16);
            this.rd33b.TabIndex = 2;
            this.rd33b.TabStop = true;
            this.rd33b.Tag = "B";
            this.rd33b.UseVisualStyleBackColor = true;
            // 
            // rd33a
            // 
            this.rd33a.AutoSize = true;
            this.rd33a.Location = new System.Drawing.Point(81, 5);
            this.rd33a.Margin = new System.Windows.Forms.Padding(4);
            this.rd33a.Name = "rd33a";
            this.rd33a.Size = new System.Drawing.Size(17, 16);
            this.rd33a.TabIndex = 0;
            this.rd33a.TabStop = true;
            this.rd33a.Tag = "A";
            this.rd33a.UseVisualStyleBackColor = true;
            // 
            // panel78
            // 
            this.panel78.Controls.Add(this.lbl29);
            this.panel78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel78.Location = new System.Drawing.Point(5, 5);
            this.panel78.Margin = new System.Windows.Forms.Padding(4);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(67, 16);
            this.panel78.TabIndex = 5;
            // 
            // lbl29
            // 
            this.lbl29.AutoSize = true;
            this.lbl29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl29.Location = new System.Drawing.Point(4, 0);
            this.lbl29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(64, 17);
            this.lbl29.TabIndex = 1;
            this.lbl29.Text = "Câu 29:";
            this.lbl29.Click += new System.EventHandler(this.lbl29_Click);
            // 
            // tbl28
            // 
            this.tbl28.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl28.ColumnCount = 5;
            this.tbl28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.57447F));
            this.tbl28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.42553F));
            this.tbl28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tbl28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 104F));
            this.tbl28.Controls.Add(this.rd32d, 4, 0);
            this.tbl28.Controls.Add(this.rd32c, 3, 0);
            this.tbl28.Controls.Add(this.rd32b, 2, 0);
            this.tbl28.Controls.Add(this.rd32a, 1, 0);
            this.tbl28.Controls.Add(this.panel79, 0, 0);
            this.tbl28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl28.Location = new System.Drawing.Point(5, 421);
            this.tbl28.Margin = new System.Windows.Forms.Padding(4);
            this.tbl28.Name = "tbl28";
            this.tbl28.RowCount = 1;
            this.tbl28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl28.Size = new System.Drawing.Size(356, 26);
            this.tbl28.TabIndex = 8;
            // 
            // rd32d
            // 
            this.rd32d.AutoSize = true;
            this.rd32d.Location = new System.Drawing.Point(254, 5);
            this.rd32d.Margin = new System.Windows.Forms.Padding(4);
            this.rd32d.Name = "rd32d";
            this.rd32d.Size = new System.Drawing.Size(17, 16);
            this.rd32d.TabIndex = 4;
            this.rd32d.TabStop = true;
            this.rd32d.Tag = "D";
            this.rd32d.UseVisualStyleBackColor = true;
            // 
            // rd32c
            // 
            this.rd32c.AutoSize = true;
            this.rd32c.Location = new System.Drawing.Point(194, 5);
            this.rd32c.Margin = new System.Windows.Forms.Padding(4);
            this.rd32c.Name = "rd32c";
            this.rd32c.Size = new System.Drawing.Size(17, 16);
            this.rd32c.TabIndex = 3;
            this.rd32c.TabStop = true;
            this.rd32c.Tag = "C";
            this.rd32c.UseVisualStyleBackColor = true;
            // 
            // rd32b
            // 
            this.rd32b.AutoSize = true;
            this.rd32b.Location = new System.Drawing.Point(132, 5);
            this.rd32b.Margin = new System.Windows.Forms.Padding(4);
            this.rd32b.Name = "rd32b";
            this.rd32b.Size = new System.Drawing.Size(17, 16);
            this.rd32b.TabIndex = 2;
            this.rd32b.TabStop = true;
            this.rd32b.Tag = "B";
            this.rd32b.UseVisualStyleBackColor = true;
            // 
            // rd32a
            // 
            this.rd32a.AutoSize = true;
            this.rd32a.Location = new System.Drawing.Point(81, 5);
            this.rd32a.Margin = new System.Windows.Forms.Padding(4);
            this.rd32a.Name = "rd32a";
            this.rd32a.Size = new System.Drawing.Size(17, 16);
            this.rd32a.TabIndex = 0;
            this.rd32a.TabStop = true;
            this.rd32a.Tag = "A";
            this.rd32a.UseVisualStyleBackColor = true;
            // 
            // panel79
            // 
            this.panel79.Controls.Add(this.lbl28);
            this.panel79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel79.Location = new System.Drawing.Point(5, 5);
            this.panel79.Margin = new System.Windows.Forms.Padding(4);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(67, 16);
            this.panel79.TabIndex = 5;
            // 
            // lbl28
            // 
            this.lbl28.AutoSize = true;
            this.lbl28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl28.Location = new System.Drawing.Point(4, 2);
            this.lbl28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(64, 17);
            this.lbl28.TabIndex = 1;
            this.lbl28.Text = "Câu 28:";
            this.lbl28.Click += new System.EventHandler(this.lbl28_Click);
            // 
            // tbl27
            // 
            this.tbl27.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl27.ColumnCount = 5;
            this.tbl27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.31034F));
            this.tbl27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.68966F));
            this.tbl27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tbl27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 104F));
            this.tbl27.Controls.Add(this.rd31d, 4, 0);
            this.tbl27.Controls.Add(this.rd31c, 3, 0);
            this.tbl27.Controls.Add(this.rd31b, 2, 0);
            this.tbl27.Controls.Add(this.rd31a, 1, 0);
            this.tbl27.Controls.Add(this.panel80, 0, 0);
            this.tbl27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl27.Location = new System.Drawing.Point(5, 384);
            this.tbl27.Margin = new System.Windows.Forms.Padding(4);
            this.tbl27.Name = "tbl27";
            this.tbl27.RowCount = 1;
            this.tbl27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl27.Size = new System.Drawing.Size(356, 28);
            this.tbl27.TabIndex = 7;
            // 
            // rd31d
            // 
            this.rd31d.AutoSize = true;
            this.rd31d.Location = new System.Drawing.Point(254, 5);
            this.rd31d.Margin = new System.Windows.Forms.Padding(4);
            this.rd31d.Name = "rd31d";
            this.rd31d.Size = new System.Drawing.Size(17, 16);
            this.rd31d.TabIndex = 4;
            this.rd31d.TabStop = true;
            this.rd31d.Tag = "D";
            this.rd31d.UseVisualStyleBackColor = true;
            // 
            // rd31c
            // 
            this.rd31c.AutoSize = true;
            this.rd31c.Location = new System.Drawing.Point(194, 5);
            this.rd31c.Margin = new System.Windows.Forms.Padding(4);
            this.rd31c.Name = "rd31c";
            this.rd31c.Size = new System.Drawing.Size(17, 16);
            this.rd31c.TabIndex = 3;
            this.rd31c.TabStop = true;
            this.rd31c.Tag = "C";
            this.rd31c.UseVisualStyleBackColor = true;
            // 
            // rd31b
            // 
            this.rd31b.AutoSize = true;
            this.rd31b.Location = new System.Drawing.Point(131, 5);
            this.rd31b.Margin = new System.Windows.Forms.Padding(4);
            this.rd31b.Name = "rd31b";
            this.rd31b.Size = new System.Drawing.Size(17, 16);
            this.rd31b.TabIndex = 2;
            this.rd31b.TabStop = true;
            this.rd31b.Tag = "B";
            this.rd31b.UseVisualStyleBackColor = true;
            // 
            // rd31a
            // 
            this.rd31a.AutoSize = true;
            this.rd31a.Location = new System.Drawing.Point(80, 5);
            this.rd31a.Margin = new System.Windows.Forms.Padding(4);
            this.rd31a.Name = "rd31a";
            this.rd31a.Size = new System.Drawing.Size(17, 16);
            this.rd31a.TabIndex = 0;
            this.rd31a.TabStop = true;
            this.rd31a.Tag = "A";
            this.rd31a.UseVisualStyleBackColor = true;
            // 
            // panel80
            // 
            this.panel80.Controls.Add(this.lbl27);
            this.panel80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel80.Location = new System.Drawing.Point(5, 5);
            this.panel80.Margin = new System.Windows.Forms.Padding(4);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(66, 18);
            this.panel80.TabIndex = 5;
            // 
            // lbl27
            // 
            this.lbl27.AutoSize = true;
            this.lbl27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl27.Location = new System.Drawing.Point(4, 2);
            this.lbl27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(64, 17);
            this.lbl27.TabIndex = 1;
            this.lbl27.Text = "Câu 27:";
            this.lbl27.Click += new System.EventHandler(this.lbl27_Click);
            // 
            // tbl30
            // 
            this.tbl30.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl30.ColumnCount = 5;
            this.tbl30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.85714F));
            this.tbl30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.14286F));
            this.tbl30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tbl30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 104F));
            this.tbl30.Controls.Add(this.rd30d, 4, 0);
            this.tbl30.Controls.Add(this.rd30c, 3, 0);
            this.tbl30.Controls.Add(this.rd30b, 2, 0);
            this.tbl30.Controls.Add(this.rd30a, 1, 0);
            this.tbl30.Controls.Add(this.panel81, 0, 0);
            this.tbl30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl30.Location = new System.Drawing.Point(5, 349);
            this.tbl30.Margin = new System.Windows.Forms.Padding(4);
            this.tbl30.Name = "tbl30";
            this.tbl30.RowCount = 1;
            this.tbl30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl30.Size = new System.Drawing.Size(356, 26);
            this.tbl30.TabIndex = 6;
            // 
            // rd30d
            // 
            this.rd30d.AutoSize = true;
            this.rd30d.Location = new System.Drawing.Point(254, 5);
            this.rd30d.Margin = new System.Windows.Forms.Padding(4);
            this.rd30d.Name = "rd30d";
            this.rd30d.Size = new System.Drawing.Size(17, 16);
            this.rd30d.TabIndex = 4;
            this.rd30d.TabStop = true;
            this.rd30d.Tag = "D";
            this.rd30d.UseVisualStyleBackColor = true;
            // 
            // rd30c
            // 
            this.rd30c.AutoSize = true;
            this.rd30c.Location = new System.Drawing.Point(193, 5);
            this.rd30c.Margin = new System.Windows.Forms.Padding(4);
            this.rd30c.Name = "rd30c";
            this.rd30c.Size = new System.Drawing.Size(17, 16);
            this.rd30c.TabIndex = 3;
            this.rd30c.TabStop = true;
            this.rd30c.Tag = "C";
            this.rd30c.UseVisualStyleBackColor = true;
            // 
            // rd30b
            // 
            this.rd30b.AutoSize = true;
            this.rd30b.Location = new System.Drawing.Point(131, 5);
            this.rd30b.Margin = new System.Windows.Forms.Padding(4);
            this.rd30b.Name = "rd30b";
            this.rd30b.Size = new System.Drawing.Size(17, 16);
            this.rd30b.TabIndex = 2;
            this.rd30b.TabStop = true;
            this.rd30b.Tag = "B";
            this.rd30b.UseVisualStyleBackColor = true;
            // 
            // rd30a
            // 
            this.rd30a.AutoSize = true;
            this.rd30a.Location = new System.Drawing.Point(78, 5);
            this.rd30a.Margin = new System.Windows.Forms.Padding(4);
            this.rd30a.Name = "rd30a";
            this.rd30a.Size = new System.Drawing.Size(17, 16);
            this.rd30a.TabIndex = 0;
            this.rd30a.TabStop = true;
            this.rd30a.Tag = "A";
            this.rd30a.UseVisualStyleBackColor = true;
            // 
            // panel81
            // 
            this.panel81.Controls.Add(this.lbl26);
            this.panel81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel81.Location = new System.Drawing.Point(5, 5);
            this.panel81.Margin = new System.Windows.Forms.Padding(4);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(64, 16);
            this.panel81.TabIndex = 5;
            // 
            // lbl26
            // 
            this.lbl26.AutoSize = true;
            this.lbl26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl26.Location = new System.Drawing.Point(4, 0);
            this.lbl26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(64, 17);
            this.lbl26.TabIndex = 1;
            this.lbl26.Text = "Câu 26:";
            this.lbl26.Click += new System.EventHandler(this.lbl26_Click);
            // 
            // tbl25
            // 
            this.tbl25.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl25.ColumnCount = 5;
            this.tbl25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.14286F));
            this.tbl25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.85714F));
            this.tbl25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tbl25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 104F));
            this.tbl25.Controls.Add(this.rd29d, 4, 0);
            this.tbl25.Controls.Add(this.rd29c, 3, 0);
            this.tbl25.Controls.Add(this.rd29b, 2, 0);
            this.tbl25.Controls.Add(this.rd29a, 1, 0);
            this.tbl25.Controls.Add(this.panel82, 0, 0);
            this.tbl25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl25.Location = new System.Drawing.Point(5, 314);
            this.tbl25.Margin = new System.Windows.Forms.Padding(4);
            this.tbl25.Name = "tbl25";
            this.tbl25.RowCount = 1;
            this.tbl25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl25.Size = new System.Drawing.Size(356, 26);
            this.tbl25.TabIndex = 5;
            // 
            // rd29d
            // 
            this.rd29d.AutoSize = true;
            this.rd29d.Location = new System.Drawing.Point(254, 5);
            this.rd29d.Margin = new System.Windows.Forms.Padding(4);
            this.rd29d.Name = "rd29d";
            this.rd29d.Size = new System.Drawing.Size(17, 16);
            this.rd29d.TabIndex = 4;
            this.rd29d.TabStop = true;
            this.rd29d.Tag = "D";
            this.rd29d.UseVisualStyleBackColor = true;
            // 
            // rd29c
            // 
            this.rd29c.AutoSize = true;
            this.rd29c.Location = new System.Drawing.Point(192, 5);
            this.rd29c.Margin = new System.Windows.Forms.Padding(4);
            this.rd29c.Name = "rd29c";
            this.rd29c.Size = new System.Drawing.Size(17, 16);
            this.rd29c.TabIndex = 3;
            this.rd29c.TabStop = true;
            this.rd29c.Tag = "C";
            this.rd29c.UseVisualStyleBackColor = true;
            // 
            // rd29b
            // 
            this.rd29b.AutoSize = true;
            this.rd29b.Location = new System.Drawing.Point(131, 5);
            this.rd29b.Margin = new System.Windows.Forms.Padding(4);
            this.rd29b.Name = "rd29b";
            this.rd29b.Size = new System.Drawing.Size(17, 16);
            this.rd29b.TabIndex = 2;
            this.rd29b.TabStop = true;
            this.rd29b.Tag = "B";
            this.rd29b.UseVisualStyleBackColor = true;
            // 
            // rd29a
            // 
            this.rd29a.AutoSize = true;
            this.rd29a.Location = new System.Drawing.Point(77, 5);
            this.rd29a.Margin = new System.Windows.Forms.Padding(4);
            this.rd29a.Name = "rd29a";
            this.rd29a.Size = new System.Drawing.Size(17, 16);
            this.rd29a.TabIndex = 0;
            this.rd29a.TabStop = true;
            this.rd29a.Tag = "A";
            this.rd29a.UseVisualStyleBackColor = true;
            // 
            // panel82
            // 
            this.panel82.Controls.Add(this.lbl25);
            this.panel82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel82.Location = new System.Drawing.Point(5, 5);
            this.panel82.Margin = new System.Windows.Forms.Padding(4);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(63, 16);
            this.panel82.TabIndex = 5;
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl25.Location = new System.Drawing.Point(4, 2);
            this.lbl25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(64, 17);
            this.lbl25.TabIndex = 1;
            this.lbl25.Text = "Câu 25:";
            this.lbl25.Click += new System.EventHandler(this.lbl25_Click);
            // 
            // tbl24
            // 
            this.tbl24.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl24.ColumnCount = 5;
            this.tbl24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.42857F));
            this.tbl24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.57143F));
            this.tbl24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tbl24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.tbl24.Controls.Add(this.rd28d, 4, 0);
            this.tbl24.Controls.Add(this.rd28c, 3, 0);
            this.tbl24.Controls.Add(this.rd28b, 2, 0);
            this.tbl24.Controls.Add(this.rd28a, 1, 0);
            this.tbl24.Controls.Add(this.panel83, 0, 0);
            this.tbl24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl24.Location = new System.Drawing.Point(5, 279);
            this.tbl24.Margin = new System.Windows.Forms.Padding(4);
            this.tbl24.Name = "tbl24";
            this.tbl24.RowCount = 1;
            this.tbl24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl24.Size = new System.Drawing.Size(356, 26);
            this.tbl24.TabIndex = 4;
            // 
            // rd28d
            // 
            this.rd28d.AutoSize = true;
            this.rd28d.Location = new System.Drawing.Point(271, 5);
            this.rd28d.Margin = new System.Windows.Forms.Padding(4);
            this.rd28d.Name = "rd28d";
            this.rd28d.Size = new System.Drawing.Size(17, 16);
            this.rd28d.TabIndex = 4;
            this.rd28d.TabStop = true;
            this.rd28d.Tag = "D";
            this.rd28d.UseVisualStyleBackColor = true;
            // 
            // rd28c
            // 
            this.rd28c.AutoSize = true;
            this.rd28c.Location = new System.Drawing.Point(208, 5);
            this.rd28c.Margin = new System.Windows.Forms.Padding(4);
            this.rd28c.Name = "rd28c";
            this.rd28c.Size = new System.Drawing.Size(17, 16);
            this.rd28c.TabIndex = 3;
            this.rd28c.TabStop = true;
            this.rd28c.Tag = "C";
            this.rd28c.UseVisualStyleBackColor = true;
            // 
            // rd28b
            // 
            this.rd28b.AutoSize = true;
            this.rd28b.Location = new System.Drawing.Point(147, 5);
            this.rd28b.Margin = new System.Windows.Forms.Padding(4);
            this.rd28b.Name = "rd28b";
            this.rd28b.Size = new System.Drawing.Size(17, 16);
            this.rd28b.TabIndex = 2;
            this.rd28b.TabStop = true;
            this.rd28b.Tag = "B";
            this.rd28b.UseVisualStyleBackColor = true;
            // 
            // rd28a
            // 
            this.rd28a.AutoSize = true;
            this.rd28a.Location = new System.Drawing.Point(85, 5);
            this.rd28a.Margin = new System.Windows.Forms.Padding(4);
            this.rd28a.Name = "rd28a";
            this.rd28a.Size = new System.Drawing.Size(17, 16);
            this.rd28a.TabIndex = 0;
            this.rd28a.TabStop = true;
            this.rd28a.Tag = "A";
            this.rd28a.UseVisualStyleBackColor = true;
            // 
            // panel83
            // 
            this.panel83.Controls.Add(this.lbl24);
            this.panel83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel83.Location = new System.Drawing.Point(5, 5);
            this.panel83.Margin = new System.Windows.Forms.Padding(4);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(71, 16);
            this.panel83.TabIndex = 5;
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl24.Location = new System.Drawing.Point(4, 0);
            this.lbl24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(64, 17);
            this.lbl24.TabIndex = 1;
            this.lbl24.Text = "Câu 24:";
            this.lbl24.Click += new System.EventHandler(this.lbl24_Click);
            // 
            // tbl23
            // 
            this.tbl23.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl23.ColumnCount = 5;
            this.tbl23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.11511F));
            this.tbl23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.88489F));
            this.tbl23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tbl23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tbl23.Controls.Add(this.rd27d, 4, 0);
            this.tbl23.Controls.Add(this.rd27c, 3, 0);
            this.tbl23.Controls.Add(this.rd27b, 2, 0);
            this.tbl23.Controls.Add(this.rd27a, 1, 0);
            this.tbl23.Controls.Add(this.panel84, 0, 0);
            this.tbl23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl23.Location = new System.Drawing.Point(5, 244);
            this.tbl23.Margin = new System.Windows.Forms.Padding(4);
            this.tbl23.Name = "tbl23";
            this.tbl23.RowCount = 1;
            this.tbl23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl23.Size = new System.Drawing.Size(356, 26);
            this.tbl23.TabIndex = 3;
            // 
            // rd27d
            // 
            this.rd27d.AutoSize = true;
            this.rd27d.Location = new System.Drawing.Point(269, 5);
            this.rd27d.Margin = new System.Windows.Forms.Padding(4);
            this.rd27d.Name = "rd27d";
            this.rd27d.Size = new System.Drawing.Size(17, 16);
            this.rd27d.TabIndex = 4;
            this.rd27d.TabStop = true;
            this.rd27d.Tag = "D";
            this.rd27d.UseVisualStyleBackColor = true;
            // 
            // rd27c
            // 
            this.rd27c.AutoSize = true;
            this.rd27c.Location = new System.Drawing.Point(207, 5);
            this.rd27c.Margin = new System.Windows.Forms.Padding(4);
            this.rd27c.Name = "rd27c";
            this.rd27c.Size = new System.Drawing.Size(17, 16);
            this.rd27c.TabIndex = 3;
            this.rd27c.TabStop = true;
            this.rd27c.Tag = "C";
            this.rd27c.UseVisualStyleBackColor = true;
            // 
            // rd27b
            // 
            this.rd27b.AutoSize = true;
            this.rd27b.Location = new System.Drawing.Point(146, 5);
            this.rd27b.Margin = new System.Windows.Forms.Padding(4);
            this.rd27b.Name = "rd27b";
            this.rd27b.Size = new System.Drawing.Size(17, 16);
            this.rd27b.TabIndex = 2;
            this.rd27b.TabStop = true;
            this.rd27b.Tag = "B";
            this.rd27b.UseVisualStyleBackColor = true;
            // 
            // rd27a
            // 
            this.rd27a.AutoSize = true;
            this.rd27a.Location = new System.Drawing.Point(84, 5);
            this.rd27a.Margin = new System.Windows.Forms.Padding(4);
            this.rd27a.Name = "rd27a";
            this.rd27a.Size = new System.Drawing.Size(17, 16);
            this.rd27a.TabIndex = 0;
            this.rd27a.TabStop = true;
            this.rd27a.Tag = "A";
            this.rd27a.UseVisualStyleBackColor = true;
            // 
            // panel84
            // 
            this.panel84.Controls.Add(this.lbl23);
            this.panel84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel84.Location = new System.Drawing.Point(5, 5);
            this.panel84.Margin = new System.Windows.Forms.Padding(4);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(70, 16);
            this.panel84.TabIndex = 5;
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl23.Location = new System.Drawing.Point(4, 0);
            this.lbl23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(64, 17);
            this.lbl23.TabIndex = 1;
            this.lbl23.Text = "Câu 23:";
            this.lbl23.Click += new System.EventHandler(this.lbl22_Click);
            // 
            // tbl22
            // 
            this.tbl22.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl22.ColumnCount = 5;
            this.tbl22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.7971F));
            this.tbl22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.2029F));
            this.tbl22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tbl22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.tbl22.Controls.Add(this.rd26d, 4, 0);
            this.tbl22.Controls.Add(this.rd26c, 3, 0);
            this.tbl22.Controls.Add(this.rd26b, 2, 0);
            this.tbl22.Controls.Add(this.rd26a, 1, 0);
            this.tbl22.Controls.Add(this.panel85, 0, 0);
            this.tbl22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl22.Location = new System.Drawing.Point(5, 209);
            this.tbl22.Margin = new System.Windows.Forms.Padding(4);
            this.tbl22.Name = "tbl22";
            this.tbl22.RowCount = 1;
            this.tbl22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl22.Size = new System.Drawing.Size(356, 26);
            this.tbl22.TabIndex = 2;
            // 
            // rd26d
            // 
            this.rd26d.AutoSize = true;
            this.rd26d.Location = new System.Drawing.Point(266, 5);
            this.rd26d.Margin = new System.Windows.Forms.Padding(4);
            this.rd26d.Name = "rd26d";
            this.rd26d.Size = new System.Drawing.Size(17, 16);
            this.rd26d.TabIndex = 4;
            this.rd26d.TabStop = true;
            this.rd26d.Tag = "D";
            this.rd26d.UseVisualStyleBackColor = true;
            // 
            // rd26c
            // 
            this.rd26c.AutoSize = true;
            this.rd26c.Location = new System.Drawing.Point(205, 5);
            this.rd26c.Margin = new System.Windows.Forms.Padding(4);
            this.rd26c.Name = "rd26c";
            this.rd26c.Size = new System.Drawing.Size(17, 16);
            this.rd26c.TabIndex = 3;
            this.rd26c.TabStop = true;
            this.rd26c.Tag = "C";
            this.rd26c.UseVisualStyleBackColor = true;
            // 
            // rd26b
            // 
            this.rd26b.AutoSize = true;
            this.rd26b.Location = new System.Drawing.Point(145, 5);
            this.rd26b.Margin = new System.Windows.Forms.Padding(4);
            this.rd26b.Name = "rd26b";
            this.rd26b.Size = new System.Drawing.Size(17, 16);
            this.rd26b.TabIndex = 2;
            this.rd26b.TabStop = true;
            this.rd26b.Tag = "B";
            this.rd26b.UseVisualStyleBackColor = true;
            // 
            // rd26a
            // 
            this.rd26a.AutoSize = true;
            this.rd26a.Location = new System.Drawing.Point(83, 5);
            this.rd26a.Margin = new System.Windows.Forms.Padding(4);
            this.rd26a.Name = "rd26a";
            this.rd26a.Size = new System.Drawing.Size(17, 16);
            this.rd26a.TabIndex = 0;
            this.rd26a.TabStop = true;
            this.rd26a.Tag = "A";
            this.rd26a.UseVisualStyleBackColor = true;
            // 
            // panel85
            // 
            this.panel85.Controls.Add(this.lbl22);
            this.panel85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel85.Location = new System.Drawing.Point(5, 5);
            this.panel85.Margin = new System.Windows.Forms.Padding(4);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(69, 16);
            this.panel85.TabIndex = 5;
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl22.Location = new System.Drawing.Point(4, 2);
            this.lbl22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(64, 17);
            this.lbl22.TabIndex = 1;
            this.lbl22.Text = "Câu 22:";
            this.lbl22.Click += new System.EventHandler(this.lbl22_Click);
            // 
            // tbl21
            // 
            this.tbl21.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl21.ColumnCount = 5;
            this.tbl21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.03356F));
            this.tbl21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.96644F));
            this.tbl21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tbl21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tbl21.Controls.Add(this.rd25d, 4, 0);
            this.tbl21.Controls.Add(this.rd25c, 3, 0);
            this.tbl21.Controls.Add(this.rd25b, 2, 0);
            this.tbl21.Controls.Add(this.rd25a, 1, 0);
            this.tbl21.Controls.Add(this.panel86, 0, 0);
            this.tbl21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl21.Location = new System.Drawing.Point(5, 174);
            this.tbl21.Margin = new System.Windows.Forms.Padding(4);
            this.tbl21.Name = "tbl21";
            this.tbl21.RowCount = 1;
            this.tbl21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl21.Size = new System.Drawing.Size(356, 26);
            this.tbl21.TabIndex = 1;
            // 
            // rd25d
            // 
            this.rd25d.AutoSize = true;
            this.rd25d.Location = new System.Drawing.Point(251, 5);
            this.rd25d.Margin = new System.Windows.Forms.Padding(4);
            this.rd25d.Name = "rd25d";
            this.rd25d.Size = new System.Drawing.Size(17, 16);
            this.rd25d.TabIndex = 4;
            this.rd25d.TabStop = true;
            this.rd25d.Tag = "D";
            this.rd25d.UseVisualStyleBackColor = true;
            // 
            // rd25c
            // 
            this.rd25c.AutoSize = true;
            this.rd25c.Location = new System.Drawing.Point(190, 5);
            this.rd25c.Margin = new System.Windows.Forms.Padding(4);
            this.rd25c.Name = "rd25c";
            this.rd25c.Size = new System.Drawing.Size(17, 16);
            this.rd25c.TabIndex = 3;
            this.rd25c.TabStop = true;
            this.rd25c.Tag = "C";
            this.rd25c.UseVisualStyleBackColor = true;
            // 
            // rd25b
            // 
            this.rd25b.AutoSize = true;
            this.rd25b.Location = new System.Drawing.Point(129, 5);
            this.rd25b.Margin = new System.Windows.Forms.Padding(4);
            this.rd25b.Name = "rd25b";
            this.rd25b.Size = new System.Drawing.Size(17, 16);
            this.rd25b.TabIndex = 2;
            this.rd25b.TabStop = true;
            this.rd25b.Tag = "B";
            this.rd25b.UseVisualStyleBackColor = true;
            // 
            // rd25a
            // 
            this.rd25a.AutoSize = true;
            this.rd25a.Location = new System.Drawing.Point(73, 5);
            this.rd25a.Margin = new System.Windows.Forms.Padding(4);
            this.rd25a.Name = "rd25a";
            this.rd25a.Size = new System.Drawing.Size(17, 16);
            this.rd25a.TabIndex = 0;
            this.rd25a.TabStop = true;
            this.rd25a.Tag = "A";
            this.rd25a.UseVisualStyleBackColor = true;
            // 
            // panel86
            // 
            this.panel86.Controls.Add(this.lbl21);
            this.panel86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel86.Location = new System.Drawing.Point(5, 5);
            this.panel86.Margin = new System.Windows.Forms.Padding(4);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(59, 16);
            this.panel86.TabIndex = 5;
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl21.Location = new System.Drawing.Point(4, 0);
            this.lbl21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(64, 17);
            this.lbl21.TabIndex = 0;
            this.lbl21.Text = "Câu 21:";
            this.lbl21.Click += new System.EventHandler(this.lbl21_Click);
            // 
            // panel87
            // 
            this.panel87.Controls.Add(this.tableLayoutPanel79);
            this.panel87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel87.Location = new System.Drawing.Point(5, 5);
            this.panel87.Margin = new System.Windows.Forms.Padding(4);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(356, 160);
            this.panel87.TabIndex = 0;
            // 
            // tableLayoutPanel79
            // 
            this.tableLayoutPanel79.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel79.ColumnCount = 5;
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.05405F));
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.94595F));
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tableLayoutPanel79.Controls.Add(this.panel88, 4, 0);
            this.tableLayoutPanel79.Controls.Add(this.panel89, 3, 0);
            this.tableLayoutPanel79.Controls.Add(this.panel90, 0, 0);
            this.tableLayoutPanel79.Controls.Add(this.panel91, 1, 0);
            this.tableLayoutPanel79.Controls.Add(this.panel93, 2, 0);
            this.tableLayoutPanel79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel79.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel79.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel79.Name = "tableLayoutPanel79";
            this.tableLayoutPanel79.RowCount = 1;
            this.tableLayoutPanel79.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel79.Size = new System.Drawing.Size(356, 160);
            this.tableLayoutPanel79.TabIndex = 2;
            // 
            // panel88
            // 
            this.panel88.Controls.Add(this.label21);
            this.panel88.Controls.Add(this.label13);
            this.panel88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel88.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel88.Location = new System.Drawing.Point(251, 5);
            this.panel88.Margin = new System.Windows.Forms.Padding(4);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(100, 150);
            this.panel88.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label21.Location = new System.Drawing.Point(6, 72);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 13);
            this.label21.TabIndex = 10;
            this.label21.Text = "Đáp án";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.Location = new System.Drawing.Point(12, 87);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 32);
            this.label13.TabIndex = 4;
            this.label13.Text = "D";
            // 
            // panel89
            // 
            this.panel89.Controls.Add(this.label20);
            this.panel89.Controls.Add(this.label8);
            this.panel89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel89.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel89.Location = new System.Drawing.Point(189, 5);
            this.panel89.Margin = new System.Windows.Forms.Padding(4);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(53, 150);
            this.panel89.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label20.Location = new System.Drawing.Point(1, 71);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 13);
            this.label20.TabIndex = 9;
            this.label20.Text = "Đáp án";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(9, 87);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 32);
            this.label8.TabIndex = 3;
            this.label8.Text = "C";
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.label11);
            this.panel90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel90.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel90.Location = new System.Drawing.Point(5, 5);
            this.panel90.Margin = new System.Windows.Forms.Padding(4);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(59, 150);
            this.panel90.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.Location = new System.Drawing.Point(5, 74);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 16);
            this.label11.TabIndex = 3;
            this.label11.Text = "Câu hỏi";
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.panel92);
            this.panel91.Controls.Add(this.label89);
            this.panel91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel91.Location = new System.Drawing.Point(73, 5);
            this.panel91.Margin = new System.Windows.Forms.Padding(4);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(48, 150);
            this.panel91.TabIndex = 0;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.label18);
            this.panel92.Controls.Add(this.label6);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel92.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel92.Location = new System.Drawing.Point(0, 0);
            this.panel92.Margin = new System.Windows.Forms.Padding(4);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(48, 150);
            this.panel92.TabIndex = 2;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label18.Location = new System.Drawing.Point(4, 71);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Đáp án";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(10, 88);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 32);
            this.label6.TabIndex = 2;
            this.label6.Text = "A";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label89.Location = new System.Drawing.Point(2, 0);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(18, 17);
            this.label89.TabIndex = 0;
            this.label89.Text = "A";
            // 
            // panel93
            // 
            this.panel93.Controls.Add(this.label19);
            this.panel93.Controls.Add(this.label7);
            this.panel93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel93.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel93.Location = new System.Drawing.Point(130, 5);
            this.panel93.Margin = new System.Windows.Forms.Padding(4);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(50, 150);
            this.panel93.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label19.Location = new System.Drawing.Point(1, 71);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 13);
            this.label19.TabIndex = 8;
            this.label19.Text = "Đáp án";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(6, 88);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 32);
            this.label7.TabIndex = 2;
            this.label7.Text = "B";
            // 
            // tableLayoutPanelcot1
            // 
            this.tableLayoutPanelcot1.BackColor = System.Drawing.Color.Gainsboro;
            this.tableLayoutPanelcot1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanelcot1.ColumnCount = 1;
            this.tableLayoutPanelcot1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 401F));
            this.tableLayoutPanelcot1.Controls.Add(this.tbl20, 0, 20);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl19, 0, 19);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl18, 0, 18);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl17, 0, 17);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl16, 0, 16);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl15, 0, 15);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl14, 0, 14);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl13, 0, 13);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl12, 0, 12);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl11, 0, 11);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl10, 0, 10);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl9, 0, 9);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl8, 0, 8);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl7, 0, 7);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl6, 0, 6);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl5, 0, 5);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl4, 0, 4);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl3, 0, 3);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl2, 0, 2);
            this.tableLayoutPanelcot1.Controls.Add(this.tbl1, 0, 1);
            this.tableLayoutPanelcot1.Controls.Add(this.panel8, 0, 0);
            this.tableLayoutPanelcot1.Location = new System.Drawing.Point(1178, 4);
            this.tableLayoutPanelcot1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanelcot1.Name = "tableLayoutPanelcot1";
            this.tableLayoutPanelcot1.RowCount = 22;
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanelcot1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanelcot1.Size = new System.Drawing.Size(377, 909);
            this.tableLayoutPanelcot1.TabIndex = 36;
            // 
            // tbl20
            // 
            this.tbl20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl20.ColumnCount = 5;
            this.tbl20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.64198F));
            this.tbl20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.35802F));
            this.tbl20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tbl20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tbl20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 106F));
            this.tbl20.Controls.Add(this.rd20d, 4, 0);
            this.tbl20.Controls.Add(this.rd20c, 3, 0);
            this.tbl20.Controls.Add(this.rd20b, 2, 0);
            this.tbl20.Controls.Add(this.rd20a, 1, 0);
            this.tbl20.Controls.Add(this.panel27, 0, 0);
            this.tbl20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl20.Location = new System.Drawing.Point(5, 841);
            this.tbl20.Margin = new System.Windows.Forms.Padding(4);
            this.tbl20.Name = "tbl20";
            this.tbl20.RowCount = 1;
            this.tbl20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl20.Size = new System.Drawing.Size(393, 26);
            this.tbl20.TabIndex = 20;
            // 
            // rd20d
            // 
            this.rd20d.AutoSize = true;
            this.rd20d.Location = new System.Drawing.Point(289, 5);
            this.rd20d.Margin = new System.Windows.Forms.Padding(4);
            this.rd20d.Name = "rd20d";
            this.rd20d.Size = new System.Drawing.Size(17, 16);
            this.rd20d.TabIndex = 4;
            this.rd20d.TabStop = true;
            this.rd20d.Tag = "D";
            this.rd20d.UseVisualStyleBackColor = true;
            // 
            // rd20c
            // 
            this.rd20c.AutoSize = true;
            this.rd20c.Location = new System.Drawing.Point(223, 5);
            this.rd20c.Margin = new System.Windows.Forms.Padding(4);
            this.rd20c.Name = "rd20c";
            this.rd20c.Size = new System.Drawing.Size(17, 16);
            this.rd20c.TabIndex = 3;
            this.rd20c.TabStop = true;
            this.rd20c.Tag = "C";
            this.rd20c.UseVisualStyleBackColor = true;
            // 
            // rd20b
            // 
            this.rd20b.AutoSize = true;
            this.rd20b.Location = new System.Drawing.Point(156, 5);
            this.rd20b.Margin = new System.Windows.Forms.Padding(4);
            this.rd20b.Name = "rd20b";
            this.rd20b.Size = new System.Drawing.Size(17, 16);
            this.rd20b.TabIndex = 2;
            this.rd20b.TabStop = true;
            this.rd20b.Tag = "B";
            this.rd20b.UseVisualStyleBackColor = true;
            // 
            // rd20a
            // 
            this.rd20a.AutoSize = true;
            this.rd20a.Location = new System.Drawing.Point(93, 5);
            this.rd20a.Margin = new System.Windows.Forms.Padding(4);
            this.rd20a.Name = "rd20a";
            this.rd20a.Size = new System.Drawing.Size(17, 16);
            this.rd20a.TabIndex = 0;
            this.rd20a.TabStop = true;
            this.rd20a.Tag = "A";
            this.rd20a.UseVisualStyleBackColor = true;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.lbl20);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(5, 5);
            this.panel27.Margin = new System.Windows.Forms.Padding(4);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(79, 16);
            this.panel27.TabIndex = 5;
            // 
            // lbl20
            // 
            this.lbl20.AutoSize = true;
            this.lbl20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl20.Location = new System.Drawing.Point(-4, 2);
            this.lbl20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(64, 17);
            this.lbl20.TabIndex = 1;
            this.lbl20.Text = "Câu 20:";
            this.lbl20.Click += new System.EventHandler(this.lbl20_Click);
            // 
            // tbl19
            // 
            this.tbl19.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl19.ColumnCount = 5;
            this.tbl19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.1195F));
            this.tbl19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.8805F));
            this.tbl19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tbl19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tbl19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tbl19.Controls.Add(this.rd19d, 4, 0);
            this.tbl19.Controls.Add(this.rd19c, 3, 0);
            this.tbl19.Controls.Add(this.rd19b, 2, 0);
            this.tbl19.Controls.Add(this.rd19a, 1, 0);
            this.tbl19.Controls.Add(this.panel26, 0, 0);
            this.tbl19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl19.Location = new System.Drawing.Point(5, 806);
            this.tbl19.Margin = new System.Windows.Forms.Padding(4);
            this.tbl19.Name = "tbl19";
            this.tbl19.RowCount = 1;
            this.tbl19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl19.Size = new System.Drawing.Size(393, 26);
            this.tbl19.TabIndex = 19;
            // 
            // rd19d
            // 
            this.rd19d.AutoSize = true;
            this.rd19d.Location = new System.Drawing.Point(288, 5);
            this.rd19d.Margin = new System.Windows.Forms.Padding(4);
            this.rd19d.Name = "rd19d";
            this.rd19d.Size = new System.Drawing.Size(17, 16);
            this.rd19d.TabIndex = 4;
            this.rd19d.TabStop = true;
            this.rd19d.Tag = "D";
            this.rd19d.UseVisualStyleBackColor = true;
            // 
            // rd19c
            // 
            this.rd19c.AutoSize = true;
            this.rd19c.Location = new System.Drawing.Point(223, 5);
            this.rd19c.Margin = new System.Windows.Forms.Padding(4);
            this.rd19c.Name = "rd19c";
            this.rd19c.Size = new System.Drawing.Size(17, 16);
            this.rd19c.TabIndex = 3;
            this.rd19c.TabStop = true;
            this.rd19c.Tag = "C";
            this.rd19c.UseVisualStyleBackColor = true;
            // 
            // rd19b
            // 
            this.rd19b.AutoSize = true;
            this.rd19b.Location = new System.Drawing.Point(156, 5);
            this.rd19b.Margin = new System.Windows.Forms.Padding(4);
            this.rd19b.Name = "rd19b";
            this.rd19b.Size = new System.Drawing.Size(17, 16);
            this.rd19b.TabIndex = 2;
            this.rd19b.TabStop = true;
            this.rd19b.Tag = "B";
            this.rd19b.UseVisualStyleBackColor = true;
            // 
            // rd19a
            // 
            this.rd19a.AutoSize = true;
            this.rd19a.Location = new System.Drawing.Point(94, 5);
            this.rd19a.Margin = new System.Windows.Forms.Padding(4);
            this.rd19a.Name = "rd19a";
            this.rd19a.Size = new System.Drawing.Size(17, 16);
            this.rd19a.TabIndex = 0;
            this.rd19a.TabStop = true;
            this.rd19a.Tag = "A";
            this.rd19a.UseVisualStyleBackColor = true;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.lbl19);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(5, 5);
            this.panel26.Margin = new System.Windows.Forms.Padding(4);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(80, 16);
            this.panel26.TabIndex = 5;
            // 
            // lbl19
            // 
            this.lbl19.AutoSize = true;
            this.lbl19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl19.Location = new System.Drawing.Point(-5, 2);
            this.lbl19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(64, 17);
            this.lbl19.TabIndex = 1;
            this.lbl19.Text = "Câu 19:";
            this.lbl19.Click += new System.EventHandler(this.lbl19_Click);
            // 
            // tbl18
            // 
            this.tbl18.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl18.ColumnCount = 5;
            this.tbl18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.59872F));
            this.tbl18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.40128F));
            this.tbl18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tbl18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tbl18.Controls.Add(this.rd18d, 4, 0);
            this.tbl18.Controls.Add(this.rd18c, 3, 0);
            this.tbl18.Controls.Add(this.rd18b, 2, 0);
            this.tbl18.Controls.Add(this.rd18a, 1, 0);
            this.tbl18.Controls.Add(this.panel25, 0, 0);
            this.tbl18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl18.Location = new System.Drawing.Point(5, 771);
            this.tbl18.Margin = new System.Windows.Forms.Padding(4);
            this.tbl18.Name = "tbl18";
            this.tbl18.RowCount = 1;
            this.tbl18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl18.Size = new System.Drawing.Size(393, 26);
            this.tbl18.TabIndex = 18;
            this.tbl18.Paint += new System.Windows.Forms.PaintEventHandler(this.tbl18_Paint);
            // 
            // rd18d
            // 
            this.rd18d.AutoSize = true;
            this.rd18d.Location = new System.Drawing.Point(288, 5);
            this.rd18d.Margin = new System.Windows.Forms.Padding(4);
            this.rd18d.Name = "rd18d";
            this.rd18d.Size = new System.Drawing.Size(17, 16);
            this.rd18d.TabIndex = 4;
            this.rd18d.TabStop = true;
            this.rd18d.Tag = "D";
            this.rd18d.UseVisualStyleBackColor = true;
            // 
            // rd18c
            // 
            this.rd18c.AutoSize = true;
            this.rd18c.Location = new System.Drawing.Point(223, 5);
            this.rd18c.Margin = new System.Windows.Forms.Padding(4);
            this.rd18c.Name = "rd18c";
            this.rd18c.Size = new System.Drawing.Size(17, 16);
            this.rd18c.TabIndex = 3;
            this.rd18c.TabStop = true;
            this.rd18c.Tag = "C";
            this.rd18c.UseVisualStyleBackColor = true;
            // 
            // rd18b
            // 
            this.rd18b.AutoSize = true;
            this.rd18b.Location = new System.Drawing.Point(154, 5);
            this.rd18b.Margin = new System.Windows.Forms.Padding(4);
            this.rd18b.Name = "rd18b";
            this.rd18b.Size = new System.Drawing.Size(17, 16);
            this.rd18b.TabIndex = 2;
            this.rd18b.TabStop = true;
            this.rd18b.Tag = "B";
            this.rd18b.UseVisualStyleBackColor = true;
            // 
            // rd18a
            // 
            this.rd18a.AutoSize = true;
            this.rd18a.Location = new System.Drawing.Point(92, 5);
            this.rd18a.Margin = new System.Windows.Forms.Padding(4);
            this.rd18a.Name = "rd18a";
            this.rd18a.Size = new System.Drawing.Size(17, 16);
            this.rd18a.TabIndex = 0;
            this.rd18a.TabStop = true;
            this.rd18a.Tag = "A";
            this.rd18a.UseVisualStyleBackColor = true;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.lbl18);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(5, 5);
            this.panel25.Margin = new System.Windows.Forms.Padding(4);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(78, 16);
            this.panel25.TabIndex = 5;
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl18.Location = new System.Drawing.Point(-5, 2);
            this.lbl18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(64, 17);
            this.lbl18.TabIndex = 1;
            this.lbl18.Text = "Câu 18:";
            this.lbl18.Click += new System.EventHandler(this.lbl18_Click);
            // 
            // tbl17
            // 
            this.tbl17.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl17.ColumnCount = 5;
            this.tbl17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.96178F));
            this.tbl17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.03822F));
            this.tbl17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tbl17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tbl17.Controls.Add(this.rd17d, 4, 0);
            this.tbl17.Controls.Add(this.rd17c, 3, 0);
            this.tbl17.Controls.Add(this.rd17b, 2, 0);
            this.tbl17.Controls.Add(this.rd17a, 1, 0);
            this.tbl17.Controls.Add(this.panel24, 0, 0);
            this.tbl17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl17.Location = new System.Drawing.Point(5, 734);
            this.tbl17.Margin = new System.Windows.Forms.Padding(4);
            this.tbl17.Name = "tbl17";
            this.tbl17.RowCount = 1;
            this.tbl17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl17.Size = new System.Drawing.Size(393, 28);
            this.tbl17.TabIndex = 17;
            // 
            // rd17d
            // 
            this.rd17d.AutoSize = true;
            this.rd17d.Location = new System.Drawing.Point(295, 5);
            this.rd17d.Margin = new System.Windows.Forms.Padding(4);
            this.rd17d.Name = "rd17d";
            this.rd17d.Size = new System.Drawing.Size(17, 16);
            this.rd17d.TabIndex = 4;
            this.rd17d.TabStop = true;
            this.rd17d.Tag = "D";
            this.rd17d.UseVisualStyleBackColor = true;
            // 
            // rd17c
            // 
            this.rd17c.AutoSize = true;
            this.rd17c.Location = new System.Drawing.Point(229, 5);
            this.rd17c.Margin = new System.Windows.Forms.Padding(4);
            this.rd17c.Name = "rd17c";
            this.rd17c.Size = new System.Drawing.Size(17, 16);
            this.rd17c.TabIndex = 3;
            this.rd17c.TabStop = true;
            this.rd17c.Tag = "C";
            this.rd17c.UseVisualStyleBackColor = true;
            // 
            // rd17b
            // 
            this.rd17b.AutoSize = true;
            this.rd17b.Location = new System.Drawing.Point(161, 5);
            this.rd17b.Margin = new System.Windows.Forms.Padding(4);
            this.rd17b.Name = "rd17b";
            this.rd17b.Size = new System.Drawing.Size(17, 16);
            this.rd17b.TabIndex = 2;
            this.rd17b.TabStop = true;
            this.rd17b.Tag = "B";
            this.rd17b.UseVisualStyleBackColor = true;
            // 
            // rd17a
            // 
            this.rd17a.AutoSize = true;
            this.rd17a.Location = new System.Drawing.Point(95, 5);
            this.rd17a.Margin = new System.Windows.Forms.Padding(4);
            this.rd17a.Name = "rd17a";
            this.rd17a.Size = new System.Drawing.Size(17, 16);
            this.rd17a.TabIndex = 0;
            this.rd17a.TabStop = true;
            this.rd17a.Tag = "A";
            this.rd17a.UseVisualStyleBackColor = true;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.lbl17);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(5, 5);
            this.panel24.Margin = new System.Windows.Forms.Padding(4);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(81, 18);
            this.panel24.TabIndex = 5;
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl17.Location = new System.Drawing.Point(-5, 0);
            this.lbl17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(64, 17);
            this.lbl17.TabIndex = 1;
            this.lbl17.Text = "Câu 17:";
            this.lbl17.Click += new System.EventHandler(this.lbl17_Click);
            // 
            // tbl16
            // 
            this.tbl16.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl16.ColumnCount = 5;
            this.tbl16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.96178F));
            this.tbl16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.03822F));
            this.tbl16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tbl16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tbl16.Controls.Add(this.rd16d, 4, 0);
            this.tbl16.Controls.Add(this.rd16c, 3, 0);
            this.tbl16.Controls.Add(this.rd16b, 2, 0);
            this.tbl16.Controls.Add(this.rd16a, 1, 0);
            this.tbl16.Controls.Add(this.panel23, 0, 0);
            this.tbl16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl16.Location = new System.Drawing.Point(5, 699);
            this.tbl16.Margin = new System.Windows.Forms.Padding(4);
            this.tbl16.Name = "tbl16";
            this.tbl16.RowCount = 1;
            this.tbl16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl16.Size = new System.Drawing.Size(393, 26);
            this.tbl16.TabIndex = 16;
            // 
            // rd16d
            // 
            this.rd16d.AutoSize = true;
            this.rd16d.Location = new System.Drawing.Point(295, 5);
            this.rd16d.Margin = new System.Windows.Forms.Padding(4);
            this.rd16d.Name = "rd16d";
            this.rd16d.Size = new System.Drawing.Size(17, 16);
            this.rd16d.TabIndex = 4;
            this.rd16d.TabStop = true;
            this.rd16d.Tag = "D";
            this.rd16d.UseVisualStyleBackColor = true;
            // 
            // rd16c
            // 
            this.rd16c.AutoSize = true;
            this.rd16c.Location = new System.Drawing.Point(230, 5);
            this.rd16c.Margin = new System.Windows.Forms.Padding(4);
            this.rd16c.Name = "rd16c";
            this.rd16c.Size = new System.Drawing.Size(17, 16);
            this.rd16c.TabIndex = 3;
            this.rd16c.TabStop = true;
            this.rd16c.Tag = "C";
            this.rd16c.UseVisualStyleBackColor = true;
            // 
            // rd16b
            // 
            this.rd16b.AutoSize = true;
            this.rd16b.Location = new System.Drawing.Point(161, 5);
            this.rd16b.Margin = new System.Windows.Forms.Padding(4);
            this.rd16b.Name = "rd16b";
            this.rd16b.Size = new System.Drawing.Size(17, 16);
            this.rd16b.TabIndex = 2;
            this.rd16b.TabStop = true;
            this.rd16b.Tag = "B";
            this.rd16b.UseVisualStyleBackColor = true;
            // 
            // rd16a
            // 
            this.rd16a.AutoSize = true;
            this.rd16a.Location = new System.Drawing.Point(95, 5);
            this.rd16a.Margin = new System.Windows.Forms.Padding(4);
            this.rd16a.Name = "rd16a";
            this.rd16a.Size = new System.Drawing.Size(17, 16);
            this.rd16a.TabIndex = 0;
            this.rd16a.TabStop = true;
            this.rd16a.Tag = "A";
            this.rd16a.UseVisualStyleBackColor = true;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.lbl16);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(5, 5);
            this.panel23.Margin = new System.Windows.Forms.Padding(4);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(81, 16);
            this.panel23.TabIndex = 5;
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl16.Location = new System.Drawing.Point(-5, -2);
            this.lbl16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(64, 17);
            this.lbl16.TabIndex = 1;
            this.lbl16.Text = "Câu 16:";
            this.lbl16.Click += new System.EventHandler(this.lbl16_Click);
            // 
            // tbl15
            // 
            this.tbl15.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl15.ColumnCount = 5;
            this.tbl15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.59872F));
            this.tbl15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.40128F));
            this.tbl15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tbl15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tbl15.Controls.Add(this.rd15d, 4, 0);
            this.tbl15.Controls.Add(this.rd15c, 3, 0);
            this.tbl15.Controls.Add(this.rd15b, 2, 0);
            this.tbl15.Controls.Add(this.rd15a, 1, 0);
            this.tbl15.Controls.Add(this.panel22, 0, 0);
            this.tbl15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl15.Location = new System.Drawing.Point(5, 664);
            this.tbl15.Margin = new System.Windows.Forms.Padding(4);
            this.tbl15.Name = "tbl15";
            this.tbl15.RowCount = 1;
            this.tbl15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl15.Size = new System.Drawing.Size(393, 26);
            this.tbl15.TabIndex = 15;
            // 
            // rd15d
            // 
            this.rd15d.AutoSize = true;
            this.rd15d.Location = new System.Drawing.Point(288, 5);
            this.rd15d.Margin = new System.Windows.Forms.Padding(4);
            this.rd15d.Name = "rd15d";
            this.rd15d.Size = new System.Drawing.Size(17, 16);
            this.rd15d.TabIndex = 4;
            this.rd15d.TabStop = true;
            this.rd15d.Tag = "D";
            this.rd15d.UseVisualStyleBackColor = true;
            // 
            // rd15c
            // 
            this.rd15c.AutoSize = true;
            this.rd15c.Location = new System.Drawing.Point(222, 5);
            this.rd15c.Margin = new System.Windows.Forms.Padding(4);
            this.rd15c.Name = "rd15c";
            this.rd15c.Size = new System.Drawing.Size(17, 16);
            this.rd15c.TabIndex = 3;
            this.rd15c.TabStop = true;
            this.rd15c.Tag = "C";
            this.rd15c.UseVisualStyleBackColor = true;
            // 
            // rd15b
            // 
            this.rd15b.AutoSize = true;
            this.rd15b.Location = new System.Drawing.Point(154, 5);
            this.rd15b.Margin = new System.Windows.Forms.Padding(4);
            this.rd15b.Name = "rd15b";
            this.rd15b.Size = new System.Drawing.Size(17, 16);
            this.rd15b.TabIndex = 2;
            this.rd15b.TabStop = true;
            this.rd15b.Tag = "B";
            this.rd15b.UseVisualStyleBackColor = true;
            // 
            // rd15a
            // 
            this.rd15a.AutoSize = true;
            this.rd15a.Location = new System.Drawing.Point(92, 5);
            this.rd15a.Margin = new System.Windows.Forms.Padding(4);
            this.rd15a.Name = "rd15a";
            this.rd15a.Size = new System.Drawing.Size(17, 16);
            this.rd15a.TabIndex = 0;
            this.rd15a.TabStop = true;
            this.rd15a.Tag = "A";
            this.rd15a.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.lbl15);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(5, 5);
            this.panel22.Margin = new System.Windows.Forms.Padding(4);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(78, 16);
            this.panel22.TabIndex = 5;
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl15.Location = new System.Drawing.Point(-4, 0);
            this.lbl15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(64, 17);
            this.lbl15.TabIndex = 1;
            this.lbl15.Text = "Câu 15:";
            this.lbl15.Click += new System.EventHandler(this.lbl15_Click);
            // 
            // tbl14
            // 
            this.tbl14.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl14.ColumnCount = 5;
            this.tbl14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.33333F));
            this.tbl14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.66667F));
            this.tbl14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tbl14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tbl14.Controls.Add(this.rd14d, 4, 0);
            this.tbl14.Controls.Add(this.rd14c, 3, 0);
            this.tbl14.Controls.Add(this.rd14b, 2, 0);
            this.tbl14.Controls.Add(this.rd14a, 1, 0);
            this.tbl14.Controls.Add(this.panel21, 0, 0);
            this.tbl14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl14.Location = new System.Drawing.Point(5, 629);
            this.tbl14.Margin = new System.Windows.Forms.Padding(4);
            this.tbl14.Name = "tbl14";
            this.tbl14.RowCount = 1;
            this.tbl14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl14.Size = new System.Drawing.Size(393, 26);
            this.tbl14.TabIndex = 14;
            // 
            // rd14d
            // 
            this.rd14d.AutoSize = true;
            this.rd14d.Location = new System.Drawing.Point(288, 5);
            this.rd14d.Margin = new System.Windows.Forms.Padding(4);
            this.rd14d.Name = "rd14d";
            this.rd14d.Size = new System.Drawing.Size(17, 16);
            this.rd14d.TabIndex = 4;
            this.rd14d.TabStop = true;
            this.rd14d.Tag = "D";
            this.rd14d.UseVisualStyleBackColor = true;
            // 
            // rd14c
            // 
            this.rd14c.AutoSize = true;
            this.rd14c.Location = new System.Drawing.Point(221, 5);
            this.rd14c.Margin = new System.Windows.Forms.Padding(4);
            this.rd14c.Name = "rd14c";
            this.rd14c.Size = new System.Drawing.Size(17, 16);
            this.rd14c.TabIndex = 3;
            this.rd14c.TabStop = true;
            this.rd14c.Tag = "C";
            this.rd14c.UseVisualStyleBackColor = true;
            // 
            // rd14b
            // 
            this.rd14b.AutoSize = true;
            this.rd14b.Location = new System.Drawing.Point(153, 5);
            this.rd14b.Margin = new System.Windows.Forms.Padding(4);
            this.rd14b.Name = "rd14b";
            this.rd14b.Size = new System.Drawing.Size(17, 16);
            this.rd14b.TabIndex = 2;
            this.rd14b.TabStop = true;
            this.rd14b.Tag = "B";
            this.rd14b.UseVisualStyleBackColor = true;
            // 
            // rd14a
            // 
            this.rd14a.AutoSize = true;
            this.rd14a.Location = new System.Drawing.Point(91, 5);
            this.rd14a.Margin = new System.Windows.Forms.Padding(4);
            this.rd14a.Name = "rd14a";
            this.rd14a.Size = new System.Drawing.Size(17, 16);
            this.rd14a.TabIndex = 0;
            this.rd14a.TabStop = true;
            this.rd14a.Tag = "A";
            this.rd14a.UseVisualStyleBackColor = true;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.lbl14);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(5, 5);
            this.panel21.Margin = new System.Windows.Forms.Padding(4);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(77, 16);
            this.panel21.TabIndex = 5;
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl14.Location = new System.Drawing.Point(-4, 0);
            this.lbl14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(64, 17);
            this.lbl14.TabIndex = 1;
            this.lbl14.Text = "Câu 14:";
            this.lbl14.Click += new System.EventHandler(this.lbl14_Click);
            // 
            // tbl13
            // 
            this.tbl13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl13.ColumnCount = 5;
            this.tbl13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.33333F));
            this.tbl13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.66667F));
            this.tbl13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tbl13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tbl13.Controls.Add(this.rd13d, 4, 0);
            this.tbl13.Controls.Add(this.rd13c, 3, 0);
            this.tbl13.Controls.Add(this.rd13b, 2, 0);
            this.tbl13.Controls.Add(this.rd13a, 1, 0);
            this.tbl13.Controls.Add(this.panel20, 0, 0);
            this.tbl13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl13.Location = new System.Drawing.Point(5, 594);
            this.tbl13.Margin = new System.Windows.Forms.Padding(4);
            this.tbl13.Name = "tbl13";
            this.tbl13.RowCount = 1;
            this.tbl13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl13.Size = new System.Drawing.Size(393, 26);
            this.tbl13.TabIndex = 13;
            // 
            // rd13d
            // 
            this.rd13d.AutoSize = true;
            this.rd13d.Location = new System.Drawing.Point(288, 5);
            this.rd13d.Margin = new System.Windows.Forms.Padding(4);
            this.rd13d.Name = "rd13d";
            this.rd13d.Size = new System.Drawing.Size(17, 16);
            this.rd13d.TabIndex = 4;
            this.rd13d.TabStop = true;
            this.rd13d.Tag = "D";
            this.rd13d.UseVisualStyleBackColor = true;
            // 
            // rd13c
            // 
            this.rd13c.AutoSize = true;
            this.rd13c.Location = new System.Drawing.Point(221, 5);
            this.rd13c.Margin = new System.Windows.Forms.Padding(4);
            this.rd13c.Name = "rd13c";
            this.rd13c.Size = new System.Drawing.Size(17, 16);
            this.rd13c.TabIndex = 3;
            this.rd13c.TabStop = true;
            this.rd13c.Tag = "C";
            this.rd13c.UseVisualStyleBackColor = true;
            // 
            // rd13b
            // 
            this.rd13b.AutoSize = true;
            this.rd13b.Location = new System.Drawing.Point(153, 5);
            this.rd13b.Margin = new System.Windows.Forms.Padding(4);
            this.rd13b.Name = "rd13b";
            this.rd13b.Size = new System.Drawing.Size(17, 16);
            this.rd13b.TabIndex = 2;
            this.rd13b.TabStop = true;
            this.rd13b.Tag = "B";
            this.rd13b.UseVisualStyleBackColor = true;
            // 
            // rd13a
            // 
            this.rd13a.AutoSize = true;
            this.rd13a.Location = new System.Drawing.Point(91, 5);
            this.rd13a.Margin = new System.Windows.Forms.Padding(4);
            this.rd13a.Name = "rd13a";
            this.rd13a.Size = new System.Drawing.Size(17, 16);
            this.rd13a.TabIndex = 0;
            this.rd13a.TabStop = true;
            this.rd13a.Tag = "A";
            this.rd13a.UseVisualStyleBackColor = true;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.lbl13);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(5, 5);
            this.panel20.Margin = new System.Windows.Forms.Padding(4);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(77, 16);
            this.panel20.TabIndex = 5;
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl13.Location = new System.Drawing.Point(-5, -2);
            this.lbl13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(64, 17);
            this.lbl13.TabIndex = 1;
            this.lbl13.Text = "Câu 13:";
            this.lbl13.Click += new System.EventHandler(this.lbl13_Click);
            // 
            // tbl12
            // 
            this.tbl12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl12.ColumnCount = 5;
            this.tbl12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.96178F));
            this.tbl12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.03822F));
            this.tbl12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 98F));
            this.tbl12.Controls.Add(this.rd12d, 4, 0);
            this.tbl12.Controls.Add(this.rd12c, 3, 0);
            this.tbl12.Controls.Add(this.rd12b, 2, 0);
            this.tbl12.Controls.Add(this.rd12a, 1, 0);
            this.tbl12.Controls.Add(this.panel19, 0, 0);
            this.tbl12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl12.Location = new System.Drawing.Point(5, 559);
            this.tbl12.Margin = new System.Windows.Forms.Padding(4);
            this.tbl12.Name = "tbl12";
            this.tbl12.RowCount = 1;
            this.tbl12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl12.Size = new System.Drawing.Size(393, 26);
            this.tbl12.TabIndex = 12;
            // 
            // rd12d
            // 
            this.rd12d.AutoSize = true;
            this.rd12d.Location = new System.Drawing.Point(297, 5);
            this.rd12d.Margin = new System.Windows.Forms.Padding(4);
            this.rd12d.Name = "rd12d";
            this.rd12d.Size = new System.Drawing.Size(17, 16);
            this.rd12d.TabIndex = 4;
            this.rd12d.TabStop = true;
            this.rd12d.Tag = "D";
            this.rd12d.UseVisualStyleBackColor = true;
            // 
            // rd12c
            // 
            this.rd12c.AutoSize = true;
            this.rd12c.Location = new System.Drawing.Point(229, 5);
            this.rd12c.Margin = new System.Windows.Forms.Padding(4);
            this.rd12c.Name = "rd12c";
            this.rd12c.Size = new System.Drawing.Size(17, 16);
            this.rd12c.TabIndex = 3;
            this.rd12c.TabStop = true;
            this.rd12c.Tag = "C";
            this.rd12c.UseVisualStyleBackColor = true;
            // 
            // rd12b
            // 
            this.rd12b.AutoSize = true;
            this.rd12b.Location = new System.Drawing.Point(161, 5);
            this.rd12b.Margin = new System.Windows.Forms.Padding(4);
            this.rd12b.Name = "rd12b";
            this.rd12b.Size = new System.Drawing.Size(17, 16);
            this.rd12b.TabIndex = 2;
            this.rd12b.TabStop = true;
            this.rd12b.Tag = "B";
            this.rd12b.UseVisualStyleBackColor = true;
            // 
            // rd12a
            // 
            this.rd12a.AutoSize = true;
            this.rd12a.Location = new System.Drawing.Point(95, 5);
            this.rd12a.Margin = new System.Windows.Forms.Padding(4);
            this.rd12a.Name = "rd12a";
            this.rd12a.Size = new System.Drawing.Size(17, 16);
            this.rd12a.TabIndex = 0;
            this.rd12a.TabStop = true;
            this.rd12a.Tag = "A";
            this.rd12a.UseVisualStyleBackColor = true;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.lbl12);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(5, 5);
            this.panel19.Margin = new System.Windows.Forms.Padding(4);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(81, 16);
            this.panel19.TabIndex = 5;
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl12.Location = new System.Drawing.Point(-4, 0);
            this.lbl12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(64, 17);
            this.lbl12.TabIndex = 1;
            this.lbl12.Text = "Câu 12:";
            this.lbl12.Click += new System.EventHandler(this.lbl12_Click);
            // 
            // tbl11
            // 
            this.tbl11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl11.ColumnCount = 5;
            this.tbl11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.96178F));
            this.tbl11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.03822F));
            this.tbl11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 98F));
            this.tbl11.Controls.Add(this.rd11d, 4, 0);
            this.tbl11.Controls.Add(this.rd11c, 3, 0);
            this.tbl11.Controls.Add(this.rd11b, 2, 0);
            this.tbl11.Controls.Add(this.rd11a, 1, 0);
            this.tbl11.Controls.Add(this.panel18, 0, 0);
            this.tbl11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl11.Location = new System.Drawing.Point(5, 524);
            this.tbl11.Margin = new System.Windows.Forms.Padding(4);
            this.tbl11.Name = "tbl11";
            this.tbl11.RowCount = 1;
            this.tbl11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl11.Size = new System.Drawing.Size(393, 26);
            this.tbl11.TabIndex = 11;
            // 
            // rd11d
            // 
            this.rd11d.AutoSize = true;
            this.rd11d.Location = new System.Drawing.Point(297, 5);
            this.rd11d.Margin = new System.Windows.Forms.Padding(4);
            this.rd11d.Name = "rd11d";
            this.rd11d.Size = new System.Drawing.Size(17, 16);
            this.rd11d.TabIndex = 4;
            this.rd11d.TabStop = true;
            this.rd11d.Tag = "D";
            this.rd11d.UseVisualStyleBackColor = true;
            // 
            // rd11c
            // 
            this.rd11c.AutoSize = true;
            this.rd11c.Location = new System.Drawing.Point(229, 5);
            this.rd11c.Margin = new System.Windows.Forms.Padding(4);
            this.rd11c.Name = "rd11c";
            this.rd11c.Size = new System.Drawing.Size(17, 16);
            this.rd11c.TabIndex = 3;
            this.rd11c.TabStop = true;
            this.rd11c.Tag = "C";
            this.rd11c.UseVisualStyleBackColor = true;
            // 
            // rd11b
            // 
            this.rd11b.AutoSize = true;
            this.rd11b.Location = new System.Drawing.Point(161, 5);
            this.rd11b.Margin = new System.Windows.Forms.Padding(4);
            this.rd11b.Name = "rd11b";
            this.rd11b.Size = new System.Drawing.Size(17, 16);
            this.rd11b.TabIndex = 2;
            this.rd11b.TabStop = true;
            this.rd11b.Tag = "B";
            this.rd11b.UseVisualStyleBackColor = true;
            // 
            // rd11a
            // 
            this.rd11a.AutoSize = true;
            this.rd11a.Location = new System.Drawing.Point(95, 5);
            this.rd11a.Margin = new System.Windows.Forms.Padding(4);
            this.rd11a.Name = "rd11a";
            this.rd11a.Size = new System.Drawing.Size(17, 16);
            this.rd11a.TabIndex = 0;
            this.rd11a.TabStop = true;
            this.rd11a.Tag = "A";
            this.rd11a.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.lbl11);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(5, 5);
            this.panel18.Margin = new System.Windows.Forms.Padding(4);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(81, 16);
            this.panel18.TabIndex = 5;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl11.Location = new System.Drawing.Point(-7, 0);
            this.lbl11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(69, 17);
            this.lbl11.TabIndex = 1;
            this.lbl11.Text = " Câu 11:";
            this.lbl11.Click += new System.EventHandler(this.lbl11_Click);
            // 
            // tbl10
            // 
            this.tbl10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl10.ColumnCount = 5;
            this.tbl10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.2327F));
            this.tbl10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.7673F));
            this.tbl10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tbl10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tbl10.Controls.Add(this.rd10d, 4, 0);
            this.tbl10.Controls.Add(this.rd10c, 3, 0);
            this.tbl10.Controls.Add(this.rd10b, 2, 0);
            this.tbl10.Controls.Add(this.rd10a, 1, 0);
            this.tbl10.Controls.Add(this.panel17, 0, 0);
            this.tbl10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl10.Location = new System.Drawing.Point(5, 489);
            this.tbl10.Margin = new System.Windows.Forms.Padding(4);
            this.tbl10.Name = "tbl10";
            this.tbl10.RowCount = 1;
            this.tbl10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl10.Size = new System.Drawing.Size(393, 26);
            this.tbl10.TabIndex = 10;
            // 
            // rd10d
            // 
            this.rd10d.AutoSize = true;
            this.rd10d.Location = new System.Drawing.Point(287, 5);
            this.rd10d.Margin = new System.Windows.Forms.Padding(4);
            this.rd10d.Name = "rd10d";
            this.rd10d.Size = new System.Drawing.Size(17, 16);
            this.rd10d.TabIndex = 4;
            this.rd10d.TabStop = true;
            this.rd10d.Tag = "D";
            this.rd10d.UseVisualStyleBackColor = true;
            // 
            // rd10c
            // 
            this.rd10c.AutoSize = true;
            this.rd10c.Location = new System.Drawing.Point(219, 5);
            this.rd10c.Margin = new System.Windows.Forms.Padding(4);
            this.rd10c.Name = "rd10c";
            this.rd10c.Size = new System.Drawing.Size(17, 16);
            this.rd10c.TabIndex = 3;
            this.rd10c.TabStop = true;
            this.rd10c.Tag = "C";
            this.rd10c.UseVisualStyleBackColor = true;
            // 
            // rd10b
            // 
            this.rd10b.AutoSize = true;
            this.rd10b.Location = new System.Drawing.Point(152, 5);
            this.rd10b.Margin = new System.Windows.Forms.Padding(4);
            this.rd10b.Name = "rd10b";
            this.rd10b.Size = new System.Drawing.Size(17, 16);
            this.rd10b.TabIndex = 2;
            this.rd10b.TabStop = true;
            this.rd10b.Tag = "B";
            this.rd10b.UseVisualStyleBackColor = true;
            // 
            // rd10a
            // 
            this.rd10a.AutoSize = true;
            this.rd10a.Location = new System.Drawing.Point(89, 5);
            this.rd10a.Margin = new System.Windows.Forms.Padding(4);
            this.rd10a.Name = "rd10a";
            this.rd10a.Size = new System.Drawing.Size(17, 16);
            this.rd10a.TabIndex = 0;
            this.rd10a.TabStop = true;
            this.rd10a.Tag = "A";
            this.rd10a.UseVisualStyleBackColor = true;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.lbl10);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(5, 5);
            this.panel17.Margin = new System.Windows.Forms.Padding(4);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(75, 16);
            this.panel17.TabIndex = 5;
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl10.Location = new System.Drawing.Point(-4, 0);
            this.lbl10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(64, 17);
            this.lbl10.TabIndex = 1;
            this.lbl10.Text = "Câu 10:";
            this.lbl10.Click += new System.EventHandler(this.lbl10_Click);
            // 
            // tbl9
            // 
            this.tbl9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl9.ColumnCount = 5;
            this.tbl9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.2327F));
            this.tbl9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.7673F));
            this.tbl9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tbl9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tbl9.Controls.Add(this.rd9d, 4, 0);
            this.tbl9.Controls.Add(this.rd9c, 3, 0);
            this.tbl9.Controls.Add(this.rd9b, 2, 0);
            this.tbl9.Controls.Add(this.rd9a, 1, 0);
            this.tbl9.Controls.Add(this.panel16, 0, 0);
            this.tbl9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl9.Location = new System.Drawing.Point(5, 454);
            this.tbl9.Margin = new System.Windows.Forms.Padding(4);
            this.tbl9.Name = "tbl9";
            this.tbl9.RowCount = 1;
            this.tbl9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl9.Size = new System.Drawing.Size(393, 26);
            this.tbl9.TabIndex = 9;
            // 
            // rd9d
            // 
            this.rd9d.AutoSize = true;
            this.rd9d.Location = new System.Drawing.Point(287, 5);
            this.rd9d.Margin = new System.Windows.Forms.Padding(4);
            this.rd9d.Name = "rd9d";
            this.rd9d.Size = new System.Drawing.Size(17, 16);
            this.rd9d.TabIndex = 4;
            this.rd9d.TabStop = true;
            this.rd9d.Tag = "D";
            this.rd9d.UseVisualStyleBackColor = true;
            // 
            // rd9c
            // 
            this.rd9c.AutoSize = true;
            this.rd9c.Location = new System.Drawing.Point(218, 5);
            this.rd9c.Margin = new System.Windows.Forms.Padding(4);
            this.rd9c.Name = "rd9c";
            this.rd9c.Size = new System.Drawing.Size(17, 16);
            this.rd9c.TabIndex = 3;
            this.rd9c.TabStop = true;
            this.rd9c.Tag = "C";
            this.rd9c.UseVisualStyleBackColor = true;
            // 
            // rd9b
            // 
            this.rd9b.AutoSize = true;
            this.rd9b.Location = new System.Drawing.Point(151, 5);
            this.rd9b.Margin = new System.Windows.Forms.Padding(4);
            this.rd9b.Name = "rd9b";
            this.rd9b.Size = new System.Drawing.Size(17, 16);
            this.rd9b.TabIndex = 2;
            this.rd9b.TabStop = true;
            this.rd9b.Tag = "B";
            this.rd9b.UseVisualStyleBackColor = true;
            // 
            // rd9a
            // 
            this.rd9a.AutoSize = true;
            this.rd9a.Location = new System.Drawing.Point(88, 5);
            this.rd9a.Margin = new System.Windows.Forms.Padding(4);
            this.rd9a.Name = "rd9a";
            this.rd9a.Size = new System.Drawing.Size(17, 16);
            this.rd9a.TabIndex = 0;
            this.rd9a.TabStop = true;
            this.rd9a.Tag = "A";
            this.rd9a.UseVisualStyleBackColor = true;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.lbl9);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(5, 5);
            this.panel16.Margin = new System.Windows.Forms.Padding(4);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(74, 16);
            this.panel16.TabIndex = 5;
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl9.Location = new System.Drawing.Point(4, 0);
            this.lbl9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(55, 17);
            this.lbl9.TabIndex = 1;
            this.lbl9.Text = "Câu 9:";
            this.lbl9.Click += new System.EventHandler(this.lbl9_Click);
            // 
            // tbl8
            // 
            this.tbl8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl8.ColumnCount = 5;
            this.tbl8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.60378F));
            this.tbl8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.39622F));
            this.tbl8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tbl8.Controls.Add(this.rd8d, 4, 0);
            this.tbl8.Controls.Add(this.rd8c, 3, 0);
            this.tbl8.Controls.Add(this.rd8b, 2, 0);
            this.tbl8.Controls.Add(this.rd8a, 1, 0);
            this.tbl8.Controls.Add(this.panel15, 0, 0);
            this.tbl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl8.Location = new System.Drawing.Point(5, 419);
            this.tbl8.Margin = new System.Windows.Forms.Padding(4);
            this.tbl8.Name = "tbl8";
            this.tbl8.RowCount = 1;
            this.tbl8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl8.Size = new System.Drawing.Size(393, 26);
            this.tbl8.TabIndex = 8;
            // 
            // rd8d
            // 
            this.rd8d.AutoSize = true;
            this.rd8d.Location = new System.Drawing.Point(287, 5);
            this.rd8d.Margin = new System.Windows.Forms.Padding(4);
            this.rd8d.Name = "rd8d";
            this.rd8d.Size = new System.Drawing.Size(17, 16);
            this.rd8d.TabIndex = 4;
            this.rd8d.TabStop = true;
            this.rd8d.Tag = "D";
            this.rd8d.UseVisualStyleBackColor = true;
            // 
            // rd8c
            // 
            this.rd8c.AutoSize = true;
            this.rd8c.Location = new System.Drawing.Point(218, 5);
            this.rd8c.Margin = new System.Windows.Forms.Padding(4);
            this.rd8c.Name = "rd8c";
            this.rd8c.Size = new System.Drawing.Size(17, 16);
            this.rd8c.TabIndex = 3;
            this.rd8c.TabStop = true;
            this.rd8c.Tag = "C";
            this.rd8c.UseVisualStyleBackColor = true;
            // 
            // rd8b
            // 
            this.rd8b.AutoSize = true;
            this.rd8b.Location = new System.Drawing.Point(149, 5);
            this.rd8b.Margin = new System.Windows.Forms.Padding(4);
            this.rd8b.Name = "rd8b";
            this.rd8b.Size = new System.Drawing.Size(17, 16);
            this.rd8b.TabIndex = 2;
            this.rd8b.TabStop = true;
            this.rd8b.Tag = "B";
            this.rd8b.UseVisualStyleBackColor = true;
            // 
            // rd8a
            // 
            this.rd8a.AutoSize = true;
            this.rd8a.Location = new System.Drawing.Point(86, 5);
            this.rd8a.Margin = new System.Windows.Forms.Padding(4);
            this.rd8a.Name = "rd8a";
            this.rd8a.Size = new System.Drawing.Size(17, 16);
            this.rd8a.TabIndex = 0;
            this.rd8a.TabStop = true;
            this.rd8a.Tag = "A";
            this.rd8a.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.lbl8);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(5, 5);
            this.panel15.Margin = new System.Windows.Forms.Padding(4);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(72, 16);
            this.panel15.TabIndex = 5;
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl8.Location = new System.Drawing.Point(4, 2);
            this.lbl8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(55, 17);
            this.lbl8.TabIndex = 1;
            this.lbl8.Text = "Câu 8:";
            this.lbl8.Click += new System.EventHandler(this.lbl8_Click);
            // 
            // tbl7
            // 
            this.tbl7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl7.ColumnCount = 5;
            this.tbl7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.23684F));
            this.tbl7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.76316F));
            this.tbl7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tbl7.Controls.Add(this.rd7d, 4, 0);
            this.tbl7.Controls.Add(this.rd7c, 3, 0);
            this.tbl7.Controls.Add(this.rd7b, 2, 0);
            this.tbl7.Controls.Add(this.rd7a, 1, 0);
            this.tbl7.Controls.Add(this.panel14, 0, 0);
            this.tbl7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl7.Location = new System.Drawing.Point(5, 384);
            this.tbl7.Margin = new System.Windows.Forms.Padding(4);
            this.tbl7.Name = "tbl7";
            this.tbl7.RowCount = 1;
            this.tbl7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl7.Size = new System.Drawing.Size(393, 26);
            this.tbl7.TabIndex = 7;
            // 
            // rd7d
            // 
            this.rd7d.AutoSize = true;
            this.rd7d.Location = new System.Drawing.Point(294, 5);
            this.rd7d.Margin = new System.Windows.Forms.Padding(4);
            this.rd7d.Name = "rd7d";
            this.rd7d.Size = new System.Drawing.Size(17, 16);
            this.rd7d.TabIndex = 4;
            this.rd7d.TabStop = true;
            this.rd7d.Tag = "D";
            this.rd7d.UseVisualStyleBackColor = true;
            // 
            // rd7c
            // 
            this.rd7c.AutoSize = true;
            this.rd7c.Location = new System.Drawing.Point(225, 5);
            this.rd7c.Margin = new System.Windows.Forms.Padding(4);
            this.rd7c.Name = "rd7c";
            this.rd7c.Size = new System.Drawing.Size(17, 16);
            this.rd7c.TabIndex = 3;
            this.rd7c.TabStop = true;
            this.rd7c.Tag = "C";
            this.rd7c.UseVisualStyleBackColor = true;
            // 
            // rd7b
            // 
            this.rd7b.AutoSize = true;
            this.rd7b.Location = new System.Drawing.Point(156, 5);
            this.rd7b.Margin = new System.Windows.Forms.Padding(4);
            this.rd7b.Name = "rd7b";
            this.rd7b.Size = new System.Drawing.Size(17, 16);
            this.rd7b.TabIndex = 2;
            this.rd7b.TabStop = true;
            this.rd7b.Tag = "B";
            this.rd7b.UseVisualStyleBackColor = true;
            // 
            // rd7a
            // 
            this.rd7a.AutoSize = true;
            this.rd7a.Location = new System.Drawing.Point(91, 5);
            this.rd7a.Margin = new System.Windows.Forms.Padding(4);
            this.rd7a.Name = "rd7a";
            this.rd7a.Size = new System.Drawing.Size(17, 16);
            this.rd7a.TabIndex = 0;
            this.rd7a.TabStop = true;
            this.rd7a.Tag = "A";
            this.rd7a.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.lbl7);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(5, 5);
            this.panel14.Margin = new System.Windows.Forms.Padding(4);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(77, 16);
            this.panel14.TabIndex = 5;
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl7.Location = new System.Drawing.Point(4, 2);
            this.lbl7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(55, 17);
            this.lbl7.TabIndex = 1;
            this.lbl7.Text = "Câu 7:";
            this.lbl7.Click += new System.EventHandler(this.lbl7_Click);
            // 
            // tbl6
            // 
            this.tbl6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl6.ColumnCount = 5;
            this.tbl6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.61589F));
            this.tbl6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.38411F));
            this.tbl6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tbl6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109F));
            this.tbl6.Controls.Add(this.rd6d, 4, 0);
            this.tbl6.Controls.Add(this.rd6c, 3, 0);
            this.tbl6.Controls.Add(this.rd6b, 2, 0);
            this.tbl6.Controls.Add(this.rd6a, 1, 0);
            this.tbl6.Controls.Add(this.panel7, 0, 0);
            this.tbl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl6.Location = new System.Drawing.Point(5, 349);
            this.tbl6.Margin = new System.Windows.Forms.Padding(4);
            this.tbl6.Name = "tbl6";
            this.tbl6.RowCount = 1;
            this.tbl6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl6.Size = new System.Drawing.Size(393, 26);
            this.tbl6.TabIndex = 6;
            // 
            // rd6d
            // 
            this.rd6d.AutoSize = true;
            this.rd6d.Location = new System.Drawing.Point(286, 5);
            this.rd6d.Margin = new System.Windows.Forms.Padding(4);
            this.rd6d.Name = "rd6d";
            this.rd6d.Size = new System.Drawing.Size(17, 16);
            this.rd6d.TabIndex = 4;
            this.rd6d.TabStop = true;
            this.rd6d.Tag = "D";
            this.rd6d.UseVisualStyleBackColor = true;
            // 
            // rd6c
            // 
            this.rd6c.AutoSize = true;
            this.rd6c.Location = new System.Drawing.Point(218, 5);
            this.rd6c.Margin = new System.Windows.Forms.Padding(4);
            this.rd6c.Name = "rd6c";
            this.rd6c.Size = new System.Drawing.Size(17, 16);
            this.rd6c.TabIndex = 3;
            this.rd6c.TabStop = true;
            this.rd6c.Tag = "C";
            this.rd6c.UseVisualStyleBackColor = true;
            // 
            // rd6b
            // 
            this.rd6b.AutoSize = true;
            this.rd6b.Location = new System.Drawing.Point(148, 5);
            this.rd6b.Margin = new System.Windows.Forms.Padding(4);
            this.rd6b.Name = "rd6b";
            this.rd6b.Size = new System.Drawing.Size(17, 16);
            this.rd6b.TabIndex = 2;
            this.rd6b.TabStop = true;
            this.rd6b.Tag = "B";
            this.rd6b.UseVisualStyleBackColor = true;
            // 
            // rd6a
            // 
            this.rd6a.AutoSize = true;
            this.rd6a.Location = new System.Drawing.Point(87, 5);
            this.rd6a.Margin = new System.Windows.Forms.Padding(4);
            this.rd6a.Name = "rd6a";
            this.rd6a.Size = new System.Drawing.Size(17, 16);
            this.rd6a.TabIndex = 0;
            this.rd6a.TabStop = true;
            this.rd6a.Tag = "A";
            this.rd6a.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.lbl6);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(5, 5);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(73, 16);
            this.panel7.TabIndex = 5;
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl6.Location = new System.Drawing.Point(4, 0);
            this.lbl6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(55, 17);
            this.lbl6.TabIndex = 1;
            this.lbl6.Text = "Câu 6:";
            this.lbl6.Click += new System.EventHandler(this.lbl6_Click);
            // 
            // tbl5
            // 
            this.tbl5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl5.ColumnCount = 5;
            this.tbl5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.95364F));
            this.tbl5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.04636F));
            this.tbl5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tbl5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 102F));
            this.tbl5.Controls.Add(this.rd5d, 4, 0);
            this.tbl5.Controls.Add(this.rd5c, 3, 0);
            this.tbl5.Controls.Add(this.rd5b, 2, 0);
            this.tbl5.Controls.Add(this.rd5a, 1, 0);
            this.tbl5.Controls.Add(this.panel6, 0, 0);
            this.tbl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl5.Location = new System.Drawing.Point(5, 314);
            this.tbl5.Margin = new System.Windows.Forms.Padding(4);
            this.tbl5.Name = "tbl5";
            this.tbl5.RowCount = 1;
            this.tbl5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl5.Size = new System.Drawing.Size(393, 26);
            this.tbl5.TabIndex = 5;
            // 
            // rd5d
            // 
            this.rd5d.AutoSize = true;
            this.rd5d.Location = new System.Drawing.Point(293, 5);
            this.rd5d.Margin = new System.Windows.Forms.Padding(4);
            this.rd5d.Name = "rd5d";
            this.rd5d.Size = new System.Drawing.Size(17, 16);
            this.rd5d.TabIndex = 4;
            this.rd5d.TabStop = true;
            this.rd5d.Tag = "D";
            this.rd5d.UseVisualStyleBackColor = true;
            // 
            // rd5c
            // 
            this.rd5c.AutoSize = true;
            this.rd5c.Location = new System.Drawing.Point(225, 5);
            this.rd5c.Margin = new System.Windows.Forms.Padding(4);
            this.rd5c.Name = "rd5c";
            this.rd5c.Size = new System.Drawing.Size(17, 16);
            this.rd5c.TabIndex = 3;
            this.rd5c.TabStop = true;
            this.rd5c.Tag = "C";
            this.rd5c.UseVisualStyleBackColor = true;
            // 
            // rd5b
            // 
            this.rd5b.AutoSize = true;
            this.rd5b.Location = new System.Drawing.Point(155, 5);
            this.rd5b.Margin = new System.Windows.Forms.Padding(4);
            this.rd5b.Name = "rd5b";
            this.rd5b.Size = new System.Drawing.Size(17, 16);
            this.rd5b.TabIndex = 2;
            this.rd5b.TabStop = true;
            this.rd5b.Tag = "B";
            this.rd5b.UseVisualStyleBackColor = true;
            // 
            // rd5a
            // 
            this.rd5a.AutoSize = true;
            this.rd5a.Location = new System.Drawing.Point(90, 5);
            this.rd5a.Margin = new System.Windows.Forms.Padding(4);
            this.rd5a.Name = "rd5a";
            this.rd5a.Size = new System.Drawing.Size(17, 16);
            this.rd5a.TabIndex = 0;
            this.rd5a.TabStop = true;
            this.rd5a.Tag = "A";
            this.rd5a.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lbl5);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(5, 5);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(76, 16);
            this.panel6.TabIndex = 5;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl5.Location = new System.Drawing.Point(4, 2);
            this.lbl5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(55, 17);
            this.lbl5.TabIndex = 1;
            this.lbl5.Text = "Câu 5:";
            this.lbl5.Click += new System.EventHandler(this.lbl5_Click);
            // 
            // tbl4
            // 
            this.tbl4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl4.ColumnCount = 5;
            this.tbl4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.48387F));
            this.tbl4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.51613F));
            this.tbl4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tbl4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 98F));
            this.tbl4.Controls.Add(this.rd4d, 4, 0);
            this.tbl4.Controls.Add(this.rd4c, 3, 0);
            this.tbl4.Controls.Add(this.rd4b, 2, 0);
            this.tbl4.Controls.Add(this.rd4a, 1, 0);
            this.tbl4.Controls.Add(this.panel5, 0, 0);
            this.tbl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl4.Location = new System.Drawing.Point(5, 279);
            this.tbl4.Margin = new System.Windows.Forms.Padding(4);
            this.tbl4.Name = "tbl4";
            this.tbl4.RowCount = 1;
            this.tbl4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl4.Size = new System.Drawing.Size(393, 26);
            this.tbl4.TabIndex = 4;
            // 
            // rd4d
            // 
            this.rd4d.AutoSize = true;
            this.rd4d.Location = new System.Drawing.Point(297, 5);
            this.rd4d.Margin = new System.Windows.Forms.Padding(4);
            this.rd4d.Name = "rd4d";
            this.rd4d.Size = new System.Drawing.Size(17, 16);
            this.rd4d.TabIndex = 4;
            this.rd4d.TabStop = true;
            this.rd4d.Tag = "D";
            this.rd4d.UseVisualStyleBackColor = true;
            // 
            // rd4c
            // 
            this.rd4c.AutoSize = true;
            this.rd4c.Location = new System.Drawing.Point(229, 5);
            this.rd4c.Margin = new System.Windows.Forms.Padding(4);
            this.rd4c.Name = "rd4c";
            this.rd4c.Size = new System.Drawing.Size(17, 16);
            this.rd4c.TabIndex = 3;
            this.rd4c.TabStop = true;
            this.rd4c.Tag = "C";
            this.rd4c.UseVisualStyleBackColor = true;
            // 
            // rd4b
            // 
            this.rd4b.AutoSize = true;
            this.rd4b.Location = new System.Drawing.Point(159, 5);
            this.rd4b.Margin = new System.Windows.Forms.Padding(4);
            this.rd4b.Name = "rd4b";
            this.rd4b.Size = new System.Drawing.Size(17, 16);
            this.rd4b.TabIndex = 2;
            this.rd4b.TabStop = true;
            this.rd4b.Tag = "B";
            this.rd4b.UseVisualStyleBackColor = true;
            // 
            // rd4a
            // 
            this.rd4a.AutoSize = true;
            this.rd4a.Location = new System.Drawing.Point(90, 5);
            this.rd4a.Margin = new System.Windows.Forms.Padding(4);
            this.rd4a.Name = "rd4a";
            this.rd4a.Size = new System.Drawing.Size(17, 16);
            this.rd4a.TabIndex = 0;
            this.rd4a.TabStop = true;
            this.rd4a.Tag = "A";
            this.rd4a.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.lbl4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(5, 5);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(76, 16);
            this.panel5.TabIndex = 5;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl4.Location = new System.Drawing.Point(4, 0);
            this.lbl4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(55, 17);
            this.lbl4.TabIndex = 1;
            this.lbl4.Text = "Câu 4:";
            this.lbl4.Click += new System.EventHandler(this.lbl4_Click);
            // 
            // tbl3
            // 
            this.tbl3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl3.ColumnCount = 5;
            this.tbl3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.84415F));
            this.tbl3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.15585F));
            this.tbl3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tbl3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tbl3.Controls.Add(this.rd3d, 4, 0);
            this.tbl3.Controls.Add(this.rd3c, 3, 0);
            this.tbl3.Controls.Add(this.rd3b, 2, 0);
            this.tbl3.Controls.Add(this.rd3a, 1, 0);
            this.tbl3.Controls.Add(this.panel4, 0, 0);
            this.tbl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl3.Location = new System.Drawing.Point(5, 244);
            this.tbl3.Margin = new System.Windows.Forms.Padding(4);
            this.tbl3.Name = "tbl3";
            this.tbl3.RowCount = 1;
            this.tbl3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl3.Size = new System.Drawing.Size(393, 26);
            this.tbl3.TabIndex = 3;
            // 
            // rd3d
            // 
            this.rd3d.AutoSize = true;
            this.rd3d.Location = new System.Drawing.Point(284, 5);
            this.rd3d.Margin = new System.Windows.Forms.Padding(4);
            this.rd3d.Name = "rd3d";
            this.rd3d.Size = new System.Drawing.Size(17, 16);
            this.rd3d.TabIndex = 4;
            this.rd3d.TabStop = true;
            this.rd3d.Tag = "D";
            this.rd3d.UseVisualStyleBackColor = true;
            // 
            // rd3c
            // 
            this.rd3c.AutoSize = true;
            this.rd3c.Location = new System.Drawing.Point(216, 5);
            this.rd3c.Margin = new System.Windows.Forms.Padding(4);
            this.rd3c.Name = "rd3c";
            this.rd3c.Size = new System.Drawing.Size(17, 16);
            this.rd3c.TabIndex = 3;
            this.rd3c.TabStop = true;
            this.rd3c.Tag = "C";
            this.rd3c.UseVisualStyleBackColor = true;
            // 
            // rd3b
            // 
            this.rd3b.AutoSize = true;
            this.rd3b.Location = new System.Drawing.Point(148, 5);
            this.rd3b.Margin = new System.Windows.Forms.Padding(4);
            this.rd3b.Name = "rd3b";
            this.rd3b.Size = new System.Drawing.Size(17, 16);
            this.rd3b.TabIndex = 2;
            this.rd3b.TabStop = true;
            this.rd3b.Tag = "B";
            this.rd3b.UseVisualStyleBackColor = true;
            // 
            // rd3a
            // 
            this.rd3a.AutoSize = true;
            this.rd3a.Location = new System.Drawing.Point(85, 5);
            this.rd3a.Margin = new System.Windows.Forms.Padding(4);
            this.rd3a.Name = "rd3a";
            this.rd3a.Size = new System.Drawing.Size(17, 16);
            this.rd3a.TabIndex = 0;
            this.rd3a.TabStop = true;
            this.rd3a.Tag = "A";
            this.rd3a.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbl3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(5, 5);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(71, 16);
            this.panel4.TabIndex = 5;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl3.Location = new System.Drawing.Point(4, 0);
            this.lbl3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(55, 17);
            this.lbl3.TabIndex = 1;
            this.lbl3.Text = "Câu 3:";
            this.lbl3.Click += new System.EventHandler(this.lbl3_Click);
            // 
            // tbl2
            // 
            this.tbl2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl2.ColumnCount = 5;
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.54546F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.45454F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tbl2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tbl2.Controls.Add(this.rd2d, 4, 0);
            this.tbl2.Controls.Add(this.rd2c, 3, 0);
            this.tbl2.Controls.Add(this.rd2b, 2, 0);
            this.tbl2.Controls.Add(this.rd2a, 1, 0);
            this.tbl2.Controls.Add(this.panel3, 0, 0);
            this.tbl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl2.Location = new System.Drawing.Point(5, 209);
            this.tbl2.Margin = new System.Windows.Forms.Padding(4);
            this.tbl2.Name = "tbl2";
            this.tbl2.RowCount = 1;
            this.tbl2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl2.Size = new System.Drawing.Size(393, 26);
            this.tbl2.TabIndex = 2;
            // 
            // rd2d
            // 
            this.rd2d.AutoSize = true;
            this.rd2d.Location = new System.Drawing.Point(284, 5);
            this.rd2d.Margin = new System.Windows.Forms.Padding(4);
            this.rd2d.Name = "rd2d";
            this.rd2d.Size = new System.Drawing.Size(17, 16);
            this.rd2d.TabIndex = 4;
            this.rd2d.TabStop = true;
            this.rd2d.Tag = "D";
            this.rd2d.UseVisualStyleBackColor = true;
            // 
            // rd2c
            // 
            this.rd2c.AutoSize = true;
            this.rd2c.Location = new System.Drawing.Point(215, 5);
            this.rd2c.Margin = new System.Windows.Forms.Padding(4);
            this.rd2c.Name = "rd2c";
            this.rd2c.Size = new System.Drawing.Size(17, 16);
            this.rd2c.TabIndex = 3;
            this.rd2c.TabStop = true;
            this.rd2c.Tag = "C";
            this.rd2c.UseVisualStyleBackColor = true;
            // 
            // rd2b
            // 
            this.rd2b.AutoSize = true;
            this.rd2b.Location = new System.Drawing.Point(148, 5);
            this.rd2b.Margin = new System.Windows.Forms.Padding(4);
            this.rd2b.Name = "rd2b";
            this.rd2b.Size = new System.Drawing.Size(17, 16);
            this.rd2b.TabIndex = 2;
            this.rd2b.TabStop = true;
            this.rd2b.Tag = "B";
            this.rd2b.UseVisualStyleBackColor = true;
            // 
            // rd2a
            // 
            this.rd2a.AutoSize = true;
            this.rd2a.Location = new System.Drawing.Point(83, 5);
            this.rd2a.Margin = new System.Windows.Forms.Padding(4);
            this.rd2a.Name = "rd2a";
            this.rd2a.Size = new System.Drawing.Size(17, 16);
            this.rd2a.TabIndex = 0;
            this.rd2a.TabStop = true;
            this.rd2a.Tag = "A";
            this.rd2a.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbl2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(5, 5);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(69, 16);
            this.panel3.TabIndex = 5;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl2.Location = new System.Drawing.Point(4, 2);
            this.lbl2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(55, 17);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Câu 2:";
            this.lbl2.Click += new System.EventHandler(this.lbl2_Click);
            this.lbl2.MouseEnter += new System.EventHandler(this.lbl2_MouseEnter);
            this.lbl2.MouseLeave += new System.EventHandler(this.lbl2_MouseLeave);
            // 
            // tbl1
            // 
            this.tbl1.BackColor = System.Drawing.Color.Gainsboro;
            this.tbl1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl1.ColumnCount = 5;
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.54546F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.45454F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tbl1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tbl1.Controls.Add(this.rd1d, 4, 0);
            this.tbl1.Controls.Add(this.rd1c, 3, 0);
            this.tbl1.Controls.Add(this.rd1b, 2, 0);
            this.tbl1.Controls.Add(this.panel2, 0, 0);
            this.tbl1.Controls.Add(this.rd1a, 1, 0);
            this.tbl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl1.Location = new System.Drawing.Point(5, 174);
            this.tbl1.Margin = new System.Windows.Forms.Padding(4);
            this.tbl1.Name = "tbl1";
            this.tbl1.RowCount = 1;
            this.tbl1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl1.Size = new System.Drawing.Size(393, 26);
            this.tbl1.TabIndex = 1;
            // 
            // rd1d
            // 
            this.rd1d.AutoSize = true;
            this.rd1d.Location = new System.Drawing.Point(284, 5);
            this.rd1d.Margin = new System.Windows.Forms.Padding(4);
            this.rd1d.Name = "rd1d";
            this.rd1d.Size = new System.Drawing.Size(17, 16);
            this.rd1d.TabIndex = 4;
            this.rd1d.TabStop = true;
            this.rd1d.Tag = "D";
            this.rd1d.UseVisualStyleBackColor = true;
            // 
            // rd1c
            // 
            this.rd1c.AutoSize = true;
            this.rd1c.Location = new System.Drawing.Point(214, 5);
            this.rd1c.Margin = new System.Windows.Forms.Padding(4);
            this.rd1c.Name = "rd1c";
            this.rd1c.Size = new System.Drawing.Size(17, 16);
            this.rd1c.TabIndex = 3;
            this.rd1c.TabStop = true;
            this.rd1c.Tag = "C";
            this.rd1c.UseVisualStyleBackColor = true;
            // 
            // rd1b
            // 
            this.rd1b.AutoSize = true;
            this.rd1b.Location = new System.Drawing.Point(148, 5);
            this.rd1b.Margin = new System.Windows.Forms.Padding(4);
            this.rd1b.Name = "rd1b";
            this.rd1b.Size = new System.Drawing.Size(17, 16);
            this.rd1b.TabIndex = 2;
            this.rd1b.TabStop = true;
            this.rd1b.Tag = "B";
            this.rd1b.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(5, 5);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(69, 16);
            this.panel2.TabIndex = 5;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbl1.Location = new System.Drawing.Point(4, 0);
            this.lbl1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(55, 17);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Câu 1:";
            this.lbl1.Click += new System.EventHandler(this.lbl1_Click);
            this.lbl1.MouseEnter += new System.EventHandler(this.lbl1_MouseEnter);
            this.lbl1.MouseLeave += new System.EventHandler(this.lbl1_MouseLeave);
            // 
            // rd1a
            // 
            this.rd1a.AutoSize = true;
            this.rd1a.Location = new System.Drawing.Point(83, 5);
            this.rd1a.Margin = new System.Windows.Forms.Padding(4);
            this.rd1a.Name = "rd1a";
            this.rd1a.Size = new System.Drawing.Size(17, 16);
            this.rd1a.TabIndex = 0;
            this.rd1a.TabStop = true;
            this.rd1a.Tag = "A";
            this.rd1a.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.tableLayoutPanel3);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(5, 5);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(393, 160);
            this.panel8.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.10345F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.89655F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 94F));
            this.tableLayoutPanel3.Controls.Add(this.panel12, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel11, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel10, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel9, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel32, 2, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(393, 160);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label17);
            this.panel12.Controls.Add(this.label5);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel12.Location = new System.Drawing.Point(301, 5);
            this.panel12.Margin = new System.Windows.Forms.Padding(4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(87, 150);
            this.panel12.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label17.Location = new System.Drawing.Point(4, 70);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 13);
            this.label17.TabIndex = 6;
            this.label17.Text = "Đáp án";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(12, 84);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 32);
            this.label5.TabIndex = 3;
            this.label5.Text = "D";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.label16);
            this.panel11.Controls.Add(this.label4);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel11.Location = new System.Drawing.Point(231, 5);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(61, 150);
            this.panel11.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label16.Location = new System.Drawing.Point(7, 71);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Đáp án";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(13, 85);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 32);
            this.label4.TabIndex = 2;
            this.label4.Text = "C";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label10);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel10.Location = new System.Drawing.Point(5, 5);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(73, 150);
            this.panel10.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(9, 68);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Câu hỏi";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel13);
            this.panel9.Controls.Add(this.label1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(87, 5);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(64, 150);
            this.panel9.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.label14);
            this.panel13.Controls.Add(this.label12);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Margin = new System.Windows.Forms.Padding(4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(64, 150);
            this.panel13.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label14.Location = new System.Drawing.Point(11, 67);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Đáp án";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.Location = new System.Drawing.Point(18, 82);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 32);
            this.label12.TabIndex = 1;
            this.label12.Text = "A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(2, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "A";
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.label15);
            this.panel32.Controls.Add(this.label9);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel32.Location = new System.Drawing.Point(160, 5);
            this.panel32.Margin = new System.Windows.Forms.Padding(4);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(62, 150);
            this.panel32.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label15.Location = new System.Drawing.Point(6, 70);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Đáp án";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(11, 84);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 32);
            this.label9.TabIndex = 1;
            this.label9.Text = "B";
            // 
            // btndone
            // 
            this.btndone.BackColor = System.Drawing.Color.White;
            this.btndone.BackgroundColor = System.Drawing.Color.White;
            this.btndone.BorderColor = System.Drawing.Color.Black;
            this.btndone.BorderRadius = 20;
            this.btndone.BorderSize = 2;
            this.btndone.FlatAppearance.BorderSize = 0;
            this.btndone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndone.ForeColor = System.Drawing.Color.Black;
            this.btndone.Location = new System.Drawing.Point(541, 848);
            this.btndone.Margin = new System.Windows.Forms.Padding(4);
            this.btndone.Name = "btndone";
            this.btndone.Size = new System.Drawing.Size(158, 50);
            this.btndone.TabIndex = 36;
            this.btndone.Text = "NỘP BÀI";
            this.btndone.TextColor = System.Drawing.Color.Black;
            this.btndone.UseVisualStyleBackColor = false;
            this.btndone.Click += new System.EventHandler(this.btndone_Click_1);
            this.btndone.MouseEnter += new System.EventHandler(this.btndone_MouseEnter);
            this.btndone.MouseLeave += new System.EventHandler(this.btndone_MouseLeave);
            // 
            // btnnext
            // 
            this.btnnext.BackColor = System.Drawing.Color.White;
            this.btnnext.BackgroundColor = System.Drawing.Color.White;
            this.btnnext.BorderColor = System.Drawing.Color.Black;
            this.btnnext.BorderRadius = 20;
            this.btnnext.BorderSize = 2;
            this.btnnext.FlatAppearance.BorderSize = 0;
            this.btnnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnext.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnext.ForeColor = System.Drawing.Color.Black;
            this.btnnext.Location = new System.Drawing.Point(911, 854);
            this.btnnext.Margin = new System.Windows.Forms.Padding(4);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(158, 50);
            this.btnnext.TabIndex = 37;
            this.btnnext.Text = "Câu sau";
            this.btnnext.TextColor = System.Drawing.Color.Black;
            this.btnnext.UseVisualStyleBackColor = false;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.White;
            this.btnback.BackgroundColor = System.Drawing.Color.White;
            this.btnback.BorderColor = System.Drawing.Color.Black;
            this.btnback.BorderRadius = 20;
            this.btnback.BorderSize = 2;
            this.btnback.FlatAppearance.BorderSize = 0;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.Black;
            this.btnback.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnback.Location = new System.Drawing.Point(11, 854);
            this.btnback.Margin = new System.Windows.Forms.Padding(4);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(158, 50);
            this.btnback.TabIndex = 32;
            this.btnback.Text = "Câu trước";
            this.btnback.TextColor = System.Drawing.Color.Black;
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click_1);
            // 
            // frmbaithi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(20, 20);
            this.ClientSize = new System.Drawing.Size(1942, 997);
            this.Controls.Add(this.tableLayoutPanelcaform);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmbaithi";
            this.Text = "frmbaithi";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmbaithi_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grbnoidung.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanelcaform.ResumeLayout(false);
            this.tableLayoutPanelcot2.ResumeLayout(false);
            this.tbl40.ResumeLayout(false);
            this.tbl40.PerformLayout();
            this.panel67.ResumeLayout(false);
            this.panel67.PerformLayout();
            this.tbl39.ResumeLayout(false);
            this.tbl39.PerformLayout();
            this.panel68.ResumeLayout(false);
            this.panel68.PerformLayout();
            this.tbl42.ResumeLayout(false);
            this.tbl42.PerformLayout();
            this.panel69.ResumeLayout(false);
            this.panel69.PerformLayout();
            this.tbl37.ResumeLayout(false);
            this.tbl37.PerformLayout();
            this.panel70.ResumeLayout(false);
            this.panel70.PerformLayout();
            this.tbl36.ResumeLayout(false);
            this.tbl36.PerformLayout();
            this.panel71.ResumeLayout(false);
            this.panel71.PerformLayout();
            this.tbl35.ResumeLayout(false);
            this.tbl35.PerformLayout();
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.tbl38.ResumeLayout(false);
            this.tbl38.PerformLayout();
            this.panel73.ResumeLayout(false);
            this.panel73.PerformLayout();
            this.tbl33.ResumeLayout(false);
            this.tbl33.PerformLayout();
            this.panel74.ResumeLayout(false);
            this.panel74.PerformLayout();
            this.tbl32.ResumeLayout(false);
            this.tbl32.PerformLayout();
            this.panel75.ResumeLayout(false);
            this.panel75.PerformLayout();
            this.tbl31.ResumeLayout(false);
            this.tbl31.PerformLayout();
            this.panel76.ResumeLayout(false);
            this.panel76.PerformLayout();
            this.tbl34.ResumeLayout(false);
            this.tbl34.PerformLayout();
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            this.tbl29.ResumeLayout(false);
            this.tbl29.PerformLayout();
            this.panel78.ResumeLayout(false);
            this.panel78.PerformLayout();
            this.tbl28.ResumeLayout(false);
            this.tbl28.PerformLayout();
            this.panel79.ResumeLayout(false);
            this.panel79.PerformLayout();
            this.tbl27.ResumeLayout(false);
            this.tbl27.PerformLayout();
            this.panel80.ResumeLayout(false);
            this.panel80.PerformLayout();
            this.tbl30.ResumeLayout(false);
            this.tbl30.PerformLayout();
            this.panel81.ResumeLayout(false);
            this.panel81.PerformLayout();
            this.tbl25.ResumeLayout(false);
            this.tbl25.PerformLayout();
            this.panel82.ResumeLayout(false);
            this.panel82.PerformLayout();
            this.tbl24.ResumeLayout(false);
            this.tbl24.PerformLayout();
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            this.tbl23.ResumeLayout(false);
            this.tbl23.PerformLayout();
            this.panel84.ResumeLayout(false);
            this.panel84.PerformLayout();
            this.tbl22.ResumeLayout(false);
            this.tbl22.PerformLayout();
            this.panel85.ResumeLayout(false);
            this.panel85.PerformLayout();
            this.tbl21.ResumeLayout(false);
            this.tbl21.PerformLayout();
            this.panel86.ResumeLayout(false);
            this.panel86.PerformLayout();
            this.panel87.ResumeLayout(false);
            this.tableLayoutPanel79.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            this.panel89.ResumeLayout(false);
            this.panel89.PerformLayout();
            this.panel90.ResumeLayout(false);
            this.panel90.PerformLayout();
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.panel92.ResumeLayout(false);
            this.panel92.PerformLayout();
            this.panel93.ResumeLayout(false);
            this.panel93.PerformLayout();
            this.tableLayoutPanelcot1.ResumeLayout(false);
            this.tbl20.ResumeLayout(false);
            this.tbl20.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.tbl19.ResumeLayout(false);
            this.tbl19.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tbl18.ResumeLayout(false);
            this.tbl18.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.tbl17.ResumeLayout(false);
            this.tbl17.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.tbl16.ResumeLayout(false);
            this.tbl16.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.tbl15.ResumeLayout(false);
            this.tbl15.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.tbl14.ResumeLayout(false);
            this.tbl14.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.tbl13.ResumeLayout(false);
            this.tbl13.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.tbl12.ResumeLayout(false);
            this.tbl12.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.tbl11.ResumeLayout(false);
            this.tbl11.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.tbl10.ResumeLayout(false);
            this.tbl10.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.tbl9.ResumeLayout(false);
            this.tbl9.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.tbl8.ResumeLayout(false);
            this.tbl8.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.tbl7.ResumeLayout(false);
            this.tbl7.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tbl6.ResumeLayout(false);
            this.tbl6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tbl5.ResumeLayout(false);
            this.tbl5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tbl4.ResumeLayout(false);
            this.tbl4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tbl3.ResumeLayout(false);
            this.tbl3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tbl2.ResumeLayout(false);
            this.tbl2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tbl1.ResumeLayout(false);
            this.tbl1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private RJButton btndone;
        private RJButton btnnext;
        private System.Windows.Forms.GroupBox grbnoidung;
        private System.Windows.Forms.Label lblnoidungcauhoi;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label lblthoigian;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label lblsocau;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblmonthi;
        private System.Windows.Forms.Label label40;
        private RJButton btnback;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblgiay;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblphut;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblmsv;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lblhoten;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelcaform;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelcot2;
        private System.Windows.Forms.TableLayoutPanel tbl40;
        private System.Windows.Forms.RadioButton rd44d;
        private System.Windows.Forms.RadioButton rd44c;
        private System.Windows.Forms.RadioButton rd44b;
        private System.Windows.Forms.RadioButton rd44a;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Label lbl40;
        private System.Windows.Forms.TableLayoutPanel tbl39;
        private System.Windows.Forms.RadioButton rd43d;
        private System.Windows.Forms.RadioButton rd43c;
        private System.Windows.Forms.RadioButton rd43b;
        private System.Windows.Forms.RadioButton rd43a;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Label lbl39;
        private System.Windows.Forms.TableLayoutPanel tbl42;
        private System.Windows.Forms.RadioButton rd42d;
        private System.Windows.Forms.RadioButton rd42c;
        private System.Windows.Forms.RadioButton rd42b;
        private System.Windows.Forms.RadioButton rd42a;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Label lbl38;
        private System.Windows.Forms.TableLayoutPanel tbl37;
        private System.Windows.Forms.RadioButton rd41d;
        private System.Windows.Forms.RadioButton rd41c;
        private System.Windows.Forms.RadioButton rd41b;
        private System.Windows.Forms.RadioButton rd41a;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Label lbl37;
        private System.Windows.Forms.TableLayoutPanel tbl36;
        private System.Windows.Forms.RadioButton rd40d;
        private System.Windows.Forms.RadioButton rd40c;
        private System.Windows.Forms.RadioButton rd40b;
        private System.Windows.Forms.RadioButton rd40a;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.TableLayoutPanel tbl35;
        private System.Windows.Forms.RadioButton rd39d;
        private System.Windows.Forms.RadioButton rd39c;
        private System.Windows.Forms.RadioButton rd39b;
        private System.Windows.Forms.RadioButton rd39a;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.TableLayoutPanel tbl38;
        private System.Windows.Forms.RadioButton rd38d;
        private System.Windows.Forms.RadioButton rd38c;
        private System.Windows.Forms.RadioButton rd38b;
        private System.Windows.Forms.RadioButton rd38a;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.TableLayoutPanel tbl33;
        private System.Windows.Forms.RadioButton rd37d;
        private System.Windows.Forms.RadioButton rd37c;
        private System.Windows.Forms.RadioButton rd37b;
        private System.Windows.Forms.RadioButton rd37;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.TableLayoutPanel tbl32;
        private System.Windows.Forms.RadioButton rd36d;
        private System.Windows.Forms.RadioButton rd36c;
        private System.Windows.Forms.RadioButton rd36b;
        private System.Windows.Forms.RadioButton rd36aa;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.TableLayoutPanel tbl31;
        private System.Windows.Forms.RadioButton rd35d;
        private System.Windows.Forms.RadioButton rd35c;
        private System.Windows.Forms.RadioButton rd35b;
        private System.Windows.Forms.RadioButton rd35a;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.TableLayoutPanel tbl34;
        private System.Windows.Forms.RadioButton rd34d;
        private System.Windows.Forms.RadioButton rd34c;
        private System.Windows.Forms.RadioButton rd34b;
        private System.Windows.Forms.RadioButton rd34a;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.TableLayoutPanel tbl29;
        private System.Windows.Forms.RadioButton rd33d;
        private System.Windows.Forms.RadioButton rd33c;
        private System.Windows.Forms.RadioButton rd33b;
        private System.Windows.Forms.RadioButton rd33a;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.TableLayoutPanel tbl28;
        private System.Windows.Forms.RadioButton rd32d;
        private System.Windows.Forms.RadioButton rd32c;
        private System.Windows.Forms.RadioButton rd32b;
        private System.Windows.Forms.RadioButton rd32a;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.TableLayoutPanel tbl27;
        private System.Windows.Forms.RadioButton rd31d;
        private System.Windows.Forms.RadioButton rd31c;
        private System.Windows.Forms.RadioButton rd31b;
        private System.Windows.Forms.RadioButton rd31a;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.TableLayoutPanel tbl30;
        private System.Windows.Forms.RadioButton rd30d;
        private System.Windows.Forms.RadioButton rd30c;
        private System.Windows.Forms.RadioButton rd30b;
        private System.Windows.Forms.RadioButton rd30a;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.TableLayoutPanel tbl25;
        private System.Windows.Forms.RadioButton rd29d;
        private System.Windows.Forms.RadioButton rd29c;
        private System.Windows.Forms.RadioButton rd29b;
        private System.Windows.Forms.RadioButton rd29a;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.TableLayoutPanel tbl24;
        private System.Windows.Forms.RadioButton rd28d;
        private System.Windows.Forms.RadioButton rd28c;
        private System.Windows.Forms.RadioButton rd28b;
        private System.Windows.Forms.RadioButton rd28a;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.TableLayoutPanel tbl23;
        private System.Windows.Forms.RadioButton rd27d;
        private System.Windows.Forms.RadioButton rd27c;
        private System.Windows.Forms.RadioButton rd27b;
        private System.Windows.Forms.RadioButton rd27a;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.TableLayoutPanel tbl22;
        private System.Windows.Forms.RadioButton rd26d;
        private System.Windows.Forms.RadioButton rd26c;
        private System.Windows.Forms.RadioButton rd26b;
        private System.Windows.Forms.RadioButton rd26a;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.TableLayoutPanel tbl21;
        private System.Windows.Forms.RadioButton rd25d;
        private System.Windows.Forms.RadioButton rd25c;
        private System.Windows.Forms.RadioButton rd25b;
        private System.Windows.Forms.RadioButton rd25a;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel79;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelcot1;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.TableLayoutPanel tbl20;
        private System.Windows.Forms.RadioButton rd20d;
        private System.Windows.Forms.RadioButton rd20c;
        private System.Windows.Forms.RadioButton rd20b;
        private System.Windows.Forms.RadioButton rd20a;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.TableLayoutPanel tbl19;
        private System.Windows.Forms.RadioButton rd19d;
        private System.Windows.Forms.RadioButton rd19c;
        private System.Windows.Forms.RadioButton rd19b;
        private System.Windows.Forms.RadioButton rd19a;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.TableLayoutPanel tbl18;
        private System.Windows.Forms.RadioButton rd18d;
        private System.Windows.Forms.RadioButton rd18c;
        private System.Windows.Forms.RadioButton rd18b;
        private System.Windows.Forms.RadioButton rd18a;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.TableLayoutPanel tbl17;
        private System.Windows.Forms.RadioButton rd17d;
        private System.Windows.Forms.RadioButton rd17c;
        private System.Windows.Forms.RadioButton rd17b;
        private System.Windows.Forms.RadioButton rd17a;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.TableLayoutPanel tbl16;
        private System.Windows.Forms.RadioButton rd16d;
        private System.Windows.Forms.RadioButton rd16c;
        private System.Windows.Forms.RadioButton rd16b;
        private System.Windows.Forms.RadioButton rd16a;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.TableLayoutPanel tbl15;
        private System.Windows.Forms.RadioButton rd15d;
        private System.Windows.Forms.RadioButton rd15c;
        private System.Windows.Forms.RadioButton rd15b;
        private System.Windows.Forms.RadioButton rd15a;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.TableLayoutPanel tbl14;
        private System.Windows.Forms.RadioButton rd14d;
        private System.Windows.Forms.RadioButton rd14c;
        private System.Windows.Forms.RadioButton rd14b;
        private System.Windows.Forms.RadioButton rd14a;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.TableLayoutPanel tbl13;
        private System.Windows.Forms.RadioButton rd13d;
        private System.Windows.Forms.RadioButton rd13c;
        private System.Windows.Forms.RadioButton rd13b;
        private System.Windows.Forms.RadioButton rd13a;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.TableLayoutPanel tbl12;
        private System.Windows.Forms.RadioButton rd12d;
        private System.Windows.Forms.RadioButton rd12c;
        private System.Windows.Forms.RadioButton rd12b;
        private System.Windows.Forms.RadioButton rd12a;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.TableLayoutPanel tbl11;
        private System.Windows.Forms.RadioButton rd11d;
        private System.Windows.Forms.RadioButton rd11c;
        private System.Windows.Forms.RadioButton rd11b;
        private System.Windows.Forms.RadioButton rd11a;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.TableLayoutPanel tbl10;
        private System.Windows.Forms.RadioButton rd10d;
        private System.Windows.Forms.RadioButton rd10c;
        private System.Windows.Forms.RadioButton rd10b;
        private System.Windows.Forms.RadioButton rd10a;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.TableLayoutPanel tbl9;
        private System.Windows.Forms.RadioButton rd9d;
        private System.Windows.Forms.RadioButton rd9c;
        private System.Windows.Forms.RadioButton rd9b;
        private System.Windows.Forms.RadioButton rd9a;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.TableLayoutPanel tbl8;
        private System.Windows.Forms.RadioButton rd8d;
        private System.Windows.Forms.RadioButton rd8c;
        private System.Windows.Forms.RadioButton rd8b;
        private System.Windows.Forms.RadioButton rd8a;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.TableLayoutPanel tbl7;
        private System.Windows.Forms.RadioButton rd7d;
        private System.Windows.Forms.RadioButton rd7c;
        private System.Windows.Forms.RadioButton rd7b;
        private System.Windows.Forms.RadioButton rd7a;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.TableLayoutPanel tbl6;
        private System.Windows.Forms.RadioButton rd6d;
        private System.Windows.Forms.RadioButton rd6c;
        private System.Windows.Forms.RadioButton rd6b;
        private System.Windows.Forms.RadioButton rd6a;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.TableLayoutPanel tbl5;
        private System.Windows.Forms.RadioButton rd5d;
        private System.Windows.Forms.RadioButton rd5c;
        private System.Windows.Forms.RadioButton rd5b;
        private System.Windows.Forms.RadioButton rd5a;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.TableLayoutPanel tbl4;
        private System.Windows.Forms.RadioButton rd4d;
        private System.Windows.Forms.RadioButton rd4c;
        private System.Windows.Forms.RadioButton rd4b;
        private System.Windows.Forms.RadioButton rd4a;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.TableLayoutPanel tbl3;
        private System.Windows.Forms.RadioButton rd3d;
        private System.Windows.Forms.RadioButton rd3c;
        private System.Windows.Forms.RadioButton rd3b;
        private System.Windows.Forms.RadioButton rd3a;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.TableLayoutPanel tbl2;
        private System.Windows.Forms.RadioButton rd2d;
        private System.Windows.Forms.RadioButton rd2c;
        private System.Windows.Forms.RadioButton rd2b;
        private System.Windows.Forms.RadioButton rd2a;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TableLayoutPanel tbl1;
        private System.Windows.Forms.RadioButton rd1d;
        private System.Windows.Forms.RadioButton rd1c;
        private System.Windows.Forms.RadioButton rd1b;
        private System.Windows.Forms.RadioButton rd1a;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox ckbdatco1;
        private System.Windows.Forms.CheckBox ckbdatco5;
        private System.Windows.Forms.CheckBox ckbdatco3;
        private System.Windows.Forms.CheckBox ckbdatco2;
        private System.Windows.Forms.CheckBox ckbdatco4;
        private System.Windows.Forms.CheckBox ckbdatco13;
        private System.Windows.Forms.CheckBox ckbdatco12;
        private System.Windows.Forms.CheckBox ckbdatco11;
        private System.Windows.Forms.CheckBox ckbdatco10;
        private System.Windows.Forms.CheckBox ckbdatco9;
        private System.Windows.Forms.CheckBox ckbdatco8;
        private System.Windows.Forms.CheckBox ckbdatco7;
        private System.Windows.Forms.CheckBox ckbdatco6;
        private System.Windows.Forms.CheckBox ckbdatco17;
        private System.Windows.Forms.CheckBox ckbdatco16;
        private System.Windows.Forms.CheckBox ckbdatco15;
        private System.Windows.Forms.CheckBox ckbdatco14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblthongbaohetgio;
        private System.Windows.Forms.CheckBox ckbdatco21;
        private System.Windows.Forms.CheckBox ckbdatco19;
        private System.Windows.Forms.CheckBox ckbdatco20;
        private System.Windows.Forms.CheckBox ckbdatco18;
        private System.Windows.Forms.CheckBox ckbdatco40;
        private System.Windows.Forms.CheckBox ckbdatco39;
        private System.Windows.Forms.CheckBox ckbdatco38;
        private System.Windows.Forms.CheckBox ckbdatco37;
        private System.Windows.Forms.CheckBox ckbdatco36;
        private System.Windows.Forms.CheckBox ckbdatco35;
        private System.Windows.Forms.CheckBox ckbdatco34;
        private System.Windows.Forms.CheckBox ckbdatco33;
        private System.Windows.Forms.CheckBox ckbdatco32;
        private System.Windows.Forms.CheckBox ckbdatco31;
        private System.Windows.Forms.CheckBox ckbdatco30;
        private System.Windows.Forms.CheckBox ckbdatco29;
        private System.Windows.Forms.CheckBox ckbdatco28;
        private System.Windows.Forms.CheckBox ckbdatco27;
        private System.Windows.Forms.CheckBox ckbdatco26;
        private System.Windows.Forms.CheckBox ckbdatco25;
        private System.Windows.Forms.CheckBox ckbdatco24;
        private System.Windows.Forms.CheckBox ckbdatco23;
        private System.Windows.Forms.CheckBox ckbdatco22;
    }
}