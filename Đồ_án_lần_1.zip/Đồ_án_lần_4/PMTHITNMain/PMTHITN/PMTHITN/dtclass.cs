﻿namespace PMTHITN
{
}

namespace PMTHITN
{
}
namespace PMTHITN
{


    partial class dtclass
    {
        partial class dtDiemtheomonDataTable
        {
        }
    }
}
