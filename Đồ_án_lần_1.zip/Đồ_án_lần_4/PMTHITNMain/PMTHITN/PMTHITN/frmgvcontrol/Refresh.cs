﻿using PMTHITN.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace PMTHITN.frmgvcontrol
{
    internal class Refresh
    {
        private string type;
        private DatabaseHelper dbHelper; // Giả sử bạn có một lớp DatabaseHelper để xử lý truy vấn

        public Refresh(string type, DatabaseHelper dbHelper)
        {
            this.type = type;
            this.dbHelper = dbHelper;
        }

        public void ExecuteRefresh(DataGridView dgvmenu, DataGridView dgvphanhoi, string type,
            TextBox txtmach, TextBox txtmamon, TextBox txtnoidung,
            TextBox txtsocau, TextBox txttenmon, TextBox txtthoigian, TextBox txtten_phanhoi,
            TextBox txtmssv_phanhoi, TextBox txthodem_phanhoi, TextBox txtlop_phanhoi, TextBox txtmon_phanhoi, RichTextBox txtnoidung_phanhoi,
            TextBox txtngay_phanhoi, ComboBox cmbdapan, ComboBox cmbmon, ComboBox comboBoxChuong,
            ComboBox cmbtrangthai, DateTimePicker dtptgthi, DateTimePicker dptthoigianbatdau,
            DateTimePicker dptthoigianketthuc)
        {
            // Làm sạch các TextBox
            txtmach.Clear();
            txtmamon.Clear();
            txtnoidung.Clear();
            txtsocau.Clear();
            txttenmon.Clear();
            txtthoigian.Clear();

            txtten_phanhoi.Clear();
            txtmssv_phanhoi.Clear();
            txthodem_phanhoi.Clear();
            txtlop_phanhoi.Clear();
            txtmon_phanhoi.Clear();
            txtnoidung_phanhoi.Clear();
            txtngay_phanhoi.Clear();

            // Đặt lại giá trị ComboBox
            cmbdapan.SelectedIndex = -1;
            cmbmon.SelectedIndex = -1;
            comboBoxChuong.SelectedIndex = -1;
            cmbtrangthai.SelectedIndex = -1;

            // Đặt lại các DateTimePicker
            dtptgthi.Value = DateTime.Now;
            dptthoigianbatdau.Value = DateTime.Now;
            dptthoigianketthuc.Value = DateTime.Now;

            string sql = string.Empty; // Khởi tạo biến sql

            // Xác định câu truy vấn SQL dựa trên loại dữ liệu
            switch (type)
            {
                case "CauHoi":
                    sql = @"
                SELECT 
                    MaCH AS 'Mã câu hỏi', 
                    MaM AS 'Mã môn', 
                    Noidung AS 'Nội dung câu hỏi', 
                    Dapan AS 'Đáp án', 
                    Chuong AS 'Chương' 
                FROM 
                    CAUHOI"; // Truy vấn cho bảng câu hỏi
                    dbHelper.LoadDuLieu(sql, dgvmenu); // Tải dữ liệu vào dgvmenu
                    break;

                case "MonHoc":
                    sql = @"
                 select MaM as 'Mã Môn', MaMH as 'Mã môn học', Tenmon as 'Tên môn', Socau as 'Số câu', TGlambai as 'Thời gian làm bài', Thoigianthi as 'Ngày thi' from MONTHI";
            
                    dbHelper.LoadDuLieu(sql, dgvmenu); // Tải dữ liệu vào dgvmenu
                    break;

                case "SinhVien":
                    sql = @"
                SELECT 
                    MaSV AS 'Mã SV', 
                    Hodem AS 'Họ đệm', 
                    Ten AS 'Tên', 
                    Ngaysinh AS 'Ngày sinh', 
                    Matkhau AS 'Mật khẩu' 
                FROM 
                    SV"; // Truy vấn cho bảng sinh viên
                    dbHelper.LoadDuLieu(sql, dgvmenu); // Tải dữ liệu vào dgvmenu
                    break;

                case "DiemDanh":
                    sql = @"
       SELECT 
    pdd.ID_phien AS [ID],
    l.MaL AS [Mã lớp],
    l.TenL AS [Tên lớp],
    mh.MaMH AS [Mã môn học],
    mh.Tenmonhoc AS [Tên môn học],
    pdd.Ngay AS [Ngày], 
    pdd.Gio_batdau AS [Thời gian bắt đầu], 
    pdd.Gio_ketthuc AS [Thời gian kết thúc],
    pdd.SoLan AS [Lần],
    pdd.Trangthai AS [Trạng thái]
FROM 
    PHIENDIEMDANH pdd
JOIN 
    LOP l ON pdd.MaL = l.MaL
JOIN 
    MONHOC mh ON pdd.MaMH = mh.MaMH
ORDER BY 
    pdd.Ngay DESC"; // Truy vấn cho bảng điểm danh
                    dbHelper.LoadDuLieu(sql, dgvmenu); // Tải dữ liệu vào dgvmenu
                    break;

                case "Phanhoi":
                    sql = @"
SELECT 
    ph.ID_phanhoi AS [ID], 
    sv.MaSV AS [Mã SV], 
    sv.Hodem AS [Họ đệm], 
    sv.Ten AS [Tên], 
    l.TenL AS [Tên lớp], 
    mh.Tenmonhoc AS [Tên môn học], 
    ph.Noidung AS [Nội dung], 
    ph.Ngaytao AS [Ngày tạo], 
    ph.TrangThai AS [Trạng thái]
FROM 
    PHANHOI ph
JOIN 
    SV sv ON ph.MaSV = sv.MaSV
JOIN 
    LOPSV lsv ON lsv.MaSV = sv.MaSV
JOIN 
    LOP l ON l.MaL = lsv.MaL
JOIN 
    MONHOC mh ON mh.MaL = l.MaL
ORDER BY 
    ph.ID_phanhoi
";
                    // Truy vấn cho bảng phản hồi
                    dbHelper.LoadDuLieu(sql, dgvphanhoi); // Tải dữ liệu vào dgvphanhoi
                    break;

                default:
                    MessageBox.Show("Loại dữ liệu không hợp lệ."); // Xử lý trường hợp không hợp lệ
                    return;
            }
        }
    }
}