﻿using PMTHITN.Data;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms;

namespace PMTHITN.frmgvcontrol
{
    internal class Filter
    {
        private readonly DatabaseHelper dbHelper;

        public Filter(DatabaseHelper dbHelper)
        {
            this.dbHelper = dbHelper;
        }

        //QUẢN LÝ
        // Phương thức tìm kiếm câu hỏi, môn thi, sinh viên, và điểm danh
        public void TimKiemTheoLoai(string searchText, string loai, DataGridView dgvmenu)
        {
            string sql = string.Empty;

            if (loai == "Danh sách câu hỏi")
            {
                sql = @"
            SELECT 
                MaCH AS 'Mã câu hỏi', 
                MaM AS 'Mã môn', 
                Noidung AS 'Nội dung câu hỏi', 
                Dapan AS 'Đáp án', 
                Chuong AS 'Chương' 
            FROM 
                CAUHOI 
            WHERE 
                MaCH LIKE @searchText 
                OR Noidung LIKE @searchText";
            }
            else if (loai == "Danh sách môn thi")
            {
                sql = @"
            SELECT 
                MaM AS 'Mã Môn', 
                MaMH AS 'Mã môn học', 
                Tenmon AS 'Tên môn', 
                Socau AS 'Số câu', 
                TGlambai AS 'Thời gian làm bài', 
                Thoigianthi AS 'Ngày thi' 
            FROM 
                MONTHI 
            WHERE 
                Thoigianthi LIKE @searchText 
                OR Tenmon LIKE @searchText";
            }
            else if (loai == "Danh sách sinh viên")
            {
                sql = @"
            SELECT 
                MaSV AS 'Mã SV', 
                Hodem AS 'Họ đệm', 
                Ten AS 'Tên', 
                Ngaysinh AS 'Ngày sinh', 
                Matkhau AS 'Mật khẩu' 
            FROM 
                SV 
            WHERE 
                MaSV LIKE @searchText 
                OR Hodem LIKE @searchText 
                OR Ten LIKE @searchText";
            }
            else if (loai == "Điểm danh sinh viên")
            {
                sql = @"
            SELECT 
                pdd.ID_phien AS [ID],
                l.MaL AS [Mã lớp],
                l.TenL AS [Tên lớp],
                mh.MaMH AS [Mã môn học],
                mh.Tenmonhoc AS [Tên môn học],
                pdd.Ngay AS [Ngày], 
                pdd.Gio_batdau AS [Thời gian bắt đầu], 
                pdd.Gio_ketthuc AS [Thời gian kết thúc],
                pdd.SoLan AS [Lần],
                pdd.Trangthai AS [Trạng thái]
            FROM 
                PHIENDIEMDANH pdd
            JOIN 
                LOP l ON pdd.MaL = l.MaL
            JOIN 
                MONHOC mh ON pdd.MaMH = mh.MaMH
            WHERE 
                l.TenL LIKE @searchText 
                OR pdd.Ngay LIKE @searchText";
            }

            // Sử dụng SqlParameter để tránh SQL Injection
            SqlParameter[] parameters = {
            new SqlParameter("@searchText", "%" + searchText + "%")
        };

            try
            {
                // Gọi phương thức LoadDuLieu để tải dữ liệu
                dbHelper.LoadDuLieu(sql, dgvmenu, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }

        // Phương thức tìm kiếm theo môn học trong ComboBox
        public void TimKiemTheoMonHoc(string tenMon, DataGridView dgvmenu)
        {
            string sql = "SELECT CAUHOI.MaCH, CAUHOI.MaM, CAUHOI.Noidung, CAUHOI.Dapan " +
                         "FROM CAUHOI, MONTHI " +
                         "WHERE CAUHOI.MaM = MONTHI.MaM AND MONTHI.Tenmon LIKE @TenMon";

            SqlParameter[] parameters = {
            new SqlParameter("@TenMon", "%" + tenMon + "%")
        };

            try
            {
                dbHelper.LoadDuLieu(sql, dgvmenu, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }


        //BÁO CÁO
        public void TimKiemMSSVBaoCao(string maSV, string loai, DataGridView dgvbc)
        {
            try
            {
                string query = "";

                if (loai == "Bảng điểm")
                {
                    query = @"
                    SELECT 
                        KETQUA.MaSV AS 'Mã SV', 
                        SV.Hodem AS 'Họ đệm', 
                        SV.Ten AS 'Tên', 
                        LOP.TenL AS 'Tên Lớp', 
                        MONTHI.Tenmon AS 'Tên Môn', 
                        AVG(KETQUA.Diem) AS 'Điểm Trung Bình', 
                        COUNT(KETQUA.LanThi) AS 'Số Lần Thi' 
                    FROM 
                        KETQUA 
                    INNER JOIN 
                        SV ON KETQUA.MaSV = SV.MaSV 
                    INNER JOIN 
                        LOPSV ON KETQUA.MaSV = LOPSV.MaSV 
                    INNER JOIN 
                        LOP ON LOPSV.MaL = LOP.MaL 
                    INNER JOIN 
                        MONTHI ON KETQUA.MaM = MONTHI.MaM 
                    WHERE 
                        KETQUA.MaSV LIKE '%' + @MaSV + '%'
                    GROUP BY 
                        KETQUA.MaSV, SV.Hodem, SV.Ten, LOP.TenL, MONTHI.Tenmon";
                }
                else if (loai == "Bài làm")
                {
                    query = @"
                    SELECT DISTINCT 
                        SV.MaSV AS 'Mã SV', 
                        SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                        LOP.TenL AS 'Tên lớp', 
                        MONTHI.Tenmon AS 'Tên môn', 
                        KETQUA.SoCauDung AS 'Số câu đúng', 
                        KETQUA.SoCauSai AS 'Số câu sai', 
                        KETQUA.SoCauKhongLam AS 'Số câu không làm', 
                        KETQUA.Diem AS 'Điểm', 
                        KETQUA.Lanthi AS 'Lần thi', 
                        BAILAM.NgayThi AS 'Ngày thi' 
                    FROM 
                        KETQUA 
                    INNER JOIN 
                        SV ON KETQUA.MaSV = SV.MaSV 
                    INNER JOIN 
                        LOPSV ON SV.MaSV = LOPSV.MaSV 
                    INNER JOIN 
                        LOP ON LOPSV.MaL = LOP.MaL 
                    INNER JOIN 
                        CAUHOI ON KETQUA.MaM = CAUHOI.MaM 
                    INNER JOIN 
                        MONTHI ON CAUHOI.MaM = MONTHI.MaM 
                    INNER JOIN 
                        BAILAM ON KETQUA.MaSV = BAILAM.MaSV 
                    WHERE 
                        BAILAM.MaSV = SV.MaSV 
                        AND CAUHOI.MaM = MONTHI.MaM 
                        AND BAILAM.MaCH = CAUHOI.MaCH 
                        AND KETQUA.MaSV LIKE '%' + @MaSV + '%'";
                }
                else if (loai == "Báo cáo điểm danh")
                {
                    query = @"
                    SELECT 
                        PHIENDIEMDANH.ID_phien AS 'ID Phiên', 
                        DIEMDANH.MaSV AS 'Mã SV', 
                        SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                        LOP.TenL AS 'Tên lớp', 
                        MONHOC.Tenmonhoc AS 'Môn Học',
                        DIEMDANH.Thoigian_xacnhan AS 'Ngày xác nhận', 
                        PHIENDIEMDANH.SoLan AS 'Lần',
                        DIEMDANH.Trangthai AS 'Trạng thái'
                    FROM 
                        DIEMDANH
                    INNER JOIN 
                        PHIENDIEMDANH ON DIEMDANH.ID_phien = PHIENDIEMDANH.ID_phien
                    INNER JOIN 
                        SV ON DIEMDANH.MaSV = SV.MaSV
                    INNER JOIN 
                        LOPSV ON SV.MaSV = LOPSV.MaSV
                    INNER JOIN 
                        LOP ON LOPSV.MaL = LOP.MaL
                    INNER JOIN
                        MONHOC ON MONHOC.MaMH = PHIENDIEMDANH.MaMH
                    WHERE 
                        DIEMDANH.MaSV LIKE '%' + @MaSV + '%'
                    ORDER BY 
                        PHIENDIEMDANH.SoLan, DIEMDANH.Thoigian_xacnhan;";
                }

                // Định nghĩa tham số cho câu truy vấn
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@MaSV", maSV)
                };

                // Thực hiện truy vấn và gán kết quả vào DataGridView
                DataTable dt = dbHelper.ExecuteQuery(query, parameters);
                dgvbc.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }


        public void TimKiemTenMonBaoCao(string tenMon, string loai, DataGridView dgvbc)
        {
            try
            {
                string query = "";

                if (loai == "Bảng điểm")
                {
                    query = @"
                            SELECT 
                        KETQUA.MaSV AS 'Mã SV', 
                        SV.Hodem AS 'Họ đệm', 
                        SV.Ten AS 'Tên', 
                        LOP.TenL AS 'Tên Lớp', 
                        MONTHI.Tenmon AS 'Tên Môn', 
                        AVG(KETQUA.Diem) AS 'Điểm Trung Bình', 
                        COUNT(KETQUA.LanThi) AS 'Số Lần Thi' 
                    FROM 
                        KETQUA 
                    INNER JOIN 
                        SV ON KETQUA.MaSV = SV.MaSV 
                    INNER JOIN 
                        LOPSV ON KETQUA.MaSV = LOPSV.MaSV 
                    INNER JOIN 
                        LOP ON LOPSV.MaL = LOP.MaL 
                    INNER JOIN 
                        MONTHI ON KETQUA.MaM = MONTHI.MaM 
                    WHERE 
                        MONTHI.Tenmon LIKE '%' + @Tenmon + '%'
                    GROUP BY 
                        KETQUA.MaSV, SV.Hodem, SV.Ten, LOP.TenL, MONTHI.Tenmon";

                }
                else if (loai == "Bài làm")
                {
                    query = @"
                    SELECT DISTINCT 
                SV.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONTHI.Tenmon AS 'Tên môn', 
                KETQUA.SoCauDung AS 'Số câu đúng', 
                KETQUA.SoCauSai AS 'Số câu sai', 
                KETQUA.SoCauKhongLam AS 'Số câu không làm', 
                KETQUA.Diem AS 'Điểm', 
                KETQUA.Lanthi AS 'Lần thi', 
                BAILAM.NgayThi AS 'Ngày thi' 
            FROM 
                KETQUA 
            INNER JOIN 
                SV ON KETQUA.MaSV = SV.MaSV 
            INNER JOIN 
                LOPSV ON SV.MaSV = LOPSV.MaSV 
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL 
            INNER JOIN 
                CAUHOI ON KETQUA.MaM = CAUHOI.MaM 
            INNER JOIN 
                MONTHI ON CAUHOI.MaM = MONTHI.MaM 
            INNER JOIN 
                BAILAM ON KETQUA.MaSV = BAILAM.MaSV 
            WHERE 
                MONTHI.Tenmon LIKE '%' + @Tenmon + '%' ";
                }
                else if (loai == "Báo cáo điểm danh")
                {
                    query = @"
                    SELECT 
                PHIENDIEMDANH.ID_phien AS 'ID Phiên', 
                DIEMDANH.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONHOC.Tenmonhoc AS 'Môn học',
                DIEMDANH.Thoigian_xacnhan AS 'Ngày xác nhận', 
                PHIENDIEMDANH.SoLan AS 'Lần',
                DIEMDANH.Trangthai AS 'Trạng thái'
            FROM 
                DIEMDANH
            INNER JOIN 
                PHIENDIEMDANH ON DIEMDANH.ID_phien = PHIENDIEMDANH.ID_phien
            INNER JOIN 
                SV ON DIEMDANH.MaSV = SV.MaSV
            INNER JOIN 
                LOPSV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL
            INNER JOIN 
                MONHOC ON MONHOC.MaMH = PHIENDIEMDANH.MaMH
            WHERE 
                MONHOC.Tenmonhoc LIKE '%' + @Tenmonhoc + '%'
            ORDER BY 
                PHIENDIEMDANH.SoLan, DIEMDANH.Thoigian_xacnhan";
                }

                // Định nghĩa tham số cho câu truy vấn
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Tenmon", tenMon)
                };

                // Thực hiện truy vấn và gán kết quả vào DataGridView
                DataTable dt = dbHelper.ExecuteQuery(query, parameters);
                dgvbc.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }

        public void TimKiemTenLopBaoCao(string tenLop, string loai, DataGridView dgvbc)
        {
            try
            {
                string query = "";

                if (loai == "Bảng điểm")
                {
                    query = @"
                    SELECT 
                KETQUA.MaSV AS 'Mã SV', 
                SV.Hodem AS 'Họ đệm', 
                SV.Ten AS 'Tên', 
                LOP.TenL AS 'Tên Lớp', 
                MONTHI.Tenmon AS 'Tên Môn', 
                AVG(KETQUA.Diem) AS 'Điểm Trung Bình', 
                COUNT(KETQUA.LanThi) AS 'Số Lần Thi' 
            FROM 
                KETQUA 
            INNER JOIN 
                SV ON KETQUA.MaSV = SV.MaSV 
            INNER JOIN 
                LOPSV ON KETQUA.MaSV = LOPSV.MaSV 
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL 
            INNER JOIN 
                MONTHI ON KETQUA.MaM = MONTHI.MaM 
            WHERE 
                LOP.TenL LIKE '%' + @TenL + '%' 
            GROUP BY 
                KETQUA.MaSV, SV.Hodem, SV.Ten, LOP.TenL, MONTHI.Tenmon";
                }
                else if (loai == "Bài làm")
                {
                    query = @"
                    SELECT DISTINCT 
                SV.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONTHI.Tenmon AS 'Tên môn', 
                KETQUA.SoCauDung AS 'Số câu đúng', 
                KETQUA.SoCauSai AS 'Số câu sai', 
                KETQUA.SoCauKhongLam AS 'Số câu không làm', 
                KETQUA.Diem AS 'Điểm', 
                KETQUA.Lanthi AS 'Lần thi', 
                BAILAM.NgayThi AS 'Ngày thi' 
            FROM 
                KETQUA 
            INNER JOIN 
                SV ON KETQUA.MaSV = SV.MaSV 
            INNER JOIN 
                LOPSV ON SV.MaSV = LOPSV.MaSV 
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL 
            INNER JOIN 
                CAUHOI ON KETQUA.MaM = CAUHOI.MaM 
            INNER JOIN 
                MONTHI ON CAUHOI.MaM = MONTHI.MaM 
            INNER JOIN 
                BAILAM ON KETQUA.MaSV = BAILAM.MaSV 
            WHERE 
                LOP.TenL LIKE '%' + @TenL + '%'";
                }
                else if (loai == "Báo cáo điểm danh")
                {
                    query = @"
                    SELECT 
                PHIENDIEMDANH.ID_phien AS 'ID Phiên', 
                DIEMDANH.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONHOC.Tenmonhoc AS 'Môn học',
                DIEMDANH.Thoigian_xacnhan AS 'Ngày xác nhận', 
                PHIENDIEMDANH.SoLan AS 'Lần',
                DIEMDANH.Trangthai AS 'Trạng thái'
            FROM DIEMDANH
            INNER JOIN PHIENDIEMDANH ON DIEMDANH.ID_phien = PHIENDIEMDANH.ID_phien
            INNER JOIN SV ON DIEMDANH.MaSV = SV.MaSV
            INNER JOIN LOPSV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN LOP ON LOPSV.MaL = LOP.MaL
            INNER JOIN MONHOC ON MONHOC.MaMH = PHIENDIEMDANH.MaMH
            WHERE 
                LOP.TenL LIKE '%' + @TenL + '%'
            ORDER BY 
                PHIENDIEMDANH.SoLan, DIEMDANH.Thoigian_xacnhan;";
                }

                // Định nghĩa tham số cho câu truy vấn
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@TenL", tenLop)
                };

                // Thực hiện truy vấn và gán kết quả vào DataGridView
                DataTable dt = dbHelper.ExecuteQuery(query, parameters);
                dgvbc.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }

        public void TimKiemNgayBaoCao(string Ngaybaocao, string loai, DataGridView dgvbc)
        {
            try
            {
                DateTime startDate = DateTime.Parse(Ngaybaocao).Date;
                DateTime endDate = startDate.AddDays(1); // Thêm một ngày để bao gồm cả ngày báo cáo

                string query = "";

                if (loai == "Bài làm")
                {
                    query = @"
            SELECT DISTINCT 
                SV.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONTHI.Tenmon AS 'Tên môn', 
                KETQUA.SoCauDung AS 'Số câu đúng', 
                KETQUA.SoCauSai AS 'Số câu sai', 
                KETQUA.SoCauKhongLam AS 'Số câu không làm', 
                KETQUA.Diem AS 'Điểm', 
                KETQUA.Lanthi AS 'Lần thi', 
                BAILAM.NgayThi AS 'Ngày thi' 
            FROM 
                KETQUA 
            INNER JOIN 
                SV ON KETQUA.MaSV = SV.MaSV 
            INNER JOIN 
                LOPSV ON SV.MaSV = LOPSV.MaSV 
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL 
            INNER JOIN 
                CAUHOI ON KETQUA.MaM = CAUHOI.MaM 
            INNER JOIN 
                MONTHI ON CAUHOI.MaM = MONTHI.MaM 
            INNER JOIN 
                BAILAM ON KETQUA.MaSV = BAILAM.MaSV 
            WHERE 
                BAILAM.MaSV = SV.MaSV 
                AND CAUHOI.MaM = MONTHI.MaM 
                AND BAILAM.MaCH = CAUHOI.MaCH 
                AND BAILAM.NgayThi >= @StartDate AND BAILAM.NgayThi < @EndDate;";
                }
                else if (loai == "Báo cáo điểm danh")
                {
                    query = @"
            SELECT 
                PHIENDIEMDANH.ID_phien AS 'ID Phiên', 
                DIEMDANH.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONHOC.Tenmonhoc AS 'Môn học',
                DIEMDANH.Thoigian_xacnhan AS 'Ngày xác nhận', 
                PHIENDIEMDANH.SoLan AS 'Lần',
                DIEMDANH.Trangthai AS 'Trạng thái'
            FROM 
                DIEMDANH
            INNER JOIN 
                PHIENDIEMDANH ON DIEMDANH.ID_phien = PHIENDIEMDANH.ID_phien
            INNER JOIN 
                SV ON DIEMDANH.MaSV = SV.MaSV
            INNER JOIN 
                LOPSV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL
            INNER JOIN 
                MONHOC ON MONHOC.MaMH = PHIENDIEMDANH.MaMH
            WHERE 
                DIEMDANH.Thoigian_xacnhan >= @StartDate AND DIEMDANH.Thoigian_xacnhan < @EndDate
            ORDER BY 
                PHIENDIEMDANH.SoLan, DIEMDANH.Thoigian_xacnhan;";
                }

                // Định nghĩa tham số cho câu truy vấn
                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@StartDate", startDate),
            new SqlParameter("@EndDate", endDate)
                };

                // Thực hiện truy vấn và gán kết quả vào DataGridView
                DataTable dt = dbHelper.ExecuteQuery(query, parameters);
                dgvbc.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }






        //PHẢN HỒI
        public void TimKiemMSSVPhanHoi(TextBox txttimkiemmssv_phanhoi, DataGridView dgvphanhoi)
        {
            string searchValue = txttimkiemmssv_phanhoi.Text.Trim();
            string query = @"
                SELECT 
                    ph.ID_phanhoi AS [ID], 
                    sv.MaSV AS [Mã SV], 
                    sv.Hodem AS [Họ đệm], 
                    sv.Ten AS [Tên], 
                    l.TenL AS [Tên lớp], 
                    mh.Tenmonhoc AS [Tên môn học], 
                    ph.Noidung AS [Nội dung], 
                    ph.Ngaytao AS [Ngày tạo], 
                    ph.Trangthai AS [Trạng thái]
                FROM 
                    PHANHOI ph
                INNER JOIN 
                    SV sv ON ph.MaSV = sv.MaSV
                INNER JOIN 
                    LOPSV lsv ON lsv.MaSV = sv.MaSV
                INNER JOIN 
                    LOP l ON l.MaL = lsv.MaL
                INNER JOIN 
                    MONHOC mh ON mh.MaL = l.MaL
                WHERE 
                    sv.MaSV LIKE @MaSV";

            SqlParameter[] parameters = {
                new SqlParameter("@MaSV", "%" + searchValue + "%")
            };

            try
            {
                dbHelper.LoadDuLieu(query, dgvphanhoi, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tìm kiếm: {ex.Message}");
            }
        }

        public void TimKiemMonPhanHoi(ComboBox txttimkiemmon_phanhoi, DataGridView dgvphanhoi)
        {
            string selectedMonHoc = txttimkiemmon_phanhoi.SelectedItem.ToString();
            string query = @"
                SELECT 
                    ph.ID_phanhoi AS [ID], 
                    sv.MaSV AS [Mã SV], 
                    sv.Hodem AS [Họ đệm], 
                    sv.Ten AS [Tên], 
                    l.TenL AS [Tên lớp], 
                    mh.Tenmonhoc AS [Tên môn học], 
                    ph.Noidung AS [Nội dung], 
                    ph.Ngaytao AS [Ngày tạo], 
                    ph.Trangthai AS [Trạng thái]
                FROM 
                    PHANHOI ph
                INNER JOIN 
                    SV sv ON ph.MaSV = sv.MaSV
                INNER JOIN 
                    LOPSV lsv ON lsv.MaSV = sv.MaSV
                INNER JOIN 
                    LOP l ON l.MaL = lsv.MaL
                INNER JOIN 
                    MONHOC mh ON mh.MaL = l.MaL
                WHERE 
                    mh.Tenmonhoc = @TenMonHoc";

            SqlParameter[] parameters = {
                new SqlParameter("@TenMonHoc", selectedMonHoc)
            };

            try
            {
                dbHelper.LoadDuLieu(query, dgvphanhoi, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tìm kiếm: {ex.Message}");
            }
        }

        public void TimKiemLopPhanHoi(TextBox txttimkiemlop_phanhoi, DataGridView dgvphanhoi)
        {
            string searchValue = txttimkiemlop_phanhoi.Text.Trim();
            string query = @"
                SELECT 
                    ph.ID_phanhoi AS [ID], 
                    sv.MaSV AS [Mã SV], 
                    sv.Hodem AS [Họ đệm], 
                    sv.Ten AS [Tên], 
                    l.TenL AS [Tên lớp], 
                    mh.Tenmonhoc AS [Tên môn học], 
                    ph.Noidung AS [Nội dung], 
                    ph.Ngaytao AS [Ngày tạo], 
                    ph.Trangthai AS [Trạng thái]
                FROM 
                    PHANHOI ph
                INNER JOIN 
                    SV sv ON ph.MaSV = sv.MaSV
                INNER JOIN 
                    LOPSV lsv ON lsv.MaSV = sv.MaSV
                INNER JOIN 
                    LOP l ON l.MaL = lsv.MaL
                INNER JOIN 
                    MONHOC mh ON mh.MaL = l.MaL
                WHERE 
                    l.TenL LIKE @TenL";

            SqlParameter[] parameters = {
                new SqlParameter("@TenL", "%" + searchValue + "%")
            };

            try
            {
                dbHelper.LoadDuLieu(query, dgvphanhoi, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tìm kiếm: {ex.Message}");
            }
        }

        public void TimKiemNgayPhanHoi(DateTimePicker dtptimkiem_phanhoi, DataGridView dgvphanhoi)
        {
            string query = @"
                SELECT 
                    ph.ID_phanhoi AS [ID], 
                    sv.MaSV AS [Mã SV], 
                    sv.Hodem AS [Họ đệm], 
                    sv.Ten AS [Tên], 
                    l.TenL AS [Tên lớp], 
                    mh.Tenmonhoc AS [Tên môn học], 
                    ph.Noidung AS [Nội dung], 
                    ph.Ngaytao AS [Ngày tạo], 
                    ph.Trangthai AS [Trạng thái]
                FROM 
                    PHANHOI ph
                INNER JOIN 
                    SV sv ON ph.MaSV = sv.MaSV
                INNER JOIN 
                    LOPSV lsv ON lsv.MaSV = sv.MaSV
                INNER JOIN 
                    LOP l ON l.MaL = lsv.MaL
                INNER JOIN 
                    MONHOC mh ON mh.MaL = l.MaL
                WHERE 
                    ph.Ngaytao >= @StartDate AND ph.Ngaytao < @EndDate
                ORDER BY 
                    ph.ID_phanhoi";

            DateTime selectedDate = dtptimkiem_phanhoi.Value.Date;
            DateTime startDate = selectedDate; // Ngày bắt đầu
            DateTime endDate = selectedDate.AddDays(1); // Ngày kết thúc

            SqlParameter[] parameters = {
                new SqlParameter("@StartDate", startDate),
                new SqlParameter("@EndDate", endDate)
            };

            try
            {
                dbHelper.LoadDuLieu(query, dgvphanhoi, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }
    }
}

