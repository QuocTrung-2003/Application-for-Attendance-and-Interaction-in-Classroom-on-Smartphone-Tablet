﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace PMTHITN.frmgvcontrol
{
    internal class Hidebnt
    {
        public void SetControlVisibilityAndEnablement(Panel panelcauhoi, Panel panel5,

            TextBox txtmamon,
            TextBox txtmamonhoc,
            TextBox txttenmon,
            TextBox txtthoigian,
            TextBox txtsocau,
            TextBox txtmach,
            TextBox txtnoidung,
            TextBox txtmassv_phanhoi,
            TextBox txthodem_phanhoi,
            TextBox txtten_phanhoi,
            TextBox txtlop_phanhoi,
            TextBox txtmon_phanhoi,
            RichTextBox txtnoidung_phanhoi,
            TextBox txtngay_phanhoi,

            ComboBox cmbmon,
            ComboBox comboBoxChuong,
            ComboBox cmbdapan,
            ComboBox cmbtrangthai,

            DateTimePicker dtptgthi,
            DateTimePicker dptthoigianbatdau,
            DateTimePicker dptthoigianketthuc,

            Button btnthem,
            Button btnxoa,
            Button btnsua,
            Button btnluu,
            Button btnhuy,
            Button btndiemdanh,

            Label lbl_ID_phien_baocao,
            Label lbltrangthai_baocao,
            TextBox txt_ID_phien_baocao,
            ComboBox cmbtrangthai_baocao,
            Button btnluubaocao,
            Button btnhuybaocao)
        {
            panelcauhoi.Visible = false;
            panel5.Visible = false;
            //// Set visibility to false




            // Set enabled to false
            txtmach.Enabled = false;
            txtnoidung.Enabled = false;
            txtmamon.Enabled = false;
            txtmamonhoc.Enabled = false;
            txtsocau.Enabled = false;
            txtthoigian.Enabled = false;
            txttenmon.Enabled = false;
            txtmassv_phanhoi.Enabled = false;
            txthodem_phanhoi.Enabled = false;
            txtten_phanhoi.Enabled = false;
            txtlop_phanhoi.Enabled = false;
            txtmon_phanhoi.Enabled = false;
            txtnoidung_phanhoi.Enabled = false;
            txtngay_phanhoi.Enabled = false;

            cmbdapan.Enabled = false;
            cmbmon.Enabled = false;
            comboBoxChuong.Enabled = false;
            cmbtrangthai.Enabled = false;

            dtptgthi.Enabled = false;
            dptthoigianbatdau.Enabled = false;
            dptthoigianketthuc.Enabled = false;

            btnthem.Enabled = true;
            btnxoa.Enabled = false;
            btnsua.Enabled = false;
            btnluu.Enabled = false;
            btnhuy.Enabled = false;
            btndiemdanh.Enabled = false;

            lbl_ID_phien_baocao.Visible = false;
            lbltrangthai_baocao.Visible = false;
            txt_ID_phien_baocao.Visible = false;
            cmbtrangthai_baocao.Visible = false;
            btnluubaocao.Visible = false;
            btnhuybaocao.Visible = false;
        }
        public void CapNhatTrangThaiNut_Class(bool them, bool sua, bool xoa, bool luu, bool huy, bool diemdanh,
        Button btnThem, Button btnSua, Button btnXoa, Button btnLuu, Button btnHuy, Button btnDiemDanh)
        {
            btnThem.Enabled = them;
            btnSua.Enabled = sua;
            btnXoa.Enabled = xoa;
            btnLuu.Enabled = luu;
            btnHuy.Enabled = huy;
            btnDiemDanh.Enabled = diemdanh;
        }
    }
}

