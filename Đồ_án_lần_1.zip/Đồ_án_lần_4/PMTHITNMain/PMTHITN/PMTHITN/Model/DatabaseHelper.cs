﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMTHITN.Data
{
    public class DatabaseHelper

    {
        private SqlConnection conn;
        private SqlDataAdapter da;
        private DataTable dt;
        private string connectionString; // Biến thành viên để lưu chuỗi kết nối



        public DatabaseHelper(string dataSource, string databaseName)
        {
            connectionString = $"Data Source={dataSource};Initial Catalog={databaseName};Integrated Security=True;Encrypt=False";

        }


        public SqlConnection GetConnection()
        {
            SqlConnection conn = new SqlConnection(connectionString); // Khởi tạo kết nối mới
            conn.Open();
            return conn;
        }

        public void ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters); // Thêm tham số nếu có
                    }
                    command.ExecuteNonQuery(); // Thực hiện truy vấn
                }
            }
        }

        public DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
        {
            try
            {
                DataTable resultTable = new DataTable();
                using (SqlConnection connection = GetConnection())
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters); // Thêm tham số nếu có
                        }
                        using (SqlDataAdapter da = new SqlDataAdapter(command))
                        {
                            da.Fill(resultTable); // Điền dữ liệu vào DataTable
                        }
                    }
                }
                return resultTable; // Trả về DataTable chứa kết quả
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
                return null;
            }
        }

        public object ExecuteScalar(string query, SqlParameter[] parameters = null)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters); // Thêm tham số nếu có
                    }
                    return command.ExecuteScalar(); // Trả về giá trị đơn lẻ
                }
            }
        }

        public void LoadDataWithParameters(string sql, DataGridView dgv, SqlParameter[] parameters = null)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters); // Thêm tham số nếu có
                    }

                    using (SqlDataAdapter da = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgv.DataSource = dt;
                    }
                }
            }
        }


        public DataTable GetDataTable(string sql, SqlParameter[] parameters = null)
        {
            DataTable resultTable = new DataTable();
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters); // Thêm tham số nếu có
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(command))
                    {
                        da.Fill(resultTable); // Điền dữ liệu vào DataTable
                    }
                }
            }
            return resultTable; // Trả về DataTable chứa kết quả
        }



        public void Chitiet(bool a, Control[] controls)
        {
            foreach (var control in controls)
            {
                control.Enabled = a;
            }
        }


        public void Lamsach(Control[] controls)
        {
            foreach (var control in controls)
            {
                if (control is TextBox textBox)
                {
                    textBox.Clear();
                }
                else if (control is ComboBox comboBox)
                {
                    comboBox.Text = "";
                }
            }
        }
        private DataGridView dgvmenu;
        private DataGridView dgvphanhoi;
        public void LoadDuLieu(string sql, DataGridView dgv, SqlParameter[] parameters = null)
        {
            using (SqlConnection connection = GetConnection()) // Sử dụng kết nối để thực hiện lệnh
            {
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    // Nếu có tham số, thêm chúng vào SqlCommand
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    SqlDataAdapter da = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Giữ nguyên tên cột
                    foreach (DataColumn column in dt.Columns)
                    {
                        column.ColumnName = column.ColumnName; // Không thay đổi tên cột
                    }

                    dgv.DataSource = dt;
                }

                // Ẩn cột hoặc tùy chỉnh giao diện cho từng DataGridView nếu cần
                if (dgv == dgvmenu)
                {
                    // Tùy chỉnh dgvmenu nếu cần
                }
                else if (dgv == dgvphanhoi)
                {
                    // Ẩn cột ID hoặc cột không cần thiết cho dgvphanhoi
                }
            }
        }


        private DataGridView dgvdiemdanhsv;
        private DataGridView dgvphanhoisv;
        public void LoadDuLieuforsv(string sql, DataGridView dgvsv, SqlParameter[] parameters = null)
        {
            using (SqlConnection connection = GetConnection()) // Sử dụng kết nối để thực hiện lệnh
            {
                // Kiểm tra xem câu lệnh SQL có bị trống không
                if (string.IsNullOrWhiteSpace(sql))
                {
                    throw new InvalidOperationException("Câu lệnh SQL không được khởi tạo.");
                }

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    // Nếu có tham số, thêm chúng vào SqlCommand
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    // Kiểm tra câu lệnh SQL đã được khởi tạo và in ra (để debug)
                    Console.WriteLine("SQL Command: " + command.CommandText);

                    SqlDataAdapter da = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Giữ nguyên tên cột
                    foreach (DataColumn column in dt.Columns)
                    {
                        column.ColumnName = column.ColumnName; // Không thay đổi tên cột
                    }

                    dgvsv.DataSource = dt;
                }

                // Tùy chỉnh các cột hiển thị nếu cần
                if (dgvsv == dgvdiemdanhsv)
                {
                    // Xử lý tùy chỉnh cho dgvdiemdanhsv
                }
                else if (dgvsv == dgvphanhoisv)
                {
                    // Ẩn các cột không cần thiết cho dgvphanhoisv
                }
            }
        }



    }
}
