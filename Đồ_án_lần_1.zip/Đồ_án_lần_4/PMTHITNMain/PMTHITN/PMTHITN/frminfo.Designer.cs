﻿namespace PMTHITN
{
    partial class frminfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frminfo));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grbtt = new System.Windows.Forms.GroupBox();
            this.btnvaothi = new PMTHITN.RJButton();
            this.lblthoigian = new System.Windows.Forms.Label();
            this.lblsocau = new System.Windows.Forms.Label();
            this.lblmonthi = new System.Windows.Forms.Label();
            this.lblmsv = new System.Windows.Forms.Label();
            this.lblhoten = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grbtt.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(20, 60);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1097, 116);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(126, 116);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(457, 68);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(269, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bài tập trắc nghiệm";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(121, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(949, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "TRƯỜNG ĐẠI HỌC MỞ TP. HỒ CHÍ MINH";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // grbtt
            // 
            this.grbtt.Controls.Add(this.btnvaothi);
            this.grbtt.Controls.Add(this.lblthoigian);
            this.grbtt.Controls.Add(this.lblsocau);
            this.grbtt.Controls.Add(this.lblmonthi);
            this.grbtt.Controls.Add(this.lblmsv);
            this.grbtt.Controls.Add(this.lblhoten);
            this.grbtt.Controls.Add(this.label5);
            this.grbtt.Controls.Add(this.label4);
            this.grbtt.Controls.Add(this.label3);
            this.grbtt.Controls.Add(this.label6);
            this.grbtt.Controls.Add(this.label7);
            this.grbtt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbtt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbtt.ForeColor = System.Drawing.Color.Black;
            this.grbtt.Location = new System.Drawing.Point(20, 176);
            this.grbtt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grbtt.Name = "grbtt";
            this.grbtt.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grbtt.Size = new System.Drawing.Size(1097, 449);
            this.grbtt.TabIndex = 3;
            this.grbtt.TabStop = false;
            this.grbtt.Text = "Thông tin:";
            this.grbtt.Enter += new System.EventHandler(this.grbtt_Enter);
            // 
            // btnvaothi
            // 
            this.btnvaothi.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnvaothi.BackgroundColor = System.Drawing.Color.DodgerBlue;
            this.btnvaothi.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnvaothi.BorderRadius = 20;
            this.btnvaothi.BorderSize = 0;
            this.btnvaothi.FlatAppearance.BorderSize = 0;
            this.btnvaothi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvaothi.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvaothi.ForeColor = System.Drawing.Color.White;
            this.btnvaothi.Location = new System.Drawing.Point(458, 324);
            this.btnvaothi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnvaothi.Name = "btnvaothi";
            this.btnvaothi.Size = new System.Drawing.Size(264, 62);
            this.btnvaothi.TabIndex = 20;
            this.btnvaothi.Text = "Bắt đầu làm bài";
            this.btnvaothi.TextColor = System.Drawing.Color.White;
            this.btnvaothi.UseVisualStyleBackColor = false;
            this.btnvaothi.Click += new System.EventHandler(this.btnvaothi_Click);
            // 
            // lblthoigian
            // 
            this.lblthoigian.AutoSize = true;
            this.lblthoigian.BackColor = System.Drawing.Color.Transparent;
            this.lblthoigian.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblthoigian.ForeColor = System.Drawing.Color.Black;
            this.lblthoigian.Location = new System.Drawing.Point(645, 271);
            this.lblthoigian.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblthoigian.Name = "lblthoigian";
            this.lblthoigian.Size = new System.Drawing.Size(105, 29);
            this.lblthoigian.TabIndex = 19;
            this.lblthoigian.Text = "tglambai";
            this.lblthoigian.Click += new System.EventHandler(this.lblthoigian_Click);
            // 
            // lblsocau
            // 
            this.lblsocau.AutoSize = true;
            this.lblsocau.BackColor = System.Drawing.Color.Transparent;
            this.lblsocau.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsocau.ForeColor = System.Drawing.Color.Black;
            this.lblsocau.Location = new System.Drawing.Point(645, 219);
            this.lblsocau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsocau.Name = "lblsocau";
            this.lblsocau.Size = new System.Drawing.Size(77, 29);
            this.lblsocau.TabIndex = 18;
            this.lblsocau.Text = "socau";
            // 
            // lblmonthi
            // 
            this.lblmonthi.AutoSize = true;
            this.lblmonthi.BackColor = System.Drawing.Color.Transparent;
            this.lblmonthi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmonthi.ForeColor = System.Drawing.Color.Black;
            this.lblmonthi.Location = new System.Drawing.Point(645, 169);
            this.lblmonthi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmonthi.Name = "lblmonthi";
            this.lblmonthi.Size = new System.Drawing.Size(103, 29);
            this.lblmonthi.TabIndex = 17;
            this.lblmonthi.Text = "Tenmon";
            this.lblmonthi.Click += new System.EventHandler(this.lblmonthi_Click);
            // 
            // lblmsv
            // 
            this.lblmsv.AutoSize = true;
            this.lblmsv.BackColor = System.Drawing.Color.Transparent;
            this.lblmsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsv.ForeColor = System.Drawing.Color.Black;
            this.lblmsv.Location = new System.Drawing.Point(645, 115);
            this.lblmsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmsv.Name = "lblmsv";
            this.lblmsv.Size = new System.Drawing.Size(77, 29);
            this.lblmsv.TabIndex = 16;
            this.lblmsv.Text = "MaSV";
            // 
            // lblhoten
            // 
            this.lblhoten.AutoSize = true;
            this.lblhoten.BackColor = System.Drawing.Color.Transparent;
            this.lblhoten.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhoten.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblhoten.Location = new System.Drawing.Point(645, 59);
            this.lblhoten.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblhoten.Name = "lblhoten";
            this.lblhoten.Size = new System.Drawing.Size(93, 29);
            this.lblhoten.TabIndex = 15;
            this.lblhoten.Text = "Tên SV";
            this.lblhoten.Click += new System.EventHandler(this.lblhoten_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(441, 271);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(204, 29);
            this.label5.TabIndex = 14;
            this.label5.Text = "Thời gian làm bài:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(441, 219);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 29);
            this.label4.TabIndex = 13;
            this.label4.Text = "Số câu:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(441, 169);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 29);
            this.label3.TabIndex = 12;
            this.label3.Text = "Môn:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(441, 115);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 29);
            this.label6.TabIndex = 11;
            this.label6.Text = "Mã sinh viên:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(441, 59);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 29);
            this.label7.TabIndex = 10;
            this.label7.Text = "Họ tên:";
            // 
            // frminfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 645);
            this.Controls.Add(this.grbtt);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "frminfo";
            this.Text = "frminfo";
            this.Load += new System.EventHandler(this.frminfo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grbtt.ResumeLayout(false);
            this.grbtt.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grbtt;
        private System.Windows.Forms.Label lblthoigian;
        private System.Windows.Forms.Label lblsocau;
        private System.Windows.Forms.Label lblmonthi;
        private System.Windows.Forms.Label lblmsv;
        private System.Windows.Forms.Label lblhoten;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private RJButton btnvaothi;
    }
}