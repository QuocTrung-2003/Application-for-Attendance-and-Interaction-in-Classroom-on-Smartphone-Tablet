﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PMTHITN.Class;
using PMTHITN.Data;
using PMTHITN.frmgvcontrol;

namespace PMTHITN
{
    public partial class frmgv : MetroFramework.Forms.MetroForm
    {
        SqlConnection conn = new SqlConnection();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand cmd = new SqlCommand();
        DataTable dt = new DataTable();
        SqlCommand lenh = new SqlCommand();
        string sql;
        private DatabaseHelper dbHelper;
        public frmgv()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper("MSI\\MSSQLSERVER01", "THITRACNGHIEM");
            //dbHelper = new DatabaseHelper(dgvmenu, dgvphanhoi);
        }
        private void frmgv_Load(object sender, EventArgs e)
        {

            using (SqlConnection conn = dbHelper.GetConnection())
            {

            }

            Hidebnt hideControl = new Hidebnt();
            hideControl.SetControlVisibilityAndEnablement(panelcauhoi, panel5,
                txtmamon, txttenmon, txtmamonhoc, txtthoigian, txtsocau,
                txtmach, txtnoidung, txtmssv_phanhoi, txthodem_phanhoi, txtten_phanhoi, txtlop_phanhoi,
                txtmon_phanhoi, txtnoidung_phanhoi, txtngay_phanhoi, cmbmon, comboBoxChuong,
                cmbdapan, cmbtrangthai, dtptgthi, dptthoigianbatdau, dptthoigianketthuc,
                btnthem, btnxoa, btnsua, btnluu, btnhuy, btndiemdanh,
                lbl_ID_phien_baocao, lbltrangthai_baocao, txt_ID_phien_baocao, cmbtrangthai_baocao, btnluubaocao, btnhuybaocao);
        }

        private void LoadDuLieu(string sql)
        {
            dbHelper.LoadDuLieu(sql, dgvmenu);

        }

        private void Chitiet(bool a)
        {
            Control[] controls = { txtmamon, txtsocau, txtthoigian, txttenmon, txtmamonhoc, dtptgthi, txtmach, txtnoidung,
                                   cmbdapan, cmbmon, comboBoxChuong, cmbtrangthai, dptthoigianbatdau, dptthoigianketthuc };
            dbHelper.Chitiet(a, controls);
        }

        private void Lamsach()
        {
            Control[] controls = { txtmach, txtmamon, txtnoidung, txtsocau, txttenmon, txtthoigian,
                                   cmbdapan, cmbmon, comboBoxChuong, cmbtrangthai };
            dbHelper.Lamsach(controls);
        }


        // PHẦN CÂU HỎI CỦA QUẢN LÝ
        //private void CapNhatTrangThaiNut(bool them, bool sua, bool xoa, bool luu, bool huy, bool diemdanh)
        //{
        //    Hidebnt hidebnt = new Hidebnt();

        //    // Ví dụ cập nhật trạng thái của các nút
        //    hidebnt.CapNhatTrangThaiNut_Class(them, sua, xoa, luu, huy, diemdanh,
        //        btnthem, btnsua, btnxoa, btnluu, btnhuy, btndiemdanh);
        //}

        private void piccauhoi_Click(object sender, EventArgs e)
        {

            // Môn thi
            lblmamon.Visible = false;
            lbltenmon.Visible = false;
            lblsocau.Visible = false;
            lblthoigian.Visible = false;
            txtmamon.Visible = false;
            txttenmon.Visible = false;
            txtthoigian.Visible = false;
            txtsocau.Visible = false;
            dtptgthi.Visible = false;
            lbltgthi.Visible = false;
            lbltrangthai.Visible = false;
            cmbtrangthai.Visible = false;
            btndiemdanh.Visible = false;
            dptthoigianbatdau.Visible = false;
            dptthoigianketthuc.Visible = false;
            lblmamonhoc.Visible = false;
            txtmamonhoc.Visible = false;
            // Câu hỏi
            panelcauhoi.Visible = true;
            lblmonthi.Visible = true;
            lblnoidungch.Visible = true;
            lbldapan.Visible = true;
            txtmach.Visible = true;
            cmbdapan.Visible = true;
            cmbmon.Visible = true;
            cmbloc.Visible = true;
            lblloc.Visible = true;
            txtnoidung.Visible = true;
            txtmach.Visible = true;
            lblmach.Visible = true;
            lblchuong.Visible = true;
            comboBoxChuong.Visible = true;

            // Làm sạch
            Lamsach();

            // Datagridview
            grbcauhoi.Text = "Danh sách câu hỏi";
            sql = "select MaCH as 'Mã câu hỏi', MaM as 'Mã môn', Noidung as 'Nội dung câu hỏi', Dapan as 'Đáp án', Chuong as 'Chương' from CAUHOI";
            LoadDuLieu(sql);

            dgvmenu.Columns["Mã câu hỏi"].DisplayIndex = 0;
            dgvmenu.Columns["Mã môn"].DisplayIndex = 1;
            //dgvmenu.Columns["Nội dung câu hỏi"].DisplayIndex = 2;
            //dgvmenu.Columns["Đáp án"].DisplayIndex = 3;

            // Ẩn hiện nút
            //CapNhatTrangThaiNut(true, false, false, false, false, false);
            type = "CauHoi";
            RefreshData_Click(sender, e);
        }

        private void picmonthi_Click(object sender, EventArgs e)
        {
            // Câu hỏi
            lblmonthi.Visible = false;
            lblnoidungch.Visible = false;
            lbldapan.Visible = false;
            txtmach.Visible = false;
            cmbdapan.Visible = false;
            lblchuong.Visible = false;
            comboBoxChuong.Visible = false;
            cmbmon.Visible = false;
            cmbloc.Visible = false;
            lblloc.Visible = false;
            txtnoidung.Visible = false;
            txtmach.Visible = false;
            lblmach.Visible = false;
            lbltrangthai.Visible = false;
            cmbtrangthai.Visible = false;
            btndiemdanh.Visible = false;
            dptthoigianbatdau.Visible = false;
            dptthoigianketthuc.Visible = false;

            // Môn thi
            panelcauhoi.Visible = true;
            lblmamon.Visible = true;
            lbltenmon.Visible = true;
            lblsocau.Visible = true;
            lblthoigian.Visible = true;
            txtmamon.Visible = true;
            txttenmon.Visible = true;
            txtthoigian.Visible = true;
            txtsocau.Visible = true;
            dtptgthi.Visible = true;
            lbltgthi.Visible = true;
            lblmamonhoc.Visible = true;
            txtmamonhoc.Visible = true;

            // Đặt định dạng hiển thị cho DateTimePicker
            dtptgthi.Format = DateTimePickerFormat.Custom;
            dtptgthi.CustomFormat = "dd/MM/yyyy HH:mm"; // Định dạng: ngày/tháng/năm giờ:phút
            // Đổi tên lbl
            lblmamon.Text = "Mã môn:";
            lbltenmon.Text = "Tên môn:";
            lbltgthi.Text = "Thời gian thi:";
            lblsocau.Text = "Số câu:";
            lblthoigian.Text = "Thời gian:";

            // Làm sạch
            Lamsach();

            // Datagridview
            grbcauhoi.Text = "Danh sách môn thi";
            sql = "select MaM as 'Mã Môn', MaMH as 'Mã môn học', Tenmon as 'Tên môn', Socau as 'Số câu', TGlambai as 'Thời gian làm bài', Thoigianthi as 'Ngày thi' from MONTHI";
            LoadDuLieu(sql);

            // Ẩn hiện nút chức năng
            //CapNhatTrangThaiNut(true, false, false, false, false, false);

            type = "MonHoc";
            RefreshData_Click(sender, e);
        }

        private void picsv_Click(object sender, EventArgs e)
        {
            // Câu hỏi
            lblmonthi.Visible = false;
            lblnoidungch.Visible = false;
            lbldapan.Visible = false;
            txtmach.Visible = false;
            cmbdapan.Visible = false;
            lblchuong.Visible = false;
            comboBoxChuong.Visible = false;
            cmbmon.Visible = false;
            cmbloc.Visible = false;
            lblloc.Visible = false;
            txtnoidung.Visible = false;
            txtmach.Visible = false;
            lblmach.Visible = false;
            lbltrangthai.Visible = false;
            cmbtrangthai.Visible = false;
            btndiemdanh.Visible = false;
            dptthoigianbatdau.Visible = false;
            dptthoigianketthuc.Visible = false;
            lblmamonhoc.Visible = false;
            txtmamonhoc.Visible = false;
            txtthoigian.Text = "";

            // Môn thi
            panelcauhoi.Visible = true;
            lblmamon.Visible = true;
            lbltenmon.Visible = true;
            lblsocau.Visible = true;
            lblthoigian.Visible = true;
            txtmamon.Visible = true;
            txttenmon.Visible = true;
            txtthoigian.Visible = true;
            txtsocau.Visible = true;
            dtptgthi.Visible = true;
            lbltgthi.Visible = true;

            // Đặt định dạng hiển thị cho DateTimePicker
            dtptgthi.Format = DateTimePickerFormat.Custom;
            dtptgthi.CustomFormat = "dd/MM/yyyy"; // Định dạng ngày: ngày/tháng/năm
            // Đổi tên lbl
            lblmamon.Text = "Mã SV:";
            lbltenmon.Text = "Họ đệm:";
            lbltgthi.Text = "Ngày sinh:";
            lblsocau.Text = "Tên:";
            lblthoigian.Text = "Mật khẩu:";
            grbcauhoi.Text = "Danh sách sinh viên";

            // làm sạch
            Lamsach();
            // Load dữ liệu
            sql = "select MaSV as 'Mã SV', Hodem as 'Họ đệm', Ten as 'Tên', Ngaysinh as 'Ngày sinh', Matkhau as 'Mật khẩu' from SV";

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            LoadDuLieu(sql); // Gọi hàm để tải dữ liệu

            stopwatch.Stop();
            MessageBox.Show($"Thời gian tải dữ liệu: {stopwatch.ElapsedMilliseconds} ms");

            type = "SinhVien";
            RefreshData_Click(sender, e);
        }
        private void picsdiemdanh_Click(object sender, EventArgs e)
        {
            // Ẩn các trường không cần thiết
            txtsocau.Visible = false;
            txtthoigian.Visible = false;
            lblmonthi.Visible = false;
            lblnoidungch.Visible = false;
            lbldapan.Visible = false;
            txtmach.Visible = false;
            cmbdapan.Visible = false;
            lblchuong.Visible = false;
            comboBoxChuong.Visible = false;
            cmbmon.Visible = false;
            cmbloc.Visible = false;
            lblloc.Visible = false;
            txtnoidung.Visible = false;
            txtmach.Visible = false;
            lblmach.Visible = false;
            lblmamonhoc.Visible = false;
            txtmamonhoc.Visible = false;

            // Hiển thị các trường cần thiết
            panelcauhoi.Visible = true;
            lblmamon.Visible = true;
            lbltenmon.Visible = true;
            lblsocau.Visible = true;
            lblthoigian.Visible = true;
            txtmamon.Visible = true;
            txttenmon.Visible = true;
            dtptgthi.Visible = true;
            lbltgthi.Visible = true;
            lbltrangthai.Visible = true;
            cmbtrangthai.Visible = true;
            btndiemdanh.Visible = true;
            dptthoigianbatdau.Visible = true;
            dptthoigianketthuc.Visible = true;

            // Đặt định dạng hiển thị cho DateTimePicker
            dtptgthi.Format = DateTimePickerFormat.Custom;
            dtptgthi.CustomFormat = "dd/MM/yyyy HH:mm"; // Định dạng: ngày/tháng/năm giờ:phút
            // Đổi tên lbl
            lblmamon.Text = "Mã lớp:";
            lbltenmon.Text = "Mã môn học:";
            lbltgthi.Text = "Ngày";
            lblsocau.Text = "Thời gian bắt đầu:";
            lblthoigian.Text = "Thời gian kết thúc:";
            grbcauhoi.Text = "Điểm danh sinh viên";

            // Load dữ liệu
            string sql = @"
                   SELECT 
                pdd.ID_phien AS [ID],
                l.MaL AS [Mã lớp],
                l.TenL AS [Tên lớp],
                mh.MaMH AS [Mã môn học],
                mh.Tenmonhoc AS [Tên môn học],
                pdd.Ngay AS [Ngày], 
                pdd.Gio_batdau AS [Thời gian bắt đầu], 
                pdd.Gio_ketthuc AS [Thời gian kết thúc],
                pdd.SoLan AS [Lần],
                pdd.Trangthai AS [Trạng thái]
            FROM 
                PHIENDIEMDANH pdd
            JOIN 
                LOP l ON pdd.MaL = l.MaL
            JOIN 
                MONHOC mh ON pdd.MaMH = mh.MaMH
            ORDER BY 
                pdd.Ngay DESC";


            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            LoadDuLieu(sql); // Gọi hàm để tải dữ liệu

            stopwatch.Stop();
            MessageBox.Show($"Thời gian tải dữ liệu: {stopwatch.ElapsedMilliseconds} ms");

            // Làm sạch các trường
            Lamsach();

            // Cập nhật loại dữ liệu
            type = "DiemDanh";

            // Làm mới dữ liệu trên form
            RefreshData_Click(sender, e);
            dgvmenu.Columns["ID"].DisplayIndex = 0; // Cột đầu tiên

        }

        private void btndiemdanh_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Kiểm tra xem mã lớp có được chọn không
                if (!string.IsNullOrEmpty(txtmamon.Text))
                {
                    // Lấy mã lớp và mã môn từ TextBox
                    string maLop = txtmamon.Text;
                    string maMon = txttenmon.Text;

                    // Lấy tên lớp và tên môn từ cơ sở dữ liệu
                    string className = string.Empty;
                    string subjectName = string.Empty;

                    string classQuery = "SELECT TenL FROM LOP WHERE MaL = @MaLop";
                    string subjectQuery = "SELECT Tenmonhoc FROM MONHOC WHERE MaMH = @MaMon";

                    using (SqlConnection conn = new SqlConnection(dbHelper.GetConnection().ConnectionString)) // Sử dụng dbHelper
                    {
                        conn.Open();

                        // Lấy tên lớp
                        using (SqlCommand cmd = new SqlCommand(classQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@MaLop", maLop);
                            className = cmd.ExecuteScalar()?.ToString() ?? string.Empty; // Nếu không tìm thấy thì trả về chuỗi rỗng
                        }

                        // Lấy tên môn
                        using (SqlCommand cmd = new SqlCommand(subjectQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@MaMon", maMon);
                            subjectName = cmd.ExecuteScalar()?.ToString() ?? string.Empty; // Nếu không tìm thấy thì trả về chuỗi rỗng
                        }
                    }

                    // Kiểm tra xem tên lớp và tên môn có hợp lệ không
                    if (string.IsNullOrEmpty(className) || string.IsNullOrEmpty(subjectName))
                    {
                        MessageBox.Show("Tên lớp hoặc tên môn không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Lấy họ đệm và tên giảng viên từ cơ sở dữ liệu
                    string tenGiangVien = string.Empty;
                    string gvQuery = "SELECT Hodem, Ten FROM GV WHERE ID_gv = @IDGV";

                    using (SqlConnection conn = new SqlConnection(dbHelper.GetConnection().ConnectionString))
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand(gvQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@IDGV", thongtingv.MGV); // Lấy ID giảng viên từ struct
                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    string hoDem = reader["Hodem"].ToString();
                                    string ten = reader["Ten"].ToString();
                                    tenGiangVien = $"{hoDem} {ten}";
                                }
                            }
                        }
                    }

                    // Lấy danh sách sinh viên trong lớp
                    string sql = @"
                SELECT SV.MaSV 
                FROM LOPSV
                JOIN SV ON LOPSV.MaSV = SV.MaSV
                WHERE LOPSV.MaL = @MaLop";

                    DataTable dtSinhVien = dbHelper.ExecuteQuery(sql, new SqlParameter[] { new SqlParameter("@MaLop", maLop) });

                    // Gửi thông báo đến từng sinh viên
                    foreach (DataRow row in dtSinhVien.Rows)
                    {
                        string maSV = row["MaSV"].ToString();

                        // Nội dung thông báo điểm danh
                        string noidung = $"Điểm danh cho lớp {className}, môn {subjectName} vào ngày {dtptgthi.Text}, từ {dptthoigianbatdau.Text} đến {dptthoigianketthuc.Text}. Giảng viên: {tenGiangVien}";

                        // Thêm thông báo vào bảng THONGBAO
                        string insertSql = @"
                    INSERT INTO THONGBAO (MaSV, ID_gv, Noidung, Loai) 
                    VALUES (@MaSV, @IDGV, @Noidung, 'Điểm danh')";

                        dbHelper.ExecuteNonQuery(insertSql, new SqlParameter[]
                        {
                    new SqlParameter("@MaSV", maSV),
                    new SqlParameter("@IDGV", thongtingv.MGV), // Sử dụng ID giảng viên
                    new SqlParameter("@Noidung", noidung)
                        });
                    }

                    MessageBox.Show("Thông báo điểm danh đã được gửi đến sinh viên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn lớp và môn học trước khi điểm danh.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        int ID_phien = 0;

        //THAY ĐỔI NỘI DUNG Ở PHẦN NGÂN HÀNG CÂU HỎI
        private void dgvmenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvmenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!isThemMode)
            {
                if (e.RowIndex >= 0 && e.RowIndex < dgvmenu.Rows.Count)
                {
                    // CÂU HỎI
                    if (grbcauhoi.Text == "Danh sách câu hỏi")
                    {
                        txtmach.Text = dgvmenu[0, e.RowIndex].Value?.ToString() ?? "";
                        cmbmon.Text = dgvmenu[1, e.RowIndex].Value?.ToString() ?? "";
                        txtnoidung.Text = dgvmenu[2, e.RowIndex].Value?.ToString() ?? "";
                        cmbdapan.Text = dgvmenu[3, e.RowIndex].Value?.ToString() ?? "";
                        comboBoxChuong.Text = dgvmenu[4, e.RowIndex].Value?.ToString() ?? "";

                        // Chỉ bật nút sửa nếu có dữ liệu
                        btnsua.Enabled = !string.IsNullOrEmpty(txtmach.Text) ||
                                         !string.IsNullOrEmpty(cmbmon.Text) ||
                                         !string.IsNullOrEmpty(txtnoidung.Text) ||
                                         !string.IsNullOrEmpty(cmbdapan.Text) ||
                                         !string.IsNullOrEmpty(comboBoxChuong.Text);
                        btnxoa.Enabled = btnsua.Enabled; // Bật nút xóa nếu nút sửa bật
                    }
                    // MÔN THI
                    else if (grbcauhoi.Text == "Danh sách môn thi")
                    {
                        if (e.RowIndex >= 0 && e.RowIndex < dgvmenu.Rows.Count && dgvmenu.Rows[e.RowIndex].Cells.Count > 0)
                        {
                            txtmamon.Text = dgvmenu[0, e.RowIndex].Value?.ToString() ?? "";
                            txtmamonhoc.Text = dgvmenu[1, e.RowIndex].Value?.ToString() ?? "";
                            txttenmon.Text = dgvmenu[2, e.RowIndex].Value?.ToString() ?? "";
                            txtsocau.Text = dgvmenu[3, e.RowIndex].Value?.ToString() ?? "";
                            txtthoigian.Text = dgvmenu[4, e.RowIndex].Value?.ToString() ?? "";

                            // Lấy giá trị từ DataGridView cho ngày và giờ
                            var cellValue = dgvmenu[5, e.RowIndex].Value?.ToString();
                            if (!string.IsNullOrEmpty(cellValue) && DateTime.TryParse(cellValue, out DateTime tgThi))
                            {
                                dtptgthi.Value = tgThi; // Thiết lập giá trị cho DateTimePicker
                            }

                            // Chỉ bật nút sửa nếu có dữ liệu
                            btnsua.Enabled = !string.IsNullOrEmpty(txtmamon.Text) ||
                                             !string.IsNullOrEmpty(txtmamonhoc.Text) ||
                                             !string.IsNullOrEmpty(txttenmon.Text) ||
                                             !string.IsNullOrEmpty(txtsocau.Text) ||
                                             !string.IsNullOrEmpty(txtthoigian.Text);
                            btnxoa.Enabled = btnsua.Enabled; // Bật nút xóa nếu nút sửa bật
                        }

                    }

                    // SINH VIÊN
                    else if (grbcauhoi.Text == "Danh sách sinh viên")
                    {
                        txtmamon.Text = dgvmenu[0, e.RowIndex].Value?.ToString() ?? "";
                        txttenmon.Text = dgvmenu[1, e.RowIndex].Value?.ToString() ?? "";
                        txtsocau.Text = dgvmenu[2, e.RowIndex].Value?.ToString() ?? "";
                        txtthoigian.Text = dgvmenu[4, e.RowIndex].Value?.ToString() ?? "";
                        dtptgthi.Text = dgvmenu[3, e.RowIndex].Value?.ToString() ?? "";

                        // Ẩn nút btnsua và btnxoa khi chọn danh sách sinh viên
                        btnthem.Enabled = false;
                        btnsua.Enabled = false;
                        btnxoa.Enabled = false;
                    }
                    // ĐIỂM DANH SINH VIÊN
                    else if (grbcauhoi.Text == "Điểm danh sinh viên")
                    {
                        if (e.RowIndex >= 0 && e.RowIndex < dgvmenu.Rows.Count)
                        {
                            // Lấy ID_phien từ dòng đã chọn
                            if (dgvmenu.Rows[e.RowIndex].Cells["ID"].Value != DBNull.Value)
                            {
                                ID_phien = Convert.ToInt32(dgvmenu.Rows[e.RowIndex].Cells["ID"].Value);
                            }

                            // Hiển thị nội dung từ các ô tương ứng
                            txtmamon.Text = dgvmenu[1, e.RowIndex].Value?.ToString() ?? "";  // Tên lớp
                            txttenmon.Text = dgvmenu[3, e.RowIndex].Value?.ToString() ?? "";  // Tên môn
                                                                                              // Lấy giá trị từ DataGridView cho ngày và giờ
                            var cellValue = dgvmenu[5, e.RowIndex].Value?.ToString();
                            if (!string.IsNullOrEmpty(cellValue) && DateTime.TryParse(cellValue, out DateTime tgdiemdanh))
                            {
                                dtptgthi.Value = tgdiemdanh; // Thiết lập giá trị cho DateTimePicker
                            }
                            dptthoigianbatdau.Text = dgvmenu[6, e.RowIndex].Value?.ToString() ?? "";   // Thời gian bắt đầu
                            dptthoigianketthuc.Text = dgvmenu[7, e.RowIndex].Value?.ToString() ?? ""; // Thời gian kết thúc
                            cmbtrangthai.Text = dgvmenu[9, e.RowIndex].Value?.ToString() ?? ""; // Trạng thái

                            // Chỉ bật nút sửa nếu có dữ liệu
                            btnsua.Enabled = !string.IsNullOrEmpty(txtmamon.Text) &&
                                             !string.IsNullOrEmpty(txttenmon.Text) &&
                                             !string.IsNullOrEmpty(dtptgthi.Text) &&
                                             !string.IsNullOrEmpty(dptthoigianbatdau.Text) &&
                                             !string.IsNullOrEmpty(dptthoigianketthuc.Text) &&
                                             !string.IsNullOrEmpty(cmbtrangthai.Text);
                            btnxoa.Enabled = btnsua.Enabled; // Bật nút xóa nếu nút sửa bật
                            btndiemdanh.Enabled = true;
                        }
                    }
                }
            }
            else if (isThemMode)
            {
                btnsua.Enabled = false;
                btnxoa.Enabled = false;
            }
        }


        //TAB PHẢN HỒI
        private void picsphanhoi_Click(object sender, EventArgs e)
        {
            panel5.Visible = true;

            grbtimphanhoi.Text = "Tìm kiếm phản hồi";

            // làm sạch
            Lamsach();

            // Load dữ liệu
            grbphanhoidgv.Text = "Danh sách phản hồi";
            sql = @"SELECT ph.ID_phanhoi AS [ID], sv.MaSV AS [Mã SV], sv.Hodem AS [Họ đệm], sv.Ten AS [Tên], 
               l.TenL AS [Tên lớp], mh.Tenmonhoc, ph.Noidung AS [Nội dung], ph.Ngaytao AS [Ngày tạo], 
               ph.[Trangthai] AS [Trạng thái]
        FROM PHANHOI ph
        JOIN SV sv ON ph.MaSV = sv.MaSV
        JOIN LOPSV lsv ON lsv.MaSV = sv.MaSV
        JOIN LOP l ON l.MaL = lsv.MaL
        JOIN MONHOC mh ON mh.MaL = l.MaL
        ORDER BY ph.ID_phanhoi";


            dbHelper.LoadDuLieu(sql, dgvphanhoi);
            type = "Phanhoi";
            RefreshData_Click(sender, e);

            btndadoc.Visible = false;
            btnchuadoc.Visible = false;

        }

        int ID_phanhoi = 0;
        private void dgv_phanhoi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (grbphanhoidgv.Text == "Danh sách phản hồi")
            {
                // Kiểm tra xem hàng được nhấp có hợp lệ hay không
                if (e.RowIndex >= 0 && e.RowIndex < dgvphanhoi.Rows.Count)
                {
                    // Lấy ID_phien từ dòng đã chọn
                    if (dgvphanhoi.Rows[e.RowIndex].Cells["ID"].Value != DBNull.Value)
                    {
                        ID_phanhoi = Convert.ToInt32(dgvphanhoi.Rows[e.RowIndex].Cells["ID"].Value);
                    }

                    // Hiển thị nội dung từ các ô tương ứng
                    txtmssv_phanhoi.Text = dgvphanhoi[1, e.RowIndex].Value?.ToString() ?? "";  // MSSV
                    txthodem_phanhoi.Text = dgvphanhoi[2, e.RowIndex].Value?.ToString() ?? "";  // Họ đệm
                    txtten_phanhoi.Text = dgvphanhoi[3, e.RowIndex].Value?.ToString() ?? "";   // Tên
                    txtlop_phanhoi.Text = dgvphanhoi[4, e.RowIndex].Value?.ToString() ?? "";   // Lớp
                    txtmon_phanhoi.Text = dgvphanhoi[5, e.RowIndex].Value?.ToString() ?? "";   // Môn
                    txtnoidung_phanhoi.Text = dgvphanhoi[6, e.RowIndex].Value?.ToString() ?? ""; // Nội dung
                    txtngay_phanhoi.Text = dgvphanhoi[7, e.RowIndex].Value?.ToString() ?? ""; // Ngày


                    // Kiểm tra trạng thái của phản hồi
                    string trangthai = dgvphanhoi[7, e.RowIndex].Value?.ToString() ?? ""; // Trạng thái
                    if (trangthai == "Đã đọc")
                    {
                        btnchuadoc.Visible = true;  // Hiện nút "Đánh dấu chưa đọc"
                        btndadoc.Visible = false;    // Ẩn nút "Đánh dấu đã đọc"
                    }
                    else
                    {
                        btnchuadoc.Visible = false;   // Ẩn nút "Đánh dấu chưa đọc"
                        btndadoc.Visible = true;       // Hiện nút "Đánh dấu đã đọc"
                    }

                }
            }
        }


        //NÚT PHẦN PHẢN HỒI
        private void btnchuadoc_Click(object sender, EventArgs e)
        {
            // Cập nhật trạng thái chưa đọc cho phản hồi
            UpdatePhanHoiStatus("Chưa đọc");

        }

        private void btndadoc_Click(object sender, EventArgs e)
        {
            // Cập nhật trạng thái đã đọc cho phản hồi
            UpdatePhanHoiStatus("Đã đọc");

        }

        private void UpdatePhanHoiStatus(string trangthai)
        {
            // Kiểm tra xem ID_phanhoi đã được chọn chưa
            if (ID_phanhoi > 0)
            {
                string sql = "UPDATE PHANHOI SET Trangthai = @Trangthai WHERE ID_phanhoi = @ID_phanhoi";
                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@ID_phanhoi", ID_phanhoi),
            new SqlParameter("@Trangthai", trangthai)
                };

                dbHelper.ExecuteNonQuery(sql, parameters);

                // Tải lại dữ liệu phản hồi
                dbHelper.LoadDuLieu("SELECT * FROM PHANHOI", dgvphanhoi);
                RefreshData_Click(null, null);
                btndadoc.Visible = false;
                btnchuadoc.Visible = false;
                MessageBox.Show("Cập nhật trạng thái thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Vui lòng chọn phản hồi để cập nhật trạng thái!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private bool isThemMode = false;

        // NÚT THÊM
        private void btnthem_Click(object sender, EventArgs e)
        {
            if (dgvmenu.Rows.Count > 0)
            {
                dgvmenu.CurrentCell = dgvmenu[0, dgvmenu.RowCount - 1];
                txtmach.Focus();
                txtmsv.Focus();
            }
            else
            {
                MessageBox.Show("Không có dữ liệu để thêm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Hoặc thực hiện xử lý khác tùy thuộc vào logic ứng dụng của bạn.
            }
            btnxoa.Enabled = false;
            btnsua.Enabled = false;
            btnhuy.Enabled = true;
            btnluu.Enabled = true;
            Chitiet(true);
            Lamsach();
            RefreshData_Click(sender, e);
            isThemMode = true; // Kích hoạt chế độ Thêm
            btnsua.Enabled = false; // Vô hiệu hóa nút Sửa
            btnxoa.Enabled = false; // Vô hiệu hóa nút Xóa
        }

        // NÚT SỬA
        private void btnsua_Click(object sender, EventArgs e)
        {
            btnthem.Enabled = false;
            btnxoa.Enabled = false;
            btnluu.Enabled = true;
            btnhuy.Enabled = true;
            Chitiet(true);
        }



        // NÚT HUỶ
        private void btnhuy_Click(object sender, EventArgs e)
        {
            btnluu.Enabled = false;
            btnhuy.Enabled = false;
            btnxoa.Enabled = false;
            btnsua.Enabled = false;
            Chitiet(false);
            btnthem.Enabled = true;
            // Sau khi lưu dữ liệu thành công
            isThemMode = false; // Tắt chế độ Thêm
        }


        // NÚT LƯU
        private void btnluu_Click(object sender, EventArgs e)
        {
            string ngaythi = dtptgthi.Value.ToString("yyyy-MM-dd HH:mm");
            string ngaydiemdanh = dtptgthi.Value.ToString("yyyy-MM-dd HH:mm");

            // Kiểm tra nếu đang ở chế độ thêm mới
            if (btnthem.Enabled == true)
            {
                try
                {
                    // Kiểm tra dữ liệu nhập cho từng trường hợp
                    if (grbcauhoi.Text == "Danh sách câu hỏi")
                    {
                        if (string.IsNullOrWhiteSpace(txtmach.Text) || string.IsNullOrWhiteSpace(cmbmon.Text) ||
                            string.IsNullOrWhiteSpace(txtnoidung.Text) || string.IsNullOrWhiteSpace(cmbdapan.Text) ||
                            string.IsNullOrWhiteSpace(comboBoxChuong.Text))
                        {
                            MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi lưu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return; // Dừng lại nếu có trường dữ liệu bị thiếu
                        }

                        // Thực hiện thêm câu hỏi
                        string sql = "INSERT INTO CAUHOI VALUES (@MaCH, @MaM, @Noidung, @Dapan, @Chuong)";
                        SqlParameter[] parameters = new SqlParameter[]
                        {
                    new SqlParameter("@MaCH", txtmach.Text),
                    new SqlParameter("@MaM", cmbmon.Text),
                    new SqlParameter("@Noidung", txtnoidung.Text),
                    new SqlParameter("@Dapan", cmbdapan.Text),
                    new SqlParameter("@Chuong", comboBoxChuong.Text)
                        };
                        dbHelper.ExecuteNonQuery(sql, parameters);
                    }
                    else if (grbcauhoi.Text == "Danh sách môn thi")
                    {
                        if (string.IsNullOrWhiteSpace(txtmamon.Text) || string.IsNullOrEmpty(txtmamonhoc.Text) || string.IsNullOrWhiteSpace(txttenmon.Text) ||
                            string.IsNullOrWhiteSpace(txtsocau.Text) || string.IsNullOrWhiteSpace(txtthoigian.Text))
                        {
                            MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi lưu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        // Thực hiện thêm môn thi
                        string sql = "INSERT INTO MONTHI VALUES (@MaM, @MaMH, @TenMon, @Socau, @TGlambai, @Thoigianthi)";
                        SqlParameter[] parameters = new SqlParameter[]
                        {
                    new SqlParameter("@MaM", txtmamon.Text),
                    new SqlParameter("@MaMH", txtmamonhoc.Text),
                    new SqlParameter("@TenMon", txttenmon.Text),
                    new SqlParameter("@Socau", txtsocau.Text),
                    new SqlParameter("@TGlambai", txtthoigian.Text),
                    new SqlParameter("@Thoigianthi", ngaythi)
                        };
                        dbHelper.ExecuteNonQuery(sql, parameters);
                    }
                    else if (grbcauhoi.Text == "Điểm danh sinh viên")
                    {
                        int SoLan = 0;
                        // Tìm ID_phien lớn nhất hiện có cho ngày hôm nay
                        string sqlMaxId = "SELECT ISNULL(MAX(SoLan), 0) FROM PHIENDIEMDANH WHERE CAST(Ngay AS DATE) = CAST(@Ngay AS DATE)";
                        SqlParameter[] maxIdParams = new SqlParameter[]
                        {
                    new SqlParameter("@Ngay", dtptgthi.Value.Date)
                        };

                        // Thực hiện truy vấn để lấy ID lớn nhất
                        object result = dbHelper.ExecuteScalar(sqlMaxId, maxIdParams);
                        int maxId = Convert.ToInt32(result);

                        // Nếu không có ID nào, khởi tạo ID_phien = 1, nếu có thì tăng lên 1
                        SoLan = maxId == 0 ? 1 : maxId + 1;

                        // Kiểm tra nếu có ngày mới, reset về 1
                        if (DateTime.Now.Date > dtptgthi.Value.Date)
                        {
                            SoLan = 1;
                        }

                        if (string.IsNullOrWhiteSpace(txtmamon.Text) || string.IsNullOrWhiteSpace(txttenmon.Text) ||
                            string.IsNullOrWhiteSpace(cmbtrangthai.Text))
                        {
                            MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi lưu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        // Thực hiện thêm phiên điểm danh
                        string sql = "INSERT INTO PHIENDIEMDANH (ID_gv, MaL, MaMH, Ngay, Gio_batdau, Gio_ketthuc, SoLan, Trangthai) VALUES (@ID_gv, @MaL, @MaMH, @Ngay, @Gio_batdau, @Gio_ketthuc, @SoLan, @Trangthai)";

                        SqlParameter[] parameters = new SqlParameter[]
                        {
                    new SqlParameter("@ID_gv", thongtingv.MGV),
                    new SqlParameter("@MaL", txtmamon.Text),
                    new SqlParameter("@MaMH", txttenmon.Text),
                    new SqlParameter("@Ngay", ngaydiemdanh),
                    new SqlParameter("@Gio_batdau", dptthoigianbatdau.Value.TimeOfDay),
                    new SqlParameter("@Gio_ketthuc", dptthoigianketthuc.Value.TimeOfDay),
                    new SqlParameter("SoLan", SoLan),
                    new SqlParameter("@Trangthai", cmbtrangthai.SelectedItem != null ? cmbtrangthai.SelectedItem.ToString() : "Open") // Giá trị mặc định
                        };

                        dbHelper.ExecuteNonQuery(sql, parameters);
                    }

                    // Sau khi thêm thành công, tải lại dữ liệu
                    LoadDuLieu(grbcauhoi.Text == "Danh sách câu hỏi" ? "SELECT * FROM CAUHOI" : grbcauhoi.Text == "Danh sách môn thi" ? "SELECT * FROM MONTHI" : "SELECT * FROM PHIENDIEMDANH");
                    RefreshData_Click(sender, e);
                    isThemMode = false; // Tắt chế độ Thêm
                    MessageBox.Show("Thêm mới thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                isThemMode = false;
            }

            // Kiểm tra nếu đang ở chế độ sửa đổi
            if (btnsua.Enabled == true)
            {
                try
                {
                    if (grbcauhoi.Text == "Danh sách câu hỏi")
                    {
                        // Kiểm tra dữ liệu đầu vào trước khi sửa
                        if (string.IsNullOrWhiteSpace(txtmach.Text) || string.IsNullOrWhiteSpace(cmbmon.Text) ||
                            string.IsNullOrWhiteSpace(txtnoidung.Text) || string.IsNullOrWhiteSpace(cmbdapan.Text) ||
                            string.IsNullOrWhiteSpace(comboBoxChuong.Text))
                        {
                            MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return; // Dừng lại nếu có trường dữ liệu bị thiếu
                        }

                        // Thực hiện sửa câu hỏi
                        string sql = "UPDATE CAUHOI SET MaM = @MaM, Noidung = @Noidung, Dapan = @Dapan, Chuong = @Chuong WHERE MaCH = @MaCH";
                        SqlParameter[] parameters = new SqlParameter[]
                        {
                    new SqlParameter("@MaCH", txtmach.Text),
                    new SqlParameter("@MaM", cmbmon.Text),
                    new SqlParameter("@Noidung", txtnoidung.Text),
                    new SqlParameter("@Dapan", cmbdapan.Text),
                    new SqlParameter("@Chuong", comboBoxChuong.Text)
                        };
                        dbHelper.ExecuteNonQuery(sql, parameters);
                    }
                    else if (grbcauhoi.Text == "Danh sách môn thi")
                    {
                        if (string.IsNullOrWhiteSpace(txtmamon.Text) || string.IsNullOrEmpty(txtmamonhoc.Text) || string.IsNullOrWhiteSpace(txttenmon.Text) ||
                            string.IsNullOrWhiteSpace(txtsocau.Text) || string.IsNullOrWhiteSpace(txtthoigian.Text))
                        {
                            MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        // Thực hiện sửa môn thi
                        string sql = "UPDATE MONTHI SET Tenmon = @TenMon, Socau = @Socau, TGlambai = @TGlambai, Thoigianthi = @Thoigianthi WHERE MaM = @MaM";
                        SqlParameter[] parameters = new SqlParameter[]
                        {
                    new SqlParameter("@MaM", txtmamon.Text),
                    new SqlParameter("@TenMon", txttenmon.Text),
                    new SqlParameter("@Socau", txtsocau.Text),
                    new SqlParameter("@TGlambai", txtthoigian.Text),
                    new SqlParameter("@Thoigianthi", ngaythi)
                        };
                        dbHelper.ExecuteNonQuery(sql, parameters);
                    }
                    else if (grbcauhoi.Text == "Điểm danh sinh viên")
                    {
                        // Kiểm tra dữ liệu đầu vào trước khi sửa
                        if (string.IsNullOrWhiteSpace(txtmamon.Text) || string.IsNullOrWhiteSpace(txttenmon.Text) ||
                            string.IsNullOrWhiteSpace(cmbtrangthai.Text))
                        {
                            MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        // Thực hiện sửa phiên điểm danh
                        string sql = "UPDATE PHIENDIEMDANH SET MaL = @MaL, MaMH = @MaMH, Ngay = @Ngay, Gio_batdau = @Gio_batdau, Gio_ketthuc = @Gio_ketthuc, Trangthai = @Trangthai WHERE ID_phien = @ID_phien";
                        SqlParameter[] parameters = new SqlParameter[]
                        {
                    new SqlParameter("@ID_phien", ID_phien),
                    new SqlParameter("@MaL", txtmamon.Text),
                    new SqlParameter("@MaMH", txttenmon.Text),
                    new SqlParameter("@Ngay", dtptgthi.Value.Date),
                    new SqlParameter("@Gio_batdau", dptthoigianbatdau.Value.TimeOfDay),
                    new SqlParameter("@Gio_ketthuc", dptthoigianketthuc.Value.TimeOfDay),
                    new SqlParameter("@Trangthai", cmbtrangthai.SelectedItem != null ? cmbtrangthai.SelectedItem.ToString() : "Open")
                        };

                        dbHelper.ExecuteNonQuery(sql, parameters);
                    }

                    // Sau khi sửa thành công, tải lại dữ liệu
                    LoadDuLieu(grbcauhoi.Text == "Danh sách câu hỏi" ? "SELECT * FROM CAUHOI" : grbcauhoi.Text == "Danh sách môn thi" ? "SELECT * FROM MONTHI" : "SELECT * FROM PHIENDIEMDANH");
                    RefreshData_Click(sender, e);
                    isThemMode = false;
                    MessageBox.Show("Sửa thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                isThemMode = false;
            }

            // Cập nhật trạng thái các nút
            btnluu.Enabled = false;
            btnhuy.Enabled = false;
            btnxoa.Enabled = false;
            btnsua.Enabled = false;
            Chitiet(false);
            Lamsach();
            btnthem.Enabled = true;
        }

        // Phương thức lấy ID_phien tiếp theo
        private int GetNextSessionId(DateTime today)
        {
            int nextId = 1; // Giá trị mặc định cho ID_phien

            // Truy vấn để lấy ID_phien lớn nhất trong ngày hôm nay
            string sql = "SELECT MAX(ID_phien) FROM PHIENDIEMDANH WHERE CAST(Ngay AS DATE) = @Today";
            SqlParameter[] parameters = new SqlParameter[]
            {
        new SqlParameter("@Today", today.Date)
            };

            object result = dbHelper.ExecuteScalar(sql, parameters);

            if (result != DBNull.Value)
            {
                nextId = Convert.ToInt32(result) + 1; // Cộng thêm 1 vào ID_phien lớn nhất
            }

            return nextId; // Trả về ID_phien tiếp theo
        }

        //NÚT XOÁ
        private void btnxoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Bạn có chắc chắn muốn xóa không ?", "Xóa dữ liệu", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    string sql = "";
                    SqlParameter[] parameters = null; // Khai báo biến để lưu tham số

                    // Chọn câu lệnh SQL dựa vào loại câu hỏi
                    if (grbcauhoi.Text == "Danh sách câu hỏi")
                    {
                        sql = "DELETE FROM CAUHOI WHERE MaCH = @MaCH"; // Câu lệnh xóa câu hỏi
                        parameters = new SqlParameter[] { new SqlParameter("@MaCH", txtmach.Text) }; // Tham số MaCH
                    }
                    else if (grbcauhoi.Text == "Danh sách môn thi")
                    {
                        sql = "DELETE FROM MONTHI WHERE MaM = @MaM"; // Câu lệnh xóa môn thi
                        parameters = new SqlParameter[] { new SqlParameter("@MaM", txtmamon.Text) }; // Tham số MaM
                    }
                    else if (grbcauhoi.Text == "Điểm danh sinh viên")
                    {
                        sql = "DELETE FROM PHIENDIEMDANH WHERE ID_phien = @ID_phien"; // Câu lệnh xóa điểm danh
                        parameters = new SqlParameter[] { new SqlParameter("@ID_phien", ID_phien) }; // Tham số ID_phien
                    }

                    // **THAY ĐỔI NÀY: Gọi phương thức ExecuteNonQuery từ DatabaseHelper**
                    dbHelper = new DatabaseHelper("MSI\\MSSQLSERVER01", "THITRACNGHIEM"); // Khởi tạo lớp DatabaseHelper
                    dbHelper.ExecuteNonQuery(sql, parameters); // Gọi phương thức xóa với câu lệnh và tham số

                    // Tải lại dữ liệu sau khi xóa
                    LoadDuLieu("SELECT * FROM " + (grbcauhoi.Text == "Danh sách câu hỏi" ? "CAUHOI" : grbcauhoi.Text == "Danh sách môn thi" ? "MONTHI" : "PHIENDIEMDANH"));
                    RefreshData_Click(sender, e);
                    MessageBox.Show("Đã Xóa", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information); // Thông báo xóa thành công


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi xóa dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error); // Thông báo lỗi
            }
        }

        // NÚT TAB BÁO CÁO

        private void picbangdiem_Click(object sender, EventArgs e)
        {
            lbl_ID_phien_baocao.Visible = false;
            lbltrangthai_baocao.Visible = false;
            txt_ID_phien_baocao.Visible = false;
            cmbtrangthai_baocao.Visible = false;
            btnluubaocao.Visible = false;
            btnhuybaocao.Visible = false;
            lblngaytimkiembaocao.Visible = false;
            dpttimkiembaocao.Visible = false;
            try
            {
                grbtim.Text = "Bảng điểm";

                string sql = @" SELECT  KETQUA.MaSV AS 'Mã SV', 
                        SV.Hodem AS 'Họ đệm', 
                        SV.Ten AS 'Tên', 
                        LOP.TenL AS 'Tên Lớp', 
                        MONTHI.Tenmon AS 'Tên Môn', 
                        AVG(KETQUA.Diem) AS 'Điểm Trung Bình', 
                        COUNT(KETQUA.LanThi) AS 'Số Lần Thi' 
                    FROM KETQUA 
                    INNER JOIN SV ON KETQUA.MaSV = SV.MaSV 
                    INNER JOIN LOPSV ON KETQUA.MaSV = LOPSV.MaSV 
                    INNER JOIN LOP ON LOPSV.MaL = LOP.MaL 
                    INNER JOIN MONTHI ON KETQUA.MaM = MONTHI.MaM 
                    GROUP BY KETQUA.MaSV, SV.Hodem, SV.Ten, LOP.TenL, MONTHI.Tenmon";


                DataTable dt = dbHelper.ExecuteQuery(sql);
                dgvbc.DataSource = dt;

                //dgvbc.Columns["Tên"].DisplayIndex = 2;
                //dgvbc.Columns["Tên Môn"].DisplayIndex = 3;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }

        private void picbaithi_Click(object sender, EventArgs e)
        {
            lbl_ID_phien_baocao.Visible = false;
            lbltrangthai_baocao.Visible = false;
            txt_ID_phien_baocao.Visible = false;
            cmbtrangthai_baocao.Visible = false;
            btnluubaocao.Visible = false;
            btnhuybaocao.Visible = false;
            lblngaytimkiembaocao.Visible = true;
            dpttimkiembaocao.Visible = true;
            try
            {
                grbtim.Text = "Bài làm";

                string sql = @"SELECT DISTINCT SV.MaSV AS 'Mã SV', 
                      SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                      LOP.TenL AS 'Tên lớp', 
                      MONTHI.Tenmon AS 'Tên môn', 
                      KETQUA.SoCauDung AS 'Số câu đúng', 
                      KETQUA.SoCauSai AS 'Số câu sai', 
                      KETQUA.SoCauKhongLam AS 'Số câu không làm', 
                      KETQUA.Diem AS 'Điểm', 
                      KETQUA.Lanthi AS 'Lần thi', 
                      BAILAM.NgayThi AS 'Ngày thi' 
               FROM KETQUA 
               INNER JOIN SV ON KETQUA.MaSV = SV.MaSV 
               INNER JOIN LOPSV ON SV.MaSV = LOPSV.MaSV 
               INNER JOIN LOP ON LOPSV.MaL = LOP.MaL 
               INNER JOIN CAUHOI ON KETQUA.MaM = CAUHOI.MaM 
               INNER JOIN MONTHI ON CAUHOI.MaM = MONTHI.MaM 
               INNER JOIN BAILAM ON KETQUA.MaSV = BAILAM.MaSV";  // Thêm bảng BAILAM ở đây



                DataTable dt = dbHelper.ExecuteQuery(sql);
                dgvbc.DataSource = dt;

                // Định dạng cột "Ngày thi" để hiển thị ngày và giờ
                dgvbc.Columns["Ngày thi"].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm"; // Định dạng theo ngày/tháng/năm giờ:phút

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }

        private void picsbaocaodiemdanh_Click(object sender, EventArgs e)
        {
            lblngaytimkiembaocao.Visible = true;
            dpttimkiembaocao.Visible = true;
            try
            {
                // Thiết lập tên nút
                grbtim.Text = "Báo cáo điểm danh";

                // Truy vấn SQL để lấy thông tin điểm danh
                string sql = @"
            SELECT 
                PHIENDIEMDANH.ID_phien AS 'ID Phiên', 
                DIEMDANH.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONHOC.Tenmonhoc AS 'Môn học',
                DIEMDANH.Thoigian_xacnhan AS 'Ngày xác nhận', 
                PHIENDIEMDANH.SoLan AS 'Lần',
                DIEMDANH.Trangthai AS 'Trạng thái'
            FROM DIEMDANH
            INNER JOIN PHIENDIEMDANH ON DIEMDANH.ID_phien = PHIENDIEMDANH.ID_phien
            INNER JOIN SV ON DIEMDANH.MaSV = SV.MaSV
            INNER JOIN LOPSV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN LOP ON LOPSV.MaL = LOP.MaL
            INNER JOIN MONHOC ON MONHOC.MaMH = PHIENDIEMDANH.MaMH
            ORDER BY PHIENDIEMDANH.SoLan, DIEMDANH.Thoigian_xacnhan;"; // Sắp xếp theo ID phiên

                // Thực thi truy vấn và lấy dữ liệu
                DataTable dt = dbHelper.ExecuteQuery(sql);

                // Gán DataTable cho DataGridView hoặc xử lý theo nhu cầu
                dgvbc.DataSource = dt; // Giả sử bạn có DataGridView tên dgvData

                dgvbc.Columns["ID Phiên"].DisplayIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message);
            }
        }

        //CHỈNH SỦA BÁO CÁO ĐIỂM DANH
        private void btnsuabaocao_Click(object sender, EventArgs e)
        {
            lbl_ID_phien_baocao.Visible = true;
            lbltrangthai_baocao.Visible = true;
            txt_ID_phien_baocao.Visible = true;
            cmbtrangthai_baocao.Visible = true;
            btnluubaocao.Visible = true;
            btnhuybaocao.Visible = true;


        }

        private void btnluubaocao_Click(object sender, EventArgs e)
        {
            if (grbtim.Text == "Báo cáo điểm danh")
            {
                // Kiểm tra dữ liệu đầu vào trước khi sửa
                if (string.IsNullOrWhiteSpace(txtmsv.Text) ||string.IsNullOrWhiteSpace(txt_ID_phien_baocao.Text) || 
                    string.IsNullOrWhiteSpace(cmbtrangthai_baocao.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Dừng lại nếu có trường dữ liệu bị thiếu
                }

                // Thực hiện sửa câu hỏi
                string sql = "UPDATE DIEMDANH SET Trangthai = @trangthai WHERE MaSV = @MaSV AND ID_phien = @ID_phien";
                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@MaSV", txtmsv.Text),
            new SqlParameter("@ID_phien", txt_ID_phien_baocao.Text),
            new SqlParameter("@trangthai", cmbtrangthai_baocao.Text)
                };

                try
                {
                    dbHelper.ExecuteNonQuery(sql, parameters);
                    MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    btnhuybaocao_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi cập nhật: {ex.Message}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }


        private void btnhuybaocao_Click(object sender, EventArgs e)
        {
            lbl_ID_phien_baocao.Visible = false;
            lbltrangthai_baocao.Visible = false;
            txt_ID_phien_baocao.Visible = false;
            cmbtrangthai_baocao.Visible = false;
            btnluubaocao.Visible = false;
            btnhuybaocao.Visible = false;

            // Nếu cần xóa nội dung các trường, có thể thêm các lệnh sau:
            txtmsv.Clear();
            txt_ID_phien_baocao.Clear();
            cmbtrangthai_baocao.SelectedIndex = -1; // Đặt lại combobox về trạng thái chưa chọn
        }

        //THOÁT
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // đóng form này
            Form f = new frmlogin(); // mở lại form đăng nhập
            f.ShowDialog();
        }

        private void btnexit2_Click(object sender, EventArgs e)
        {
            this.Close(); // đóng form này
            Form f = new frmlogin(); // mở lại form đăng nhập
            f.ShowDialog();
        }

        private void thoátChươngTrìnhToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close(); // đóng form này
            Form f = new frmlogin(); // mở lại form đăng nhập
            f.ShowDialog();
        }

        // NÚT BÁO CÁO
        private void btnbclop_Click(object sender, EventArgs e)
        {
            try
            {
                rptlop rpt = new rptlop();
                string query = @"
            SELECT DISTINCT 
                LOP.MaL, 
                LOP.TenL, 
                SV.MaSV, 
                SV.Hodem, 
                SV.Ten, 
                KETQUA.Diem, 
                KETQUA.Lanthi
            FROM LOP
            INNER JOIN LOPSV ON LOPSV.MaL = LOP.MaL
            INNER JOIN SV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN KETQUA ON KETQUA.MaSV = SV.MaSV
            WHERE LOP.TenL = @TenLop";

                DataTable datarpt = dbHelper.ExecuteQuery(query, new SqlParameter[] { new SqlParameter("@TenLop", txtMalop.Text) });
                rpt.SetDataSource(datarpt);

                rptlopprv rp = new rptlopprv(rpt);
                rp.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }




        private void btnbcmon_Click(object sender, EventArgs e)
        {
            try
            {
                rptmon rpt = new rptmon();
                string query = @" SELECT 
                        MONTHI.MaM,
                        KETQUA.MaSV,
                        SV.Hodem,
                        SV.Ten,
                        LOP.TenL,
                        MONTHI.Tenmon,
                        AVG(KETQUA.Diem) AS Diem, 
                        COUNT(KETQUA.LanThi) AS LanThi
                    FROM KETQUA 
                    INNER JOIN SV ON KETQUA.MaSV = SV.MaSV 
                    INNER JOIN LOPSV ON KETQUA.MaSV = LOPSV.MaSV 
                    INNER JOIN LOP ON LOPSV.MaL = LOP.MaL 
                    INNER JOIN MONTHI ON KETQUA.MaM = MONTHI.MaM 
                    WHERE MONTHI.Tenmon = @TenMon
                    GROUP BY MONTHI.MaM, KETQUA.MaSV, SV.Hodem, SV.Ten, LOP.TenL, MONTHI.Tenmon";

                DataTable datarpt = dbHelper.ExecuteQuery(query, new SqlParameter[] { new SqlParameter("@TenMon", cmbtenmon.Text) });
                rpt.SetDataSource(datarpt);

                rptmonprv rp = new rptmonprv(rpt);
                rp.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }



        private string type;
        private void RefreshData_Click(object sender, EventArgs e)
        {

            var refresh = new Refresh(type, dbHelper);
            refresh.ExecuteRefresh(dgvmenu, dgvphanhoi, type, txtmach, txtmamon,
                           txtnoidung, txtsocau, txttenmon, txtthoigian,
                           txtten_phanhoi, txtmssv_phanhoi, txthodem_phanhoi,
                           txtlop_phanhoi, txtmon_phanhoi, txtnoidung_phanhoi, txtngay_phanhoi,
                           cmbdapan, cmbmon, comboBoxChuong, cmbtrangthai,
                           dtptgthi, dptthoigianbatdau, dptthoigianbatdau);

        }

        private void dtptgthi_ValueChanged(object sender, EventArgs e)
        {
            // Cập nhật giờ cho thời gian bắt đầu
            dptthoigianbatdau.Value = new DateTime(dtptgthi.Value.Year, dtptgthi.Value.Month, dtptgthi.Value.Day, dtptgthi.Value.Hour, dptthoigianbatdau.Value.Minute, 0);

            // Cập nhật giờ cho thời gian kết thúc nếu nó nhỏ hơn thời gian bắt đầu
            if (dptthoigianketthuc.Value <= dptthoigianbatdau.Value)
            {
                dptthoigianketthuc.Value = dptthoigianbatdau.Value.AddMinutes(1); // Đặt lại thời gian kết thúc
            }
        }

        private void dptthoigianbatdau_ValueChanged(object sender, EventArgs e)
        {
            // Cập nhật giờ cho dptthoigianketthuc
            dptthoigianketthuc.Value = new DateTime(dptthoigianbatdau.Value.Year, dptthoigianbatdau.Value.Month, dptthoigianbatdau.Value.Day, dptthoigianketthuc.Value.Hour, dptthoigianketthuc.Value.Minute, 0);

            // Kiểm tra và đảm bảo thời gian kết thúc không nhỏ hơn thời gian bắt đầu
            if (dptthoigianketthuc.Value <= dptthoigianbatdau.Value)
            {
                dptthoigianketthuc.Value = dptthoigianbatdau.Value.AddMinutes(1); // Hoặc bạn có thể đặt một khoảng thời gian khác
            }
        }

        private void dptthoigianketthuc_ValueChanged(object sender, EventArgs e)
        {
            // Kiểm tra và đảm bảo thời gian kết thúc không nhỏ hơn thời gian bắt đầu
            if (dptthoigianketthuc.Value <= dptthoigianbatdau.Value)
            {
                dptthoigianketthuc.Value = dptthoigianbatdau.Value.AddMinutes(1); // Hoặc bạn có thể đặt một khoảng thời gian khác
            }
        }


        // NÚT TÌM KIẾM TAB QUẢN LÝ
        private void txttim_TextChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            string searchText = txttim.Text;
            string loai = grbcauhoi.Text;

            filter.TimKiemTheoLoai(searchText, loai, dgvmenu);
        }


        private void cmbloc_SelectedIndexChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            string tenMon = cmbloc.Text;

            filter.TimKiemTheoMonHoc(tenMon, dgvmenu);
        }

        //NÚT TÌM KIẾM TAB BÁO CÁO

        private void txtmsv_TextChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            string loaiTimKiem = grbtim.Text; // Giả định có thuộc tính để lấy loại tìm kiếm
            string maSV = txtmsv.Text;

            // Gọi phương thức tìm kiếm
            filter.TimKiemMSSVBaoCao(maSV, loaiTimKiem, dgvbc);
        }

        private void cmbtenmon_TextChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            string loaiTimKiem = grbtim.Text; // Giả định có thuộc tính để lấy loại tìm kiếm
            string tenMon = cmbtenmon.Text;

            // Gọi phương thức tìm kiếm
            filter.TimKiemTenMonBaoCao(tenMon, loaiTimKiem, dgvbc);
        }


        private void txtMalop_TextChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            string loaiTimKiem = grbtim.Text; // Giả định có thuộc tính để lấy loại tìm kiếm
            string tenLop = txtMalop.Text;

            // Gọi phương thức tìm kiếm
            filter.TimKiemTenLopBaoCao(tenLop, loaiTimKiem, dgvbc);
        }


        private void dpttimkiembaocao_ValueChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            string ngayBaoCao = dpttimkiembaocao.Value.ToString("yyyy-MM-dd"); // Định dạng ngày nếu cần
            string loaiTimKiem = grbtim.Text; // Giả định có thuộc tính để lấy loại tìm kiếm


            // Gọi phương thức TimKiemNgayBaoCao
            filter.TimKiemNgayBaoCao(ngayBaoCao, loaiTimKiem, dgvbc); // dgvbc là DataGridView bạn muốn gán dữ liệu
        }

        // TÌM KIẾM PHẢN HỒI
        private void txttimkiemmssv_phanhoi_TextChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            filter.TimKiemMSSVPhanHoi(txttimkiemmssv_phanhoi, dgvphanhoi);
        }

        private void txttimkiemlop_phanhoi_TextChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            filter.TimKiemLopPhanHoi(txttimkiemlop_phanhoi, dgvphanhoi);
        }

        private void txttimkiemmon_phanhoi_SelectedIndexChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            filter.TimKiemMonPhanHoi(txttimkiemmon_phanhoi, dgvphanhoi);
        }

        private void dtptimkiem_phanhoi_ValueChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            filter.TimKiemNgayPhanHoi(dtptimkiem_phanhoi, dgvphanhoi);
        }

        // CÁC NÚT Ở PHẦN TRỢ GIÚP
        private void linktimch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Tìm kiếm câu hỏi" + Environment.NewLine + "1.Nhập thông tin tìm kiếm (mã câu hỏi hoặc mã môn) vào ô tìm kiếm " + Environment.NewLine + "2.Thông tin sẽ hiện ra bảng danh sách câu hỏi ở bên dưới" + Environment.NewLine + "3.Chọn tên môn thi tương ứng để lọc các câu hỏi theo từng môn";
        }

        private void linkthemch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Thêm câu hỏi " + Environment.NewLine + "1.Nhấp chuột vào Thêm " + Environment.NewLine + "2.nhập thông tin vào các ô tương ứng " + Environment.NewLine + "3.sau khi nhập đầy đủ thông tin thì nhấp chuột vào Lưu";
        }

        private void linksuach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Sửa câu hỏi " + Environment.NewLine + "1.nhấp vào câu hỏi cần sửa " + Environment.NewLine + "2.thông tin câu hỏi sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Sửa " + Environment.NewLine + "4.sửa thông tin cần thay đổi" + Environment.NewLine + "5.sau khi sửa xong nhấp vào Lưu";

        }

        private void linkxoach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xóa câu hỏi" + Environment.NewLine + "1.nhấp vào câu hỏi cần xóa " + Environment.NewLine + " 2.thông tin câu hỏi sẽ hiện vào ô tương ứng" + Environment.NewLine + " 3.nhấp vào Xóa ";

        }

        private void linktimmt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Tìm kiếm môn thi" + Environment.NewLine + "1.Nhập thông tin tìm kiếm (mã môn hoặc tên môn) vào ô tìm kiếm " + Environment.NewLine + " 2.Thông tin sẽ hiện ra bảng danh sách Môn thi ở bên dưới";

        }

        private void linkthemmt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Thêm môn thi" + Environment.NewLine + "1.Nhấp chuột vào Thêm " + Environment.NewLine + " 2.nhập thông tin vào các ô tương ứng" + Environment.NewLine + " 3.sau khi nhập đầy đủ thông tin thì nhấp chuột vào Lưu";

        }

        private void linksuamt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Sửa môn thi" + Environment.NewLine + "1.nhấp vào môn thi cần sửa" + Environment.NewLine + " 2.thông tin môn thi sẽ hiện vào ô tương ứng" + Environment.NewLine + " 3.nhấp vào Sửa " + Environment.NewLine + "4.sửa thông tin cần thay đổi" + Environment.NewLine + " 5.sau khi sửa xong nhấp vào Lưu";

        }

        private void linkxoamt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xóa môn thi" + Environment.NewLine + "1.nhấp vào môn thi cần xóa" + Environment.NewLine + " 2.thông tin môn thi sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Xóa";

        }

        private void linktimsv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Tìm kiếm sinh viên" + Environment.NewLine + "1.Nhập thông tin tìm kiếm (mã sinh viên hoặc tên sinh viên) vào ô tìm kiếm" + Environment.NewLine + " 2.Thông tin sẽ hiện ra bảng ";

        }

        private void linkthemsv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Thêm sinh viên" + Environment.NewLine + "1.Nhấp chuột vào Thêm" + Environment.NewLine + " 2.nhập thông tin vào các ô tương ứng" + Environment.NewLine + " 3.sau khi nhập đầy đủ thông tin thì nhấp chuột vào Lưu";

        }

        private void linksuasv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Sửa thông tin sinh viên" + Environment.NewLine + "1.nhấp vào sinh viên cần sửa" + Environment.NewLine + " 2.thông tin sinh viên sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Sửa" + Environment.NewLine + " 4.sửa thông tin cần thay đổi" + Environment.NewLine + "5.sau khi sửa xong nhấp vào Lưu";

        }

        private void linkxoasv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Xóa thông tin sinh viên" + Environment.NewLine + "1.nhấp vào sinh viên cần xóa" + Environment.NewLine + " 2.thông tin sinh viên sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Xóa ";

        }

        private void label12_Click(object sender, EventArgs e)
        {
            lbltrogiup.Text = "*Xem bảng điểm " + Environment.NewLine + "1.Nhập tên lớp cần xem bảng điểm." + Environment.NewLine + "2.Chọn tên môn học." + Environment.NewLine + "3.Nhập vào MSV nếu cần xem điểm của 1 sinh viên." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bảng điểm đã chọn.";

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xem bảng điểm " + Environment.NewLine + "1.Nhập tên lớp cần xem bảng điểm." + Environment.NewLine + "2.Chọn tên môn học." + Environment.NewLine + "3.Nhập vào MSV nếu cần xem điểm của 1 sinh viên." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bảng điểm đã chọn.";

        }

        private void label13_Click(object sender, EventArgs e)
        {
            lbltrogiup.Text = "*Xem bài thi " + Environment.NewLine + "1.Nhập MSV." + Environment.NewLine + "2.Chọn tên môn." + Environment.NewLine + "3.Chọn ngày thi." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bài thi của sinh viên đó.";

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xem bài thi " + Environment.NewLine + "1.Nhập MSV." + Environment.NewLine + "2.Chọn tên môn." + Environment.NewLine + "3.Chọn ngày thi." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bài thi của sinh viên đó.";

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        private void txtmach_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbmon_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbtenmon_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbltrogiup_Click(object sender, EventArgs e)
        {

        }

        private void tabtrogiup_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void dgvbc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void grbtim_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panelcauhoi_Paint(object sender, PaintEventArgs e)
        {

        }

        private void grbchitietch_Enter(object sender, EventArgs e)
        {

        }

        private void lblmonthi_Click(object sender, EventArgs e)
        {

        }

        private void txttenmon_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnoidung_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtthoigian_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbdapan_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbldapan_Click(object sender, EventArgs e)
        {

        }

        private void lbltgthi_Click(object sender, EventArgs e)
        {

        }

        private void lblthoigian_Click(object sender, EventArgs e)
        {

        }

        private void txtsocau_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblsocau_Click(object sender, EventArgs e)
        {

        }

        private void lblnoidungch_Click(object sender, EventArgs e)
        {

        }

        private void lbltenmon_Click(object sender, EventArgs e)
        {

        }

        private void txtmamon_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblmach_Click(object sender, EventArgs e)
        {

        }

        private void lblmamon_Click(object sender, EventArgs e)
        {

        }

        private void grbcauhoi_Enter(object sender, EventArgs e)
        {

        }

        private void lblloc_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tHITRACNGHIEMDataSetBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void mONTHIBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxChuong_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabphanhoi_Click(object sender, EventArgs e)
        {

        }

        private void grbphanhoidgv_Enter(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void tabquanly_Click(object sender, EventArgs e)
        {

        }

        private void grbtimch_Enter(object sender, EventArgs e)
        {

        }

        private void cmbtenmon_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void tabbaocao_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void cmbtrangthai_baocao_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}
