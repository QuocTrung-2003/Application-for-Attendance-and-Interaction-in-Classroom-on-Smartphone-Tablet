﻿namespace PMTHITN
{
    partial class frmgv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmgv));
            this.tabtrogiup = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbltrogiup = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.linkthemsv = new System.Windows.Forms.LinkLabel();
            this.linktimmt = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.label13 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label12 = new System.Windows.Forms.Label();
            this.linkxoasv = new System.Windows.Forms.LinkLabel();
            this.linksuasv = new System.Windows.Forms.LinkLabel();
            this.linktimsv = new System.Windows.Forms.LinkLabel();
            this.label11 = new System.Windows.Forms.Label();
            this.linkxoamt = new System.Windows.Forms.LinkLabel();
            this.linksuamt = new System.Windows.Forms.LinkLabel();
            this.linkthemmt = new System.Windows.Forms.LinkLabel();
            this.label10 = new System.Windows.Forms.Label();
            this.linkxoach = new System.Windows.Forms.LinkLabel();
            this.linksuach = new System.Windows.Forms.LinkLabel();
            this.linkthemch = new System.Windows.Forms.LinkLabel();
            this.linktimch = new System.Windows.Forms.LinkLabel();
            this.label9 = new System.Windows.Forms.Label();
            this.tabbaocao = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dgvbc = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.Picsbaocaodiemdanh = new System.Windows.Forms.PictureBox();
            this.grbtim = new System.Windows.Forms.GroupBox();
            this.dpttimkiembaocao = new System.Windows.Forms.DateTimePicker();
            this.lblngaytimkiembaocao = new System.Windows.Forms.Label();
            this.txtMalop = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbtenmon = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtmsv = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.picbaithi = new System.Windows.Forms.PictureBox();
            this.picbangdiem = new System.Windows.Forms.PictureBox();
            this.tabquanly = new System.Windows.Forms.TabPage();
            this.panelcauhoi = new System.Windows.Forms.Panel();
            this.grbchitietch = new System.Windows.Forms.GroupBox();
            this.txtmamonhoc = new System.Windows.Forms.TextBox();
            this.lblmamonhoc = new System.Windows.Forms.Label();
            this.dptthoigianketthuc = new System.Windows.Forms.DateTimePicker();
            this.dptthoigianbatdau = new System.Windows.Forms.DateTimePicker();
            this.lblchuong = new System.Windows.Forms.Label();
            this.comboBoxChuong = new System.Windows.Forms.ComboBox();
            this.lblmonthi = new System.Windows.Forms.Label();
            this.txtmamon = new System.Windows.Forms.TextBox();
            this.txtnoidung = new System.Windows.Forms.TextBox();
            this.txtthoigian = new System.Windows.Forms.TextBox();
            this.cmbdapan = new System.Windows.Forms.ComboBox();
            this.lbldapan = new System.Windows.Forms.Label();
            this.dtptgthi = new System.Windows.Forms.DateTimePicker();
            this.lbltgthi = new System.Windows.Forms.Label();
            this.lblthoigian = new System.Windows.Forms.Label();
            this.txtsocau = new System.Windows.Forms.TextBox();
            this.lblsocau = new System.Windows.Forms.Label();
            this.lblnoidungch = new System.Windows.Forms.Label();
            this.cmbmon = new System.Windows.Forms.ComboBox();
            this.lbltenmon = new System.Windows.Forms.Label();
            this.txtmach = new System.Windows.Forms.TextBox();
            this.lblmach = new System.Windows.Forms.Label();
            this.lblmamon = new System.Windows.Forms.Label();
            this.txttenmon = new System.Windows.Forms.TextBox();
            this.lbltrangthai = new System.Windows.Forms.Label();
            this.cmbtrangthai = new System.Windows.Forms.ComboBox();
            this.grbcauhoi = new System.Windows.Forms.GroupBox();
            this.dgvmenu = new System.Windows.Forms.DataGridView();
            this.grbtimch = new System.Windows.Forms.GroupBox();
            this.cmbloc = new System.Windows.Forms.ComboBox();
            this.lblloc = new System.Windows.Forms.Label();
            this.txttim = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.picsdiemdanh = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picmonthi = new System.Windows.Forms.PictureBox();
            this.picsv = new System.Windows.Forms.PictureBox();
            this.piccauhoi = new System.Windows.Forms.PictureBox();
            this.tHITRACNGHIEMDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tHITRACNGHIEMDataSet = new PMTHITN.THITRACNGHIEMDataSet();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabphanhoi = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.grbphanhoidgv = new System.Windows.Forms.GroupBox();
            this.dgvphanhoi = new System.Windows.Forms.DataGridView();
            this.grbphanhoi = new System.Windows.Forms.GroupBox();
            this.txtmon_phanhoi = new System.Windows.Forms.TextBox();
            this.lblmon_phanhoi = new System.Windows.Forms.Label();
            this.txtngay_phanhoi = new System.Windows.Forms.TextBox();
            this.txtlop_phanhoi = new System.Windows.Forms.TextBox();
            this.txtten_phanhoi = new System.Windows.Forms.TextBox();
            this.txthodem_phanhoi = new System.Windows.Forms.TextBox();
            this.txtmssv_phanhoi = new System.Windows.Forms.TextBox();
            this.txtnoidung_phanhoi = new System.Windows.Forms.RichTextBox();
            this.lblnoidung_phanhoi = new System.Windows.Forms.Label();
            this.lbllop_phanhoi = new System.Windows.Forms.Label();
            this.lblngay_phanhoi = new System.Windows.Forms.Label();
            this.lblten_phanhoi = new System.Windows.Forms.Label();
            this.lblhodem_phanhoi = new System.Windows.Forms.Label();
            this.lblmssv_phahoi = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.grbtimphanhoi = new System.Windows.Forms.GroupBox();
            this.dtptimkiem_phanhoi = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.txttimkiemlop_phanhoi = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txttimkiemmon_phanhoi = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txttimkiemmssv_phanhoi = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.picsphanhoi = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.RefreshData = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mONTHIBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mONTHITableAdapter = new PMTHITN.THITRACNGHIEMDataSetTableAdapters.MONTHITableAdapter();
            this.gvTableAdapter1 = new PMTHITN.THITRACNGHIEMDataSetTableAdapters.GVTableAdapter();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cAUHOIBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cAUHOITableAdapter = new PMTHITN.THITRACNGHIEMDataSetTableAdapters.CAUHOITableAdapter();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.lbltrangthai_baocao = new System.Windows.Forms.Label();
            this.cmbtrangthai_baocao = new System.Windows.Forms.ComboBox();
            this.lbl_ID_phien_baocao = new System.Windows.Forms.Label();
            this.txt_ID_phien_baocao = new System.Windows.Forms.TextBox();
            this.btnthem = new PMTHITN.RJButton();
            this.btnhuy = new PMTHITN.RJButton();
            this.btnsua = new PMTHITN.RJButton();
            this.btnxoa = new PMTHITN.RJButton();
            this.btnluu = new PMTHITN.RJButton();
            this.btnExit = new PMTHITN.RJButton();
            this.btndiemdanh = new PMTHITN.RJButton();
            this.btnhuybaocao = new PMTHITN.RJButton();
            this.btnluubaocao = new PMTHITN.RJButton();
            this.btnsuabaocao = new PMTHITN.RJButton();
            this.btnbclop = new PMTHITN.RJButton();
            this.btnbcmon = new PMTHITN.RJButton();
            this.btndadoc = new PMTHITN.RJButton();
            this.btnchuadoc = new PMTHITN.RJButton();
            this.tabtrogiup.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabbaocao.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbc)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Picsbaocaodiemdanh)).BeginInit();
            this.grbtim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbaithi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbangdiem)).BeginInit();
            this.tabquanly.SuspendLayout();
            this.panelcauhoi.SuspendLayout();
            this.grbchitietch.SuspendLayout();
            this.grbcauhoi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvmenu)).BeginInit();
            this.grbtimch.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsdiemdanh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picmonthi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picsv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccauhoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSet)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabphanhoi.SuspendLayout();
            this.panel5.SuspendLayout();
            this.grbphanhoidgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvphanhoi)).BeginInit();
            this.grbphanhoi.SuspendLayout();
            this.panel4.SuspendLayout();
            this.grbtimphanhoi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsphanhoi)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mONTHIBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAUHOIBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabtrogiup
            // 
            this.tabtrogiup.Controls.Add(this.tableLayoutPanel1);
            this.tabtrogiup.Location = new System.Drawing.Point(4, 38);
            this.tabtrogiup.Margin = new System.Windows.Forms.Padding(4);
            this.tabtrogiup.Name = "tabtrogiup";
            this.tabtrogiup.Size = new System.Drawing.Size(1894, 898);
            this.tabtrogiup.TabIndex = 2;
            this.tabtrogiup.Text = "Trợ giúp";
            this.tabtrogiup.UseVisualStyleBackColor = true;
            this.tabtrogiup.Click += new System.EventHandler(this.tabtrogiup_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.90006F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.09994F));
            this.tableLayoutPanel1.Controls.Add(this.lbltrogiup, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.89163F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 895F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1894, 898);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // lbltrogiup
            // 
            this.lbltrogiup.BackColor = System.Drawing.Color.Gainsboro;
            this.lbltrogiup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbltrogiup.Location = new System.Drawing.Point(535, 3);
            this.lbltrogiup.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltrogiup.Name = "lbltrogiup";
            this.lbltrogiup.Size = new System.Drawing.Size(1352, 892);
            this.lbltrogiup.TabIndex = 1;
            this.lbltrogiup.Click += new System.EventHandler(this.lbltrogiup_Click);
            // 
            // panel3
            // 
            this.panel3.AutoSize = true;
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Controls.Add(this.linkthemsv);
            this.panel3.Controls.Add(this.linktimmt);
            this.panel3.Controls.Add(this.linkLabel3);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.linkLabel2);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.linkxoasv);
            this.panel3.Controls.Add(this.linksuasv);
            this.panel3.Controls.Add(this.linktimsv);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.linkxoamt);
            this.panel3.Controls.Add(this.linksuamt);
            this.panel3.Controls.Add(this.linkthemmt);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.linkxoach);
            this.panel3.Controls.Add(this.linksuach);
            this.panel3.Controls.Add(this.linkthemch);
            this.panel3.Controls.Add(this.linktimch);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(7, 7);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(517, 884);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // linkthemsv
            // 
            this.linkthemsv.AutoSize = true;
            this.linkthemsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkthemsv.LinkColor = System.Drawing.Color.Black;
            this.linkthemsv.Location = new System.Drawing.Point(46, 444);
            this.linkthemsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkthemsv.Name = "linkthemsv";
            this.linkthemsv.Size = new System.Drawing.Size(79, 25);
            this.linkthemsv.TabIndex = 22;
            this.linkthemsv.TabStop = true;
            this.linkthemsv.Text = "2.Thêm";
            this.linkthemsv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkthemsv_LinkClicked);
            // 
            // linktimmt
            // 
            this.linktimmt.AutoSize = true;
            this.linktimmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linktimmt.LinkColor = System.Drawing.Color.Black;
            this.linktimmt.Location = new System.Drawing.Point(45, 208);
            this.linktimmt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linktimmt.Name = "linktimmt";
            this.linktimmt.Size = new System.Drawing.Size(107, 25);
            this.linktimmt.TabIndex = 9;
            this.linktimmt.TabStop = true;
            this.linktimmt.Text = "1.Tìm kiếm";
            this.linktimmt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linktimmt_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.LinkColor = System.Drawing.Color.Black;
            this.linkLabel3.Location = new System.Drawing.Point(45, 718);
            this.linkLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(125, 25);
            this.linkLabel3.TabIndex = 21;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "1.Xem bài thi";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(4, 672);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(263, 29);
            this.label13.TabIndex = 20;
            this.label13.Text = "V. Xem bài thi của SV\r\n";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.LinkColor = System.Drawing.Color.Black;
            this.linkLabel2.Location = new System.Drawing.Point(46, 618);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(165, 25);
            this.linkLabel2.TabIndex = 19;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "1.Xem bảng điểm";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(7, 585);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(234, 29);
            this.label12.TabIndex = 18;
            this.label12.Text = "IV. Xem bảng điểm\r\n";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // linkxoasv
            // 
            this.linkxoasv.AutoSize = true;
            this.linkxoasv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkxoasv.LinkColor = System.Drawing.Color.Black;
            this.linkxoasv.Location = new System.Drawing.Point(50, 535);
            this.linkxoasv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkxoasv.Name = "linkxoasv";
            this.linkxoasv.Size = new System.Drawing.Size(64, 25);
            this.linkxoasv.TabIndex = 17;
            this.linkxoasv.TabStop = true;
            this.linkxoasv.Text = "4.Xóa";
            this.linkxoasv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkxoasv_LinkClicked);
            // 
            // linksuasv
            // 
            this.linksuasv.AutoSize = true;
            this.linksuasv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linksuasv.LinkColor = System.Drawing.Color.Black;
            this.linksuasv.Location = new System.Drawing.Point(50, 490);
            this.linksuasv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linksuasv.Name = "linksuasv";
            this.linksuasv.Size = new System.Drawing.Size(64, 25);
            this.linksuasv.TabIndex = 16;
            this.linksuasv.TabStop = true;
            this.linksuasv.Text = "3.Sửa";
            this.linksuasv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linksuasv_LinkClicked);
            // 
            // linktimsv
            // 
            this.linktimsv.AutoSize = true;
            this.linktimsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linktimsv.LinkColor = System.Drawing.Color.Black;
            this.linktimsv.Location = new System.Drawing.Point(46, 402);
            this.linktimsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linktimsv.Name = "linktimsv";
            this.linktimsv.Size = new System.Drawing.Size(107, 25);
            this.linktimsv.TabIndex = 14;
            this.linktimsv.TabStop = true;
            this.linktimsv.Text = "1.Tìm kiếm";
            this.linktimsv.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linktimsv_LinkClicked);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(7, 368);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(446, 29);
            this.label11.TabIndex = 13;
            this.label11.Text = "III. Quản lý sinh viên (Coming soon...)";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // linkxoamt
            // 
            this.linkxoamt.AutoSize = true;
            this.linkxoamt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkxoamt.LinkColor = System.Drawing.Color.Black;
            this.linkxoamt.Location = new System.Drawing.Point(46, 322);
            this.linkxoamt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkxoamt.Name = "linkxoamt";
            this.linkxoamt.Size = new System.Drawing.Size(64, 25);
            this.linkxoamt.TabIndex = 12;
            this.linkxoamt.TabStop = true;
            this.linkxoamt.Text = "4.Xóa";
            this.linkxoamt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkxoamt_LinkClicked);
            // 
            // linksuamt
            // 
            this.linksuamt.AutoSize = true;
            this.linksuamt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linksuamt.LinkColor = System.Drawing.Color.Black;
            this.linksuamt.Location = new System.Drawing.Point(46, 286);
            this.linksuamt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linksuamt.Name = "linksuamt";
            this.linksuamt.Size = new System.Drawing.Size(64, 25);
            this.linksuamt.TabIndex = 11;
            this.linksuamt.TabStop = true;
            this.linksuamt.Text = "3.Sửa";
            this.linksuamt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linksuamt_LinkClicked);
            // 
            // linkthemmt
            // 
            this.linkthemmt.AutoSize = true;
            this.linkthemmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkthemmt.LinkColor = System.Drawing.Color.Black;
            this.linkthemmt.Location = new System.Drawing.Point(45, 250);
            this.linkthemmt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkthemmt.Name = "linkthemmt";
            this.linkthemmt.Size = new System.Drawing.Size(79, 25);
            this.linkthemmt.TabIndex = 10;
            this.linkthemmt.TabStop = true;
            this.linkthemmt.Text = "2.Thêm";
            this.linkthemmt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkthemmt_LinkClicked);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(7, 174);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(214, 29);
            this.label10.TabIndex = 8;
            this.label10.Text = "II.Quản lý môn thi";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // linkxoach
            // 
            this.linkxoach.AutoSize = true;
            this.linkxoach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkxoach.LinkColor = System.Drawing.Color.Black;
            this.linkxoach.Location = new System.Drawing.Point(45, 138);
            this.linkxoach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkxoach.Name = "linkxoach";
            this.linkxoach.Size = new System.Drawing.Size(64, 25);
            this.linkxoach.TabIndex = 7;
            this.linkxoach.TabStop = true;
            this.linkxoach.Text = "4.Xóa";
            this.linkxoach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkxoach_LinkClicked);
            // 
            // linksuach
            // 
            this.linksuach.AutoSize = true;
            this.linksuach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linksuach.LinkColor = System.Drawing.Color.Black;
            this.linksuach.Location = new System.Drawing.Point(45, 106);
            this.linksuach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linksuach.Name = "linksuach";
            this.linksuach.Size = new System.Drawing.Size(64, 25);
            this.linksuach.TabIndex = 6;
            this.linksuach.TabStop = true;
            this.linksuach.Text = "3.Sửa";
            this.linksuach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linksuach_LinkClicked);
            // 
            // linkthemch
            // 
            this.linkthemch.AutoSize = true;
            this.linkthemch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkthemch.LinkColor = System.Drawing.Color.Black;
            this.linkthemch.Location = new System.Drawing.Point(45, 74);
            this.linkthemch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkthemch.Name = "linkthemch";
            this.linkthemch.Size = new System.Drawing.Size(79, 25);
            this.linkthemch.TabIndex = 5;
            this.linkthemch.TabStop = true;
            this.linkthemch.Text = "2.Thêm";
            this.linkthemch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkthemch_LinkClicked);
            // 
            // linktimch
            // 
            this.linktimch.AutoSize = true;
            this.linktimch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linktimch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.linktimch.LinkColor = System.Drawing.Color.Black;
            this.linktimch.Location = new System.Drawing.Point(46, 39);
            this.linktimch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linktimch.Name = "linktimch";
            this.linktimch.Size = new System.Drawing.Size(107, 25);
            this.linktimch.TabIndex = 4;
            this.linktimch.TabStop = true;
            this.linktimch.Text = "1.Tìm kiếm";
            this.linktimch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linktimch_LinkClicked);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(7, 5);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(244, 29);
            this.label9.TabIndex = 1;
            this.label9.Text = "I.Ngân hàng câu hỏi";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // tabbaocao
            // 
            this.tabbaocao.Controls.Add(this.panel6);
            this.tabbaocao.Controls.Add(this.dgvbc);
            this.tabbaocao.Controls.Add(this.panel2);
            this.tabbaocao.Location = new System.Drawing.Point(4, 38);
            this.tabbaocao.Margin = new System.Windows.Forms.Padding(4);
            this.tabbaocao.Name = "tabbaocao";
            this.tabbaocao.Padding = new System.Windows.Forms.Padding(4);
            this.tabbaocao.Size = new System.Drawing.Size(1894, 898);
            this.tabbaocao.TabIndex = 1;
            this.tabbaocao.Text = "Báo cáo";
            this.tabbaocao.UseVisualStyleBackColor = true;
            this.tabbaocao.Click += new System.EventHandler(this.tabbaocao_Click);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.Color.SkyBlue;
            this.panel6.Controls.Add(this.cmbtrangthai_baocao);
            this.panel6.Controls.Add(this.txt_ID_phien_baocao);
            this.panel6.Controls.Add(this.lbltrangthai_baocao);
            this.panel6.Controls.Add(this.lbl_ID_phien_baocao);
            this.panel6.Controls.Add(this.btnhuybaocao);
            this.panel6.Controls.Add(this.btnluubaocao);
            this.panel6.Controls.Add(this.btnsuabaocao);
            this.panel6.Controls.Add(this.btnbclop);
            this.panel6.Controls.Add(this.btnbcmon);
            this.panel6.Location = new System.Drawing.Point(1651, 132);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(239, 763);
            this.panel6.TabIndex = 3;
            // 
            // dgvbc
            // 
            this.dgvbc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvbc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvbc.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvbc.BackgroundColor = System.Drawing.Color.White;
            this.dgvbc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvbc.Location = new System.Drawing.Point(4, 132);
            this.dgvbc.Margin = new System.Windows.Forms.Padding(4);
            this.dgvbc.Name = "dgvbc";
            this.dgvbc.RowHeadersWidth = 51;
            this.dgvbc.Size = new System.Drawing.Size(1645, 762);
            this.dgvbc.TabIndex = 2;
            this.dgvbc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvbc_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.Picsbaocaodiemdanh);
            this.panel2.Controls.Add(this.grbtim);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.picbaithi);
            this.panel2.Controls.Add(this.picbangdiem);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1886, 128);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(319, 91);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 25);
            this.label15.TabIndex = 7;
            this.label15.Text = "Điểm danh";
            // 
            // Picsbaocaodiemdanh
            // 
            this.Picsbaocaodiemdanh.BackColor = System.Drawing.Color.White;
            this.Picsbaocaodiemdanh.Image = ((System.Drawing.Image)(resources.GetObject("Picsbaocaodiemdanh.Image")));
            this.Picsbaocaodiemdanh.Location = new System.Drawing.Point(324, 11);
            this.Picsbaocaodiemdanh.Margin = new System.Windows.Forms.Padding(4);
            this.Picsbaocaodiemdanh.Name = "Picsbaocaodiemdanh";
            this.Picsbaocaodiemdanh.Size = new System.Drawing.Size(93, 78);
            this.Picsbaocaodiemdanh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Picsbaocaodiemdanh.TabIndex = 6;
            this.Picsbaocaodiemdanh.TabStop = false;
            this.Picsbaocaodiemdanh.Click += new System.EventHandler(this.picsbaocaodiemdanh_Click);
            // 
            // grbtim
            // 
            this.grbtim.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbtim.Controls.Add(this.dpttimkiembaocao);
            this.grbtim.Controls.Add(this.lblngaytimkiembaocao);
            this.grbtim.Controls.Add(this.txtMalop);
            this.grbtim.Controls.Add(this.label8);
            this.grbtim.Controls.Add(this.cmbtenmon);
            this.grbtim.Controls.Add(this.label7);
            this.grbtim.Controls.Add(this.txtmsv);
            this.grbtim.Controls.Add(this.label4);
            this.grbtim.Location = new System.Drawing.Point(482, 9);
            this.grbtim.Margin = new System.Windows.Forms.Padding(4);
            this.grbtim.Name = "grbtim";
            this.grbtim.Padding = new System.Windows.Forms.Padding(4);
            this.grbtim.Size = new System.Drawing.Size(1384, 103);
            this.grbtim.TabIndex = 5;
            this.grbtim.TabStop = false;
            this.grbtim.Text = "Bài làm";
            this.grbtim.Enter += new System.EventHandler(this.grbtim_Enter);
            // 
            // dpttimkiembaocao
            // 
            this.dpttimkiembaocao.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpttimkiembaocao.Location = new System.Drawing.Point(820, 50);
            this.dpttimkiembaocao.Name = "dpttimkiembaocao";
            this.dpttimkiembaocao.Size = new System.Drawing.Size(164, 34);
            this.dpttimkiembaocao.TabIndex = 17;
            this.dpttimkiembaocao.Value = new System.DateTime(2024, 10, 7, 0, 0, 0, 0);
            this.dpttimkiembaocao.ValueChanged += new System.EventHandler(this.dpttimkiembaocao_ValueChanged);
            // 
            // lblngaytimkiembaocao
            // 
            this.lblngaytimkiembaocao.AutoSize = true;
            this.lblngaytimkiembaocao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblngaytimkiembaocao.Location = new System.Drawing.Point(814, 20);
            this.lblngaytimkiembaocao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblngaytimkiembaocao.Name = "lblngaytimkiembaocao";
            this.lblngaytimkiembaocao.Size = new System.Drawing.Size(69, 25);
            this.lblngaytimkiembaocao.TabIndex = 16;
            this.lblngaytimkiembaocao.Text = "Ngày:";
            // 
            // txtMalop
            // 
            this.txtMalop.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMalop.Location = new System.Drawing.Point(529, 56);
            this.txtMalop.Margin = new System.Windows.Forms.Padding(4);
            this.txtMalop.Name = "txtMalop";
            this.txtMalop.Size = new System.Drawing.Size(240, 30);
            this.txtMalop.TabIndex = 13;
            this.txtMalop.TextChanged += new System.EventHandler(this.txtMalop_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(522, 25);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 25);
            this.label8.TabIndex = 12;
            this.label8.Text = "Lớp:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // cmbtenmon
            // 
            this.cmbtenmon.DisplayMember = "Tenmon";
            this.cmbtenmon.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtenmon.FormattingEnabled = true;
            this.cmbtenmon.Items.AddRange(new object[] {
            "Tin Học"});
            this.cmbtenmon.Location = new System.Drawing.Point(350, 57);
            this.cmbtenmon.Margin = new System.Windows.Forms.Padding(4);
            this.cmbtenmon.Name = "cmbtenmon";
            this.cmbtenmon.Size = new System.Drawing.Size(132, 31);
            this.cmbtenmon.TabIndex = 7;
            this.cmbtenmon.ValueMember = "Tenmon";
            this.cmbtenmon.SelectedIndexChanged += new System.EventHandler(this.cmbtenmon_SelectedIndexChanged_1);
            this.cmbtenmon.TextChanged += new System.EventHandler(this.cmbtenmon_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(342, 26);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "Môn:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtmsv
            // 
            this.txtmsv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmsv.Location = new System.Drawing.Point(123, 59);
            this.txtmsv.Margin = new System.Windows.Forms.Padding(4);
            this.txtmsv.Name = "txtmsv";
            this.txtmsv.Size = new System.Drawing.Size(173, 30);
            this.txtmsv.TabIndex = 5;
            this.txtmsv.TextChanged += new System.EventHandler(this.txtmsv_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(119, 26);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Mã SV:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(166, 91);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 42);
            this.label5.TabIndex = 4;
            this.label5.Text = "Bài kiểm tra";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 91);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 45);
            this.label6.TabIndex = 3;
            this.label6.Text = "Bảng điểm";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // picbaithi
            // 
            this.picbaithi.BackColor = System.Drawing.Color.White;
            this.picbaithi.Image = ((System.Drawing.Image)(resources.GetObject("picbaithi.Image")));
            this.picbaithi.Location = new System.Drawing.Point(186, 9);
            this.picbaithi.Margin = new System.Windows.Forms.Padding(4);
            this.picbaithi.Name = "picbaithi";
            this.picbaithi.Size = new System.Drawing.Size(93, 78);
            this.picbaithi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbaithi.TabIndex = 2;
            this.picbaithi.TabStop = false;
            this.picbaithi.Click += new System.EventHandler(this.picbaithi_Click);
            // 
            // picbangdiem
            // 
            this.picbangdiem.BackColor = System.Drawing.Color.White;
            this.picbangdiem.Image = ((System.Drawing.Image)(resources.GetObject("picbangdiem.Image")));
            this.picbangdiem.Location = new System.Drawing.Point(33, 9);
            this.picbangdiem.Margin = new System.Windows.Forms.Padding(4);
            this.picbangdiem.Name = "picbangdiem";
            this.picbangdiem.Size = new System.Drawing.Size(96, 78);
            this.picbangdiem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbangdiem.TabIndex = 0;
            this.picbangdiem.TabStop = false;
            this.picbangdiem.Click += new System.EventHandler(this.picbangdiem_Click);
            // 
            // tabquanly
            // 
            this.tabquanly.BackColor = System.Drawing.Color.White;
            this.tabquanly.Controls.Add(this.panelcauhoi);
            this.tabquanly.Controls.Add(this.panel1);
            this.tabquanly.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabquanly.Location = new System.Drawing.Point(4, 38);
            this.tabquanly.Margin = new System.Windows.Forms.Padding(4);
            this.tabquanly.Name = "tabquanly";
            this.tabquanly.Padding = new System.Windows.Forms.Padding(4);
            this.tabquanly.Size = new System.Drawing.Size(1894, 898);
            this.tabquanly.TabIndex = 0;
            this.tabquanly.Text = "Quản lý";
            this.tabquanly.Click += new System.EventHandler(this.tabquanly_Click);
            // 
            // panelcauhoi
            // 
            this.panelcauhoi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelcauhoi.BackColor = System.Drawing.Color.Transparent;
            this.panelcauhoi.Controls.Add(this.grbchitietch);
            this.panelcauhoi.Controls.Add(this.grbcauhoi);
            this.panelcauhoi.Controls.Add(this.grbtimch);
            this.panelcauhoi.Location = new System.Drawing.Point(4, 125);
            this.panelcauhoi.Margin = new System.Windows.Forms.Padding(4);
            this.panelcauhoi.Name = "panelcauhoi";
            this.panelcauhoi.Size = new System.Drawing.Size(1886, 769);
            this.panelcauhoi.TabIndex = 1;
            this.panelcauhoi.Paint += new System.Windows.Forms.PaintEventHandler(this.panelcauhoi_Paint);
            // 
            // grbchitietch
            // 
            this.grbchitietch.BackColor = System.Drawing.Color.Transparent;
            this.grbchitietch.Controls.Add(this.txtmamonhoc);
            this.grbchitietch.Controls.Add(this.lblmamonhoc);
            this.grbchitietch.Controls.Add(this.btnthem);
            this.grbchitietch.Controls.Add(this.btnhuy);
            this.grbchitietch.Controls.Add(this.btnsua);
            this.grbchitietch.Controls.Add(this.btnxoa);
            this.grbchitietch.Controls.Add(this.btnluu);
            this.grbchitietch.Controls.Add(this.btnExit);
            this.grbchitietch.Controls.Add(this.btndiemdanh);
            this.grbchitietch.Controls.Add(this.dptthoigianketthuc);
            this.grbchitietch.Controls.Add(this.dptthoigianbatdau);
            this.grbchitietch.Controls.Add(this.lblchuong);
            this.grbchitietch.Controls.Add(this.comboBoxChuong);
            this.grbchitietch.Controls.Add(this.lblmonthi);
            this.grbchitietch.Controls.Add(this.txtmamon);
            this.grbchitietch.Controls.Add(this.txtnoidung);
            this.grbchitietch.Controls.Add(this.txtthoigian);
            this.grbchitietch.Controls.Add(this.cmbdapan);
            this.grbchitietch.Controls.Add(this.lbldapan);
            this.grbchitietch.Controls.Add(this.dtptgthi);
            this.grbchitietch.Controls.Add(this.lbltgthi);
            this.grbchitietch.Controls.Add(this.lblthoigian);
            this.grbchitietch.Controls.Add(this.txtsocau);
            this.grbchitietch.Controls.Add(this.lblsocau);
            this.grbchitietch.Controls.Add(this.lblnoidungch);
            this.grbchitietch.Controls.Add(this.cmbmon);
            this.grbchitietch.Controls.Add(this.lbltenmon);
            this.grbchitietch.Controls.Add(this.txtmach);
            this.grbchitietch.Controls.Add(this.lblmach);
            this.grbchitietch.Controls.Add(this.lblmamon);
            this.grbchitietch.Controls.Add(this.txttenmon);
            this.grbchitietch.Controls.Add(this.lbltrangthai);
            this.grbchitietch.Controls.Add(this.cmbtrangthai);
            this.grbchitietch.Dock = System.Windows.Forms.DockStyle.Right;
            this.grbchitietch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbchitietch.Location = new System.Drawing.Point(1064, 0);
            this.grbchitietch.Margin = new System.Windows.Forms.Padding(4);
            this.grbchitietch.Name = "grbchitietch";
            this.grbchitietch.Padding = new System.Windows.Forms.Padding(4);
            this.grbchitietch.Size = new System.Drawing.Size(822, 769);
            this.grbchitietch.TabIndex = 2;
            this.grbchitietch.TabStop = false;
            this.grbchitietch.Text = "Chi tiết";
            this.grbchitietch.Enter += new System.EventHandler(this.grbchitietch_Enter);
            // 
            // txtmamonhoc
            // 
            this.txtmamonhoc.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmamonhoc.Location = new System.Drawing.Point(377, 59);
            this.txtmamonhoc.Name = "txtmamonhoc";
            this.txtmamonhoc.Size = new System.Drawing.Size(112, 30);
            this.txtmamonhoc.TabIndex = 62;
            // 
            // lblmamonhoc
            // 
            this.lblmamonhoc.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmamonhoc.AutoSize = true;
            this.lblmamonhoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmamonhoc.Location = new System.Drawing.Point(63, 59);
            this.lblmamonhoc.Name = "lblmamonhoc";
            this.lblmamonhoc.Size = new System.Drawing.Size(150, 29);
            this.lblmamonhoc.TabIndex = 61;
            this.lblmamonhoc.Text = "Mã môn học:";
            // 
            // dptthoigianketthuc
            // 
            this.dptthoigianketthuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dptthoigianketthuc.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dptthoigianketthuc.Location = new System.Drawing.Point(378, 248);
            this.dptthoigianketthuc.Name = "dptthoigianketthuc";
            this.dptthoigianketthuc.ShowUpDown = true;
            this.dptthoigianketthuc.Size = new System.Drawing.Size(340, 30);
            this.dptthoigianketthuc.TabIndex = 53;
            this.dptthoigianketthuc.ValueChanged += new System.EventHandler(this.dptthoigianketthuc_ValueChanged);
            // 
            // dptthoigianbatdau
            // 
            this.dptthoigianbatdau.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dptthoigianbatdau.CustomFormat = "HH:mm:ss";
            this.dptthoigianbatdau.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dptthoigianbatdau.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dptthoigianbatdau.Location = new System.Drawing.Point(378, 199);
            this.dptthoigianbatdau.Name = "dptthoigianbatdau";
            this.dptthoigianbatdau.ShowUpDown = true;
            this.dptthoigianbatdau.Size = new System.Drawing.Size(339, 30);
            this.dptthoigianbatdau.TabIndex = 52;
            this.dptthoigianbatdau.ValueChanged += new System.EventHandler(this.dptthoigianbatdau_ValueChanged);
            // 
            // lblchuong
            // 
            this.lblchuong.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblchuong.AutoSize = true;
            this.lblchuong.BackColor = System.Drawing.Color.Transparent;
            this.lblchuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchuong.Location = new System.Drawing.Point(62, 247);
            this.lblchuong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblchuong.Name = "lblchuong";
            this.lblchuong.Size = new System.Drawing.Size(103, 29);
            this.lblchuong.TabIndex = 48;
            this.lblchuong.Text = "Chương:";
            // 
            // comboBoxChuong
            // 
            this.comboBoxChuong.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxChuong.FormattingEnabled = true;
            this.comboBoxChuong.Items.AddRange(new object[] {
            "CHỦ ĐỀ A. MÁY TÍNH VÀ XÃ HỘI TRI THỨC",
            "CHỦ ĐỀ C. TỔ CHỨC LƯU TRỮ, TÌM KIẾM VÀ TRAO ĐỔI THÔNG TIN",
            "CHỦ ĐỀ D. ĐẠO ĐỨC, PHÁP LUẬT VÀ VĂN HÓA TRONG MÔI TRƯỜNG SỐ",
            "CHỦ ĐỀ F. GIẢI QUYẾT VẤN ĐỀ VỚI SỰ TRỢ GIÚP CỦA MÁY TÍNH",
            "CHỦ ĐỀ G. HƯỚNG NGHIỆP VỚI TIN HỌC",
            "CHỦ ĐỀ Fcs. GIẢI QUYẾT VẤN ĐỀ VỚI SỰ TRỢ GIÚP CỦA MÁY TÍNH"});
            this.comboBoxChuong.Location = new System.Drawing.Point(204, 247);
            this.comboBoxChuong.Name = "comboBoxChuong";
            this.comboBoxChuong.Size = new System.Drawing.Size(598, 33);
            this.comboBoxChuong.TabIndex = 47;
            this.comboBoxChuong.SelectedIndexChanged += new System.EventHandler(this.comboBoxChuong_SelectedIndexChanged);
            // 
            // lblmonthi
            // 
            this.lblmonthi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmonthi.AutoSize = true;
            this.lblmonthi.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmonthi.Location = new System.Drawing.Point(63, 151);
            this.lblmonthi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmonthi.Name = "lblmonthi";
            this.lblmonthi.Size = new System.Drawing.Size(105, 29);
            this.lblmonthi.TabIndex = 44;
            this.lblmonthi.Text = "Mã môn:";
            this.lblmonthi.Click += new System.EventHandler(this.lblmonthi_Click);
            // 
            // txtmamon
            // 
            this.txtmamon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmamon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmamon.Location = new System.Drawing.Point(379, 104);
            this.txtmamon.Margin = new System.Windows.Forms.Padding(4);
            this.txtmamon.Name = "txtmamon";
            this.txtmamon.Size = new System.Drawing.Size(340, 30);
            this.txtmamon.TabIndex = 1;
            this.txtmamon.TextChanged += new System.EventHandler(this.txtmamon_TextChanged);
            // 
            // txtnoidung
            // 
            this.txtnoidung.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtnoidung.BackColor = System.Drawing.Color.White;
            this.txtnoidung.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoidung.Location = new System.Drawing.Point(66, 332);
            this.txtnoidung.Margin = new System.Windows.Forms.Padding(4);
            this.txtnoidung.Multiline = true;
            this.txtnoidung.Name = "txtnoidung";
            this.txtnoidung.Size = new System.Drawing.Size(748, 206);
            this.txtnoidung.TabIndex = 32;
            this.txtnoidung.TextChanged += new System.EventHandler(this.txtnoidung_TextChanged);
            // 
            // txtthoigian
            // 
            this.txtthoigian.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtthoigian.Enabled = false;
            this.txtthoigian.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtthoigian.Location = new System.Drawing.Point(378, 248);
            this.txtthoigian.Margin = new System.Windows.Forms.Padding(4);
            this.txtthoigian.Name = "txtthoigian";
            this.txtthoigian.Size = new System.Drawing.Size(335, 30);
            this.txtthoigian.TabIndex = 34;
            this.txtthoigian.Text = "(phút)";
            this.txtthoigian.TextChanged += new System.EventHandler(this.txtthoigian_TextChanged);
            // 
            // cmbdapan
            // 
            this.cmbdapan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbdapan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdapan.FormattingEnabled = true;
            this.cmbdapan.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D"});
            this.cmbdapan.Location = new System.Drawing.Point(187, 578);
            this.cmbdapan.Margin = new System.Windows.Forms.Padding(4);
            this.cmbdapan.Name = "cmbdapan";
            this.cmbdapan.Size = new System.Drawing.Size(112, 33);
            this.cmbdapan.TabIndex = 38;
            this.cmbdapan.SelectedIndexChanged += new System.EventHandler(this.cmbdapan_SelectedIndexChanged);
            // 
            // lbldapan
            // 
            this.lbldapan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbldapan.AutoSize = true;
            this.lbldapan.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldapan.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbldapan.Location = new System.Drawing.Point(70, 577);
            this.lbldapan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldapan.Name = "lbldapan";
            this.lbldapan.Size = new System.Drawing.Size(95, 29);
            this.lbldapan.TabIndex = 37;
            this.lbldapan.Text = "Đáp án:";
            this.lbldapan.Click += new System.EventHandler(this.lbldapan_Click);
            // 
            // dtptgthi
            // 
            this.dtptgthi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtptgthi.CustomFormat = "dd/MM/yyyy HH:mm";
            this.dtptgthi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtptgthi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptgthi.Location = new System.Drawing.Point(378, 333);
            this.dtptgthi.Margin = new System.Windows.Forms.Padding(4);
            this.dtptgthi.Name = "dtptgthi";
            this.dtptgthi.Size = new System.Drawing.Size(319, 30);
            this.dtptgthi.TabIndex = 36;
            this.dtptgthi.ValueChanged += new System.EventHandler(this.dtptgthi_ValueChanged);
            // 
            // lbltgthi
            // 
            this.lbltgthi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbltgthi.AutoSize = true;
            this.lbltgthi.BackColor = System.Drawing.Color.Transparent;
            this.lbltgthi.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltgthi.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbltgthi.Location = new System.Drawing.Point(64, 332);
            this.lbltgthi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltgthi.Name = "lbltgthi";
            this.lbltgthi.Size = new System.Drawing.Size(151, 29);
            this.lbltgthi.TabIndex = 35;
            this.lbltgthi.Text = "Thời gian thi:";
            this.lbltgthi.Click += new System.EventHandler(this.lbltgthi_Click);
            // 
            // lblthoigian
            // 
            this.lblthoigian.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblthoigian.AutoSize = true;
            this.lblthoigian.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblthoigian.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblthoigian.Location = new System.Drawing.Point(64, 247);
            this.lblthoigian.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblthoigian.Name = "lblthoigian";
            this.lblthoigian.Size = new System.Drawing.Size(120, 29);
            this.lblthoigian.TabIndex = 33;
            this.lblthoigian.Text = "Thời gian:";
            this.lblthoigian.Click += new System.EventHandler(this.lblthoigian_Click);
            // 
            // txtsocau
            // 
            this.txtsocau.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtsocau.Enabled = false;
            this.txtsocau.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsocau.Location = new System.Drawing.Point(378, 196);
            this.txtsocau.Margin = new System.Windows.Forms.Padding(4);
            this.txtsocau.Name = "txtsocau";
            this.txtsocau.Size = new System.Drawing.Size(340, 33);
            this.txtsocau.TabIndex = 31;
            this.txtsocau.TextChanged += new System.EventHandler(this.txtsocau_TextChanged);
            // 
            // lblsocau
            // 
            this.lblsocau.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblsocau.AutoSize = true;
            this.lblsocau.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsocau.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblsocau.Location = new System.Drawing.Point(62, 197);
            this.lblsocau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsocau.Name = "lblsocau";
            this.lblsocau.Size = new System.Drawing.Size(93, 29);
            this.lblsocau.TabIndex = 30;
            this.lblsocau.Text = "Số câu:";
            this.lblsocau.Click += new System.EventHandler(this.lblsocau_Click);
            // 
            // lblnoidungch
            // 
            this.lblnoidungch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblnoidungch.AutoSize = true;
            this.lblnoidungch.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnoidungch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblnoidungch.Location = new System.Drawing.Point(65, 299);
            this.lblnoidungch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnoidungch.Name = "lblnoidungch";
            this.lblnoidungch.Size = new System.Drawing.Size(200, 29);
            this.lblnoidungch.TabIndex = 9;
            this.lblnoidungch.Text = "Nội dung câu hỏi:";
            this.lblnoidungch.Click += new System.EventHandler(this.lblnoidungch_Click);
            // 
            // cmbmon
            // 
            this.cmbmon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbmon.FormattingEnabled = true;
            this.cmbmon.Items.AddRange(new object[] {
            "Tin"});
            this.cmbmon.Location = new System.Drawing.Point(378, 150);
            this.cmbmon.Margin = new System.Windows.Forms.Padding(4);
            this.cmbmon.Name = "cmbmon";
            this.cmbmon.Size = new System.Drawing.Size(134, 33);
            this.cmbmon.TabIndex = 5;
            this.cmbmon.SelectedIndexChanged += new System.EventHandler(this.cmbmon_SelectedIndexChanged);
            // 
            // lbltenmon
            // 
            this.lbltenmon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbltenmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltenmon.Location = new System.Drawing.Point(62, 149);
            this.lbltenmon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltenmon.Name = "lbltenmon";
            this.lbltenmon.Size = new System.Drawing.Size(167, 52);
            this.lbltenmon.TabIndex = 4;
            this.lbltenmon.Text = "Tên môn:";
            this.lbltenmon.Click += new System.EventHandler(this.lbltenmon_Click);
            // 
            // txtmach
            // 
            this.txtmach.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmach.Location = new System.Drawing.Point(378, 104);
            this.txtmach.Margin = new System.Windows.Forms.Padding(4);
            this.txtmach.Name = "txtmach";
            this.txtmach.Size = new System.Drawing.Size(134, 30);
            this.txtmach.TabIndex = 2;
            this.txtmach.TextChanged += new System.EventHandler(this.txtmach_TextChanged);
            // 
            // lblmach
            // 
            this.lblmach.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmach.AutoSize = true;
            this.lblmach.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmach.Location = new System.Drawing.Point(65, 102);
            this.lblmach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmach.Name = "lblmach";
            this.lblmach.Size = new System.Drawing.Size(135, 29);
            this.lblmach.TabIndex = 0;
            this.lblmach.Text = "Mã câu hỏi:";
            this.lblmach.Click += new System.EventHandler(this.lblmach_Click);
            // 
            // lblmamon
            // 
            this.lblmamon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmamon.AutoSize = true;
            this.lblmamon.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmamon.Location = new System.Drawing.Point(62, 102);
            this.lblmamon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmamon.Name = "lblmamon";
            this.lblmamon.Size = new System.Drawing.Size(136, 29);
            this.lblmamon.TabIndex = 1;
            this.lblmamon.Text = "Mã môn thi:";
            this.lblmamon.Click += new System.EventHandler(this.lblmamon_Click);
            // 
            // txttenmon
            // 
            this.txttenmon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txttenmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttenmon.Location = new System.Drawing.Point(378, 150);
            this.txttenmon.Margin = new System.Windows.Forms.Padding(4);
            this.txttenmon.Name = "txttenmon";
            this.txttenmon.Size = new System.Drawing.Size(340, 30);
            this.txttenmon.TabIndex = 6;
            this.txttenmon.TextChanged += new System.EventHandler(this.txttenmon_TextChanged);
            // 
            // lbltrangthai
            // 
            this.lbltrangthai.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbltrangthai.AutoSize = true;
            this.lbltrangthai.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrangthai.Location = new System.Drawing.Point(64, 384);
            this.lbltrangthai.Name = "lbltrangthai";
            this.lbltrangthai.Size = new System.Drawing.Size(127, 29);
            this.lbltrangthai.TabIndex = 50;
            this.lbltrangthai.Text = "Trạng thái:";
            // 
            // cmbtrangthai
            // 
            this.cmbtrangthai.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbtrangthai.FormattingEnabled = true;
            this.cmbtrangthai.Items.AddRange(new object[] {
            "Mở ",
            "Đóng"});
            this.cmbtrangthai.Location = new System.Drawing.Point(378, 380);
            this.cmbtrangthai.Name = "cmbtrangthai";
            this.cmbtrangthai.Size = new System.Drawing.Size(121, 33);
            this.cmbtrangthai.TabIndex = 49;
            // 
            // grbcauhoi
            // 
            this.grbcauhoi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbcauhoi.Controls.Add(this.dgvmenu);
            this.grbcauhoi.Location = new System.Drawing.Point(14, 102);
            this.grbcauhoi.Margin = new System.Windows.Forms.Padding(4);
            this.grbcauhoi.Name = "grbcauhoi";
            this.grbcauhoi.Padding = new System.Windows.Forms.Padding(4);
            this.grbcauhoi.Size = new System.Drawing.Size(1042, 663);
            this.grbcauhoi.TabIndex = 1;
            this.grbcauhoi.TabStop = false;
            this.grbcauhoi.Text = "Ngân hàng câu hỏi";
            this.grbcauhoi.Enter += new System.EventHandler(this.grbcauhoi_Enter);
            // 
            // dgvmenu
            // 
            this.dgvmenu.AllowUserToDeleteRows = false;
            this.dgvmenu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvmenu.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvmenu.BackgroundColor = System.Drawing.Color.White;
            this.dgvmenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvmenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvmenu.Location = new System.Drawing.Point(4, 31);
            this.dgvmenu.Margin = new System.Windows.Forms.Padding(4);
            this.dgvmenu.Name = "dgvmenu";
            this.dgvmenu.ReadOnly = true;
            this.dgvmenu.RowHeadersWidth = 51;
            this.dgvmenu.Size = new System.Drawing.Size(1034, 628);
            this.dgvmenu.TabIndex = 0;
            this.dgvmenu.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvmenu_CellClick);
            this.dgvmenu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvmenu_CellContentClick);
            // 
            // grbtimch
            // 
            this.grbtimch.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbtimch.Controls.Add(this.cmbloc);
            this.grbtimch.Controls.Add(this.lblloc);
            this.grbtimch.Controls.Add(this.txttim);
            this.grbtimch.Location = new System.Drawing.Point(0, 0);
            this.grbtimch.Margin = new System.Windows.Forms.Padding(4);
            this.grbtimch.Name = "grbtimch";
            this.grbtimch.Padding = new System.Windows.Forms.Padding(4);
            this.grbtimch.Size = new System.Drawing.Size(851, 679);
            this.grbtimch.TabIndex = 0;
            this.grbtimch.TabStop = false;
            this.grbtimch.Text = "Tìm kiếm";
            this.grbtimch.Enter += new System.EventHandler(this.grbtimch_Enter);
            // 
            // cmbloc
            // 
            this.cmbloc.FormattingEnabled = true;
            this.cmbloc.Location = new System.Drawing.Point(546, 30);
            this.cmbloc.Margin = new System.Windows.Forms.Padding(4);
            this.cmbloc.Name = "cmbloc";
            this.cmbloc.Size = new System.Drawing.Size(160, 37);
            this.cmbloc.TabIndex = 2;
            this.cmbloc.SelectedIndexChanged += new System.EventHandler(this.cmbloc_SelectedIndexChanged);
            // 
            // lblloc
            // 
            this.lblloc.AutoSize = true;
            this.lblloc.Location = new System.Drawing.Point(429, 36);
            this.lblloc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblloc.Name = "lblloc";
            this.lblloc.Size = new System.Drawing.Size(111, 29);
            this.lblloc.TabIndex = 1;
            this.lblloc.Text = "Môn học:";
            this.lblloc.Click += new System.EventHandler(this.lblloc_Click);
            // 
            // txttim
            // 
            this.txttim.Location = new System.Drawing.Point(64, 38);
            this.txttim.Margin = new System.Windows.Forms.Padding(4);
            this.txttim.Name = "txttim";
            this.txttim.Size = new System.Drawing.Size(333, 34);
            this.txttim.TabIndex = 0;
            this.txttim.TextChanged += new System.EventHandler(this.txttim_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.picsdiemdanh);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.picmonthi);
            this.panel1.Controls.Add(this.picsv);
            this.panel1.Controls.Add(this.piccauhoi);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1886, 120);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(47, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 25);
            this.label14.TabIndex = 5;
            this.label14.Text = "Điểm danh";
            // 
            // picsdiemdanh
            // 
            this.picsdiemdanh.BackColor = System.Drawing.Color.White;
            this.picsdiemdanh.Image = ((System.Drawing.Image)(resources.GetObject("picsdiemdanh.Image")));
            this.picsdiemdanh.Location = new System.Drawing.Point(54, 12);
            this.picsdiemdanh.Name = "picsdiemdanh";
            this.picsdiemdanh.Size = new System.Drawing.Size(91, 81);
            this.picsdiemdanh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picsdiemdanh.TabIndex = 3;
            this.picsdiemdanh.TabStop = false;
            this.picsdiemdanh.Click += new System.EventHandler(this.picsdiemdanh_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(183, 93);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "Sinh viên";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(441, 93);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "Môn học";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(313, 94);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Câu hỏi";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // picmonthi
            // 
            this.picmonthi.BackColor = System.Drawing.Color.White;
            this.picmonthi.Image = ((System.Drawing.Image)(resources.GetObject("picmonthi.Image")));
            this.picmonthi.Location = new System.Drawing.Point(443, 14);
            this.picmonthi.Margin = new System.Windows.Forms.Padding(4);
            this.picmonthi.Name = "picmonthi";
            this.picmonthi.Size = new System.Drawing.Size(82, 74);
            this.picmonthi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picmonthi.TabIndex = 2;
            this.picmonthi.TabStop = false;
            this.picmonthi.Click += new System.EventHandler(this.picmonthi_Click);
            // 
            // picsv
            // 
            this.picsv.BackColor = System.Drawing.Color.White;
            this.picsv.Image = ((System.Drawing.Image)(resources.GetObject("picsv.Image")));
            this.picsv.Location = new System.Drawing.Point(189, 12);
            this.picsv.Margin = new System.Windows.Forms.Padding(4);
            this.picsv.Name = "picsv";
            this.picsv.Size = new System.Drawing.Size(91, 81);
            this.picsv.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picsv.TabIndex = 1;
            this.picsv.TabStop = false;
            this.picsv.Click += new System.EventHandler(this.picsv_Click);
            // 
            // piccauhoi
            // 
            this.piccauhoi.BackColor = System.Drawing.Color.White;
            this.piccauhoi.Image = ((System.Drawing.Image)(resources.GetObject("piccauhoi.Image")));
            this.piccauhoi.Location = new System.Drawing.Point(318, 14);
            this.piccauhoi.Margin = new System.Windows.Forms.Padding(4);
            this.piccauhoi.Name = "piccauhoi";
            this.piccauhoi.Size = new System.Drawing.Size(82, 76);
            this.piccauhoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.piccauhoi.TabIndex = 0;
            this.piccauhoi.TabStop = false;
            this.piccauhoi.Click += new System.EventHandler(this.piccauhoi_Click);
            // 
            // tHITRACNGHIEMDataSetBindingSource
            // 
            this.tHITRACNGHIEMDataSetBindingSource.DataSource = this.tHITRACNGHIEMDataSet;
            this.tHITRACNGHIEMDataSetBindingSource.Position = 0;
            this.tHITRACNGHIEMDataSetBindingSource.CurrentChanged += new System.EventHandler(this.tHITRACNGHIEMDataSetBindingSource_CurrentChanged);
            // 
            // tHITRACNGHIEMDataSet
            // 
            this.tHITRACNGHIEMDataSet.DataSetName = "THITRACNGHIEMDataSet";
            this.tHITRACNGHIEMDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabquanly);
            this.tabControl1.Controls.Add(this.tabbaocao);
            this.tabControl1.Controls.Add(this.tabphanhoi);
            this.tabControl1.Controls.Add(this.tabtrogiup);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(20, 60);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1902, 940);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabphanhoi
            // 
            this.tabphanhoi.Controls.Add(this.panel5);
            this.tabphanhoi.Controls.Add(this.panel4);
            this.tabphanhoi.Location = new System.Drawing.Point(4, 38);
            this.tabphanhoi.Name = "tabphanhoi";
            this.tabphanhoi.Size = new System.Drawing.Size(1894, 898);
            this.tabphanhoi.TabIndex = 3;
            this.tabphanhoi.Text = "Phản hồi";
            this.tabphanhoi.UseVisualStyleBackColor = true;
            this.tabphanhoi.Click += new System.EventHandler(this.tabphanhoi_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(this.grbphanhoidgv);
            this.panel5.Controls.Add(this.grbphanhoi);
            this.panel5.Location = new System.Drawing.Point(4, 125);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1891, 770);
            this.panel5.TabIndex = 2;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // grbphanhoidgv
            // 
            this.grbphanhoidgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbphanhoidgv.Controls.Add(this.dgvphanhoi);
            this.grbphanhoidgv.Location = new System.Drawing.Point(3, 0);
            this.grbphanhoidgv.Name = "grbphanhoidgv";
            this.grbphanhoidgv.Size = new System.Drawing.Size(945, 764);
            this.grbphanhoidgv.TabIndex = 1;
            this.grbphanhoidgv.TabStop = false;
            this.grbphanhoidgv.Text = "groupBox1";
            this.grbphanhoidgv.Enter += new System.EventHandler(this.grbphanhoidgv_Enter);
            // 
            // dgvphanhoi
            // 
            this.dgvphanhoi.AllowUserToDeleteRows = false;
            this.dgvphanhoi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvphanhoi.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvphanhoi.BackgroundColor = System.Drawing.Color.White;
            this.dgvphanhoi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvphanhoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvphanhoi.Location = new System.Drawing.Point(3, 30);
            this.dgvphanhoi.Margin = new System.Windows.Forms.Padding(4);
            this.dgvphanhoi.Name = "dgvphanhoi";
            this.dgvphanhoi.ReadOnly = true;
            this.dgvphanhoi.RowHeadersWidth = 51;
            this.dgvphanhoi.Size = new System.Drawing.Size(939, 731);
            this.dgvphanhoi.TabIndex = 1;
            this.dgvphanhoi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_phanhoi_CellClick);
            // 
            // grbphanhoi
            // 
            this.grbphanhoi.Controls.Add(this.txtmon_phanhoi);
            this.grbphanhoi.Controls.Add(this.lblmon_phanhoi);
            this.grbphanhoi.Controls.Add(this.btndadoc);
            this.grbphanhoi.Controls.Add(this.btnchuadoc);
            this.grbphanhoi.Controls.Add(this.txtngay_phanhoi);
            this.grbphanhoi.Controls.Add(this.txtlop_phanhoi);
            this.grbphanhoi.Controls.Add(this.txtten_phanhoi);
            this.grbphanhoi.Controls.Add(this.txthodem_phanhoi);
            this.grbphanhoi.Controls.Add(this.txtmssv_phanhoi);
            this.grbphanhoi.Controls.Add(this.txtnoidung_phanhoi);
            this.grbphanhoi.Controls.Add(this.lblnoidung_phanhoi);
            this.grbphanhoi.Controls.Add(this.lbllop_phanhoi);
            this.grbphanhoi.Controls.Add(this.lblngay_phanhoi);
            this.grbphanhoi.Controls.Add(this.lblten_phanhoi);
            this.grbphanhoi.Controls.Add(this.lblhodem_phanhoi);
            this.grbphanhoi.Controls.Add(this.lblmssv_phahoi);
            this.grbphanhoi.Dock = System.Windows.Forms.DockStyle.Right;
            this.grbphanhoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbphanhoi.Location = new System.Drawing.Point(954, 0);
            this.grbphanhoi.Name = "grbphanhoi";
            this.grbphanhoi.Size = new System.Drawing.Size(937, 770);
            this.grbphanhoi.TabIndex = 1;
            this.grbphanhoi.TabStop = false;
            this.grbphanhoi.Text = "Chi tiết thông tin";
            this.grbphanhoi.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtmon_phanhoi
            // 
            this.txtmon_phanhoi.Location = new System.Drawing.Point(282, 273);
            this.txtmon_phanhoi.Name = "txtmon_phanhoi";
            this.txtmon_phanhoi.Size = new System.Drawing.Size(204, 30);
            this.txtmon_phanhoi.TabIndex = 24;
            // 
            // lblmon_phanhoi
            // 
            this.lblmon_phanhoi.AutoSize = true;
            this.lblmon_phanhoi.Location = new System.Drawing.Point(134, 276);
            this.lblmon_phanhoi.Name = "lblmon_phanhoi";
            this.lblmon_phanhoi.Size = new System.Drawing.Size(57, 25);
            this.lblmon_phanhoi.TabIndex = 23;
            this.lblmon_phanhoi.Text = "Môn:";
            // 
            // txtngay_phanhoi
            // 
            this.txtngay_phanhoi.Location = new System.Drawing.Point(282, 324);
            this.txtngay_phanhoi.Name = "txtngay_phanhoi";
            this.txtngay_phanhoi.Size = new System.Drawing.Size(338, 30);
            this.txtngay_phanhoi.TabIndex = 20;
            // 
            // txtlop_phanhoi
            // 
            this.txtlop_phanhoi.Location = new System.Drawing.Point(282, 225);
            this.txtlop_phanhoi.Name = "txtlop_phanhoi";
            this.txtlop_phanhoi.Size = new System.Drawing.Size(204, 30);
            this.txtlop_phanhoi.TabIndex = 11;
            // 
            // txtten_phanhoi
            // 
            this.txtten_phanhoi.Location = new System.Drawing.Point(282, 167);
            this.txtten_phanhoi.Name = "txtten_phanhoi";
            this.txtten_phanhoi.Size = new System.Drawing.Size(204, 30);
            this.txtten_phanhoi.TabIndex = 10;
            // 
            // txthodem_phanhoi
            // 
            this.txthodem_phanhoi.Location = new System.Drawing.Point(282, 106);
            this.txthodem_phanhoi.Name = "txthodem_phanhoi";
            this.txthodem_phanhoi.Size = new System.Drawing.Size(338, 30);
            this.txthodem_phanhoi.TabIndex = 9;
            // 
            // txtmssv_phanhoi
            // 
            this.txtmssv_phanhoi.Location = new System.Drawing.Point(282, 49);
            this.txtmssv_phanhoi.Name = "txtmssv_phanhoi";
            this.txtmssv_phanhoi.Size = new System.Drawing.Size(338, 30);
            this.txtmssv_phanhoi.TabIndex = 8;
            // 
            // txtnoidung_phanhoi
            // 
            this.txtnoidung_phanhoi.BackColor = System.Drawing.Color.White;
            this.txtnoidung_phanhoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoidung_phanhoi.Location = new System.Drawing.Point(139, 426);
            this.txtnoidung_phanhoi.Name = "txtnoidung_phanhoi";
            this.txtnoidung_phanhoi.Size = new System.Drawing.Size(759, 224);
            this.txtnoidung_phanhoi.TabIndex = 7;
            this.txtnoidung_phanhoi.Text = "";
            // 
            // lblnoidung_phanhoi
            // 
            this.lblnoidung_phanhoi.AutoSize = true;
            this.lblnoidung_phanhoi.Location = new System.Drawing.Point(132, 385);
            this.lblnoidung_phanhoi.Name = "lblnoidung_phanhoi";
            this.lblnoidung_phanhoi.Size = new System.Drawing.Size(96, 25);
            this.lblnoidung_phanhoi.TabIndex = 6;
            this.lblnoidung_phanhoi.Text = "Nội dung:";
            // 
            // lbllop_phanhoi
            // 
            this.lbllop_phanhoi.AutoSize = true;
            this.lbllop_phanhoi.Location = new System.Drawing.Point(134, 228);
            this.lbllop_phanhoi.Name = "lbllop_phanhoi";
            this.lbllop_phanhoi.Size = new System.Drawing.Size(51, 25);
            this.lbllop_phanhoi.TabIndex = 5;
            this.lbllop_phanhoi.Text = "Lớp:";
            // 
            // lblngay_phanhoi
            // 
            this.lblngay_phanhoi.AutoSize = true;
            this.lblngay_phanhoi.Location = new System.Drawing.Point(132, 326);
            this.lblngay_phanhoi.Name = "lblngay_phanhoi";
            this.lblngay_phanhoi.Size = new System.Drawing.Size(64, 25);
            this.lblngay_phanhoi.TabIndex = 4;
            this.lblngay_phanhoi.Text = "Ngày:";
            // 
            // lblten_phanhoi
            // 
            this.lblten_phanhoi.AutoSize = true;
            this.lblten_phanhoi.Location = new System.Drawing.Point(132, 172);
            this.lblten_phanhoi.Name = "lblten_phanhoi";
            this.lblten_phanhoi.Size = new System.Drawing.Size(53, 25);
            this.lblten_phanhoi.TabIndex = 2;
            this.lblten_phanhoi.Text = "Tên:";
            // 
            // lblhodem_phanhoi
            // 
            this.lblhodem_phanhoi.AutoSize = true;
            this.lblhodem_phanhoi.Location = new System.Drawing.Point(131, 109);
            this.lblhodem_phanhoi.Name = "lblhodem_phanhoi";
            this.lblhodem_phanhoi.Size = new System.Drawing.Size(86, 25);
            this.lblhodem_phanhoi.TabIndex = 1;
            this.lblhodem_phanhoi.Text = "Họ đệm:";
            // 
            // lblmssv_phahoi
            // 
            this.lblmssv_phahoi.AutoSize = true;
            this.lblmssv_phahoi.Location = new System.Drawing.Point(132, 54);
            this.lblmssv_phahoi.Name = "lblmssv_phahoi";
            this.lblmssv_phahoi.Size = new System.Drawing.Size(77, 25);
            this.lblmssv_phahoi.TabIndex = 0;
            this.lblmssv_phahoi.Text = "MSSV:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Controls.Add(this.grbtimphanhoi);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.picsphanhoi);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1894, 119);
            this.panel4.TabIndex = 0;
            // 
            // grbtimphanhoi
            // 
            this.grbtimphanhoi.Controls.Add(this.dtptimkiem_phanhoi);
            this.grbtimphanhoi.Controls.Add(this.label20);
            this.grbtimphanhoi.Controls.Add(this.txttimkiemlop_phanhoi);
            this.grbtimphanhoi.Controls.Add(this.label17);
            this.grbtimphanhoi.Controls.Add(this.txttimkiemmon_phanhoi);
            this.grbtimphanhoi.Controls.Add(this.label18);
            this.grbtimphanhoi.Controls.Add(this.txttimkiemmssv_phanhoi);
            this.grbtimphanhoi.Controls.Add(this.label19);
            this.grbtimphanhoi.Location = new System.Drawing.Point(208, 4);
            this.grbtimphanhoi.Margin = new System.Windows.Forms.Padding(4);
            this.grbtimphanhoi.Name = "grbtimphanhoi";
            this.grbtimphanhoi.Padding = new System.Windows.Forms.Padding(4);
            this.grbtimphanhoi.Size = new System.Drawing.Size(1040, 103);
            this.grbtimphanhoi.TabIndex = 6;
            this.grbtimphanhoi.TabStop = false;
            this.grbtimphanhoi.Text = "Tìm kiếm";
            // 
            // dtptimkiem_phanhoi
            // 
            this.dtptimkiem_phanhoi.CustomFormat = "";
            this.dtptimkiem_phanhoi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptimkiem_phanhoi.Location = new System.Drawing.Point(782, 47);
            this.dtptimkiem_phanhoi.Name = "dtptimkiem_phanhoi";
            this.dtptimkiem_phanhoi.Size = new System.Drawing.Size(172, 34);
            this.dtptimkiem_phanhoi.TabIndex = 15;
            this.dtptimkiem_phanhoi.Value = new System.DateTime(2024, 10, 5, 13, 47, 10, 0);
            this.dtptimkiem_phanhoi.ValueChanged += new System.EventHandler(this.dtptimkiem_phanhoi_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(690, 52);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 25);
            this.label20.TabIndex = 14;
            this.label20.Text = "Ngày:";
            // 
            // txttimkiemlop_phanhoi
            // 
            this.txttimkiemlop_phanhoi.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttimkiemlop_phanhoi.Location = new System.Drawing.Point(556, 50);
            this.txttimkiemlop_phanhoi.Margin = new System.Windows.Forms.Padding(4);
            this.txttimkiemlop_phanhoi.Name = "txttimkiemlop_phanhoi";
            this.txttimkiemlop_phanhoi.Size = new System.Drawing.Size(107, 30);
            this.txttimkiemlop_phanhoi.TabIndex = 13;
            this.txttimkiemlop_phanhoi.TextChanged += new System.EventHandler(this.txttimkiemlop_phanhoi_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(493, 50);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 25);
            this.label17.TabIndex = 12;
            this.label17.Text = "Lớp:";
            // 
            // txttimkiemmon_phanhoi
            // 
            this.txttimkiemmon_phanhoi.DisplayMember = "Tenmon";
            this.txttimkiemmon_phanhoi.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttimkiemmon_phanhoi.FormattingEnabled = true;
            this.txttimkiemmon_phanhoi.Items.AddRange(new object[] {
            "Tin Học",
            "             "});
            this.txttimkiemmon_phanhoi.Location = new System.Drawing.Point(353, 50);
            this.txttimkiemmon_phanhoi.Margin = new System.Windows.Forms.Padding(4);
            this.txttimkiemmon_phanhoi.Name = "txttimkiemmon_phanhoi";
            this.txttimkiemmon_phanhoi.Size = new System.Drawing.Size(132, 31);
            this.txttimkiemmon_phanhoi.TabIndex = 7;
            this.txttimkiemmon_phanhoi.ValueMember = "Tenmon";
            this.txttimkiemmon_phanhoi.SelectedIndexChanged += new System.EventHandler(this.txttimkiemmon_phanhoi_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(291, 50);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 25);
            this.label18.TabIndex = 6;
            this.label18.Text = "Môn:";
            // 
            // txttimkiemmssv_phanhoi
            // 
            this.txttimkiemmssv_phanhoi.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttimkiemmssv_phanhoi.Location = new System.Drawing.Point(108, 50);
            this.txttimkiemmssv_phanhoi.Margin = new System.Windows.Forms.Padding(4);
            this.txttimkiemmssv_phanhoi.Name = "txttimkiemmssv_phanhoi";
            this.txttimkiemmssv_phanhoi.Size = new System.Drawing.Size(173, 30);
            this.txttimkiemmssv_phanhoi.TabIndex = 5;
            this.txttimkiemmssv_phanhoi.TextChanged += new System.EventHandler(this.txttimkiemmssv_phanhoi_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(18, 50);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 25);
            this.label19.TabIndex = 4;
            this.label19.Text = "Mã SV:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(69, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 25);
            this.label16.TabIndex = 1;
            this.label16.Text = "Phản hồi";
            // 
            // picsphanhoi
            // 
            this.picsphanhoi.BackColor = System.Drawing.Color.White;
            this.picsphanhoi.Image = ((System.Drawing.Image)(resources.GetObject("picsphanhoi.Image")));
            this.picsphanhoi.Location = new System.Drawing.Point(66, 12);
            this.picsphanhoi.Name = "picsphanhoi";
            this.picsphanhoi.Size = new System.Drawing.Size(100, 69);
            this.picsphanhoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picsphanhoi.TabIndex = 0;
            this.picsphanhoi.TabStop = false;
            this.picsphanhoi.Click += new System.EventHandler(this.picsphanhoi_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RefreshData,
            this.ExitToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(128, 52);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // RefreshData
            // 
            this.RefreshData.Name = "RefreshData";
            this.RefreshData.Size = new System.Drawing.Size(127, 24);
            this.RefreshData.Text = "Refresh";
            this.RefreshData.Click += new System.EventHandler(this.RefreshData_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(127, 24);
            this.ExitToolStripMenuItem.Text = "Exit";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.thoátChươngTrìnhToolStripMenuItem_Click);
            // 
            // mONTHIBindingSource
            // 
            this.mONTHIBindingSource.DataSource = this.tHITRACNGHIEMDataSetBindingSource;
            this.mONTHIBindingSource.Position = 0;
            this.mONTHIBindingSource.CurrentChanged += new System.EventHandler(this.mONTHIBindingSource_CurrentChanged);
            // 
            // mONTHITableAdapter
            // 
            this.mONTHITableAdapter.ClearBeforeFill = true;
            // 
            // gvTableAdapter1
            // 
            this.gvTableAdapter1.ClearBeforeFill = true;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(61, 4);
            // 
            // cAUHOIBindingSource
            // 
            this.cAUHOIBindingSource.DataMember = "CAUHOI";
            this.cAUHOIBindingSource.DataSource = this.tHITRACNGHIEMDataSetBindingSource;
            // 
            // cAUHOITableAdapter
            // 
            this.cAUHOITableAdapter.ClearBeforeFill = true;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // lbltrangthai_baocao
            // 
            this.lbltrangthai_baocao.AutoSize = true;
            this.lbltrangthai_baocao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrangthai_baocao.Location = new System.Drawing.Point(53, 323);
            this.lbltrangthai_baocao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltrangthai_baocao.Name = "lbltrangthai_baocao";
            this.lbltrangthai_baocao.Size = new System.Drawing.Size(117, 25);
            this.lbltrangthai_baocao.TabIndex = 18;
            this.lbltrangthai_baocao.Text = "Trạng thái:";
            // 
            // cmbtrangthai_baocao
            // 
            this.cmbtrangthai_baocao.DisplayMember = "Tenmon";
            this.cmbtrangthai_baocao.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtrangthai_baocao.FormattingEnabled = true;
            this.cmbtrangthai_baocao.Items.AddRange(new object[] {
            "Có mặt",
            "Vắng mặt"});
            this.cmbtrangthai_baocao.Location = new System.Drawing.Point(60, 351);
            this.cmbtrangthai_baocao.Margin = new System.Windows.Forms.Padding(4);
            this.cmbtrangthai_baocao.Name = "cmbtrangthai_baocao";
            this.cmbtrangthai_baocao.Size = new System.Drawing.Size(132, 31);
            this.cmbtrangthai_baocao.TabIndex = 19;
            this.cmbtrangthai_baocao.ValueMember = "Tenmon";
            this.cmbtrangthai_baocao.SelectedIndexChanged += new System.EventHandler(this.cmbtrangthai_baocao_SelectedIndexChanged);
            // 
            // lbl_ID_phien_baocao
            // 
            this.lbl_ID_phien_baocao.AutoSize = true;
            this.lbl_ID_phien_baocao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID_phien_baocao.Location = new System.Drawing.Point(47, 241);
            this.lbl_ID_phien_baocao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ID_phien_baocao.Name = "lbl_ID_phien_baocao";
            this.lbl_ID_phien_baocao.Size = new System.Drawing.Size(99, 25);
            this.lbl_ID_phien_baocao.TabIndex = 20;
            this.lbl_ID_phien_baocao.Text = "ID phiên:";
            // 
            // txt_ID_phien_baocao
            // 
            this.txt_ID_phien_baocao.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ID_phien_baocao.Location = new System.Drawing.Point(52, 269);
            this.txt_ID_phien_baocao.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ID_phien_baocao.Name = "txt_ID_phien_baocao";
            this.txt_ID_phien_baocao.Size = new System.Drawing.Size(104, 30);
            this.txt_ID_phien_baocao.TabIndex = 21;
            // 
            // btnthem
            // 
            this.btnthem.BackColor = System.Drawing.Color.White;
            this.btnthem.BackgroundColor = System.Drawing.Color.White;
            this.btnthem.BorderColor = System.Drawing.Color.Black;
            this.btnthem.BorderRadius = 20;
            this.btnthem.BorderSize = 2;
            this.btnthem.FlatAppearance.BorderSize = 0;
            this.btnthem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnthem.ForeColor = System.Drawing.Color.Black;
            this.btnthem.Location = new System.Drawing.Point(70, 667);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(107, 62);
            this.btnthem.TabIndex = 60;
            this.btnthem.Text = "Thêm";
            this.btnthem.TextColor = System.Drawing.Color.Black;
            this.btnthem.UseVisualStyleBackColor = false;
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // btnhuy
            // 
            this.btnhuy.BackColor = System.Drawing.Color.White;
            this.btnhuy.BackgroundColor = System.Drawing.Color.White;
            this.btnhuy.BorderColor = System.Drawing.Color.Black;
            this.btnhuy.BorderRadius = 20;
            this.btnhuy.BorderSize = 2;
            this.btnhuy.FlatAppearance.BorderSize = 0;
            this.btnhuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnhuy.ForeColor = System.Drawing.Color.Black;
            this.btnhuy.Location = new System.Drawing.Point(581, 667);
            this.btnhuy.Name = "btnhuy";
            this.btnhuy.Size = new System.Drawing.Size(107, 62);
            this.btnhuy.TabIndex = 59;
            this.btnhuy.Text = "Hủy";
            this.btnhuy.TextColor = System.Drawing.Color.Black;
            this.btnhuy.UseVisualStyleBackColor = false;
            this.btnhuy.Click += new System.EventHandler(this.btnhuy_Click);
            // 
            // btnsua
            // 
            this.btnsua.BackColor = System.Drawing.Color.White;
            this.btnsua.BackgroundColor = System.Drawing.Color.White;
            this.btnsua.BorderColor = System.Drawing.Color.Black;
            this.btnsua.BorderRadius = 20;
            this.btnsua.BorderSize = 2;
            this.btnsua.FlatAppearance.BorderSize = 0;
            this.btnsua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsua.ForeColor = System.Drawing.Color.Black;
            this.btnsua.Location = new System.Drawing.Point(185, 667);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(107, 62);
            this.btnsua.TabIndex = 58;
            this.btnsua.Text = "Sửa";
            this.btnsua.TextColor = System.Drawing.Color.Black;
            this.btnsua.UseVisualStyleBackColor = false;
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.BackColor = System.Drawing.Color.White;
            this.btnxoa.BackgroundColor = System.Drawing.Color.White;
            this.btnxoa.BorderColor = System.Drawing.Color.Black;
            this.btnxoa.BorderRadius = 20;
            this.btnxoa.BorderSize = 2;
            this.btnxoa.FlatAppearance.BorderSize = 0;
            this.btnxoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnxoa.ForeColor = System.Drawing.Color.Black;
            this.btnxoa.Location = new System.Drawing.Point(301, 667);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(107, 62);
            this.btnxoa.TabIndex = 57;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.TextColor = System.Drawing.Color.Black;
            this.btnxoa.UseVisualStyleBackColor = false;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnluu
            // 
            this.btnluu.BackColor = System.Drawing.Color.White;
            this.btnluu.BackgroundColor = System.Drawing.Color.White;
            this.btnluu.BorderColor = System.Drawing.Color.Black;
            this.btnluu.BorderRadius = 20;
            this.btnluu.BorderSize = 2;
            this.btnluu.FlatAppearance.BorderSize = 0;
            this.btnluu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnluu.ForeColor = System.Drawing.Color.Black;
            this.btnluu.Location = new System.Drawing.Point(468, 667);
            this.btnluu.Name = "btnluu";
            this.btnluu.Size = new System.Drawing.Size(107, 62);
            this.btnluu.TabIndex = 56;
            this.btnluu.Text = "Lưu";
            this.btnluu.TextColor = System.Drawing.Color.Black;
            this.btnluu.UseVisualStyleBackColor = false;
            this.btnluu.Click += new System.EventHandler(this.btnluu_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.BackgroundColor = System.Drawing.Color.White;
            this.btnExit.BorderColor = System.Drawing.Color.Black;
            this.btnExit.BorderRadius = 20;
            this.btnExit.BorderSize = 2;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(695, 667);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(107, 62);
            this.btnExit.TabIndex = 55;
            this.btnExit.Text = "Thoát";
            this.btnExit.TextColor = System.Drawing.Color.Black;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btndiemdanh
            // 
            this.btndiemdanh.BackColor = System.Drawing.Color.White;
            this.btndiemdanh.BackgroundColor = System.Drawing.Color.White;
            this.btndiemdanh.BorderColor = System.Drawing.Color.Black;
            this.btndiemdanh.BorderRadius = 20;
            this.btndiemdanh.BorderSize = 2;
            this.btndiemdanh.FlatAppearance.BorderSize = 0;
            this.btndiemdanh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndiemdanh.ForeColor = System.Drawing.Color.Black;
            this.btndiemdanh.Location = new System.Drawing.Point(330, 587);
            this.btndiemdanh.Name = "btndiemdanh";
            this.btndiemdanh.Size = new System.Drawing.Size(208, 61);
            this.btndiemdanh.TabIndex = 54;
            this.btndiemdanh.Text = "Điểm danh";
            this.btndiemdanh.TextColor = System.Drawing.Color.Black;
            this.btndiemdanh.UseVisualStyleBackColor = false;
            this.btndiemdanh.Click += new System.EventHandler(this.btndiemdanh_Click_1);
            // 
            // btnhuybaocao
            // 
            this.btnhuybaocao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnhuybaocao.BackColor = System.Drawing.Color.Snow;
            this.btnhuybaocao.BackgroundColor = System.Drawing.Color.Snow;
            this.btnhuybaocao.BorderColor = System.Drawing.Color.Black;
            this.btnhuybaocao.BorderRadius = 20;
            this.btnhuybaocao.BorderSize = 2;
            this.btnhuybaocao.FlatAppearance.BorderSize = 0;
            this.btnhuybaocao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnhuybaocao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhuybaocao.ForeColor = System.Drawing.Color.Black;
            this.btnhuybaocao.Location = new System.Drawing.Point(52, 153);
            this.btnhuybaocao.Margin = new System.Windows.Forms.Padding(4);
            this.btnhuybaocao.Name = "btnhuybaocao";
            this.btnhuybaocao.Size = new System.Drawing.Size(140, 50);
            this.btnhuybaocao.TabIndex = 17;
            this.btnhuybaocao.Text = "Hủy";
            this.btnhuybaocao.TextColor = System.Drawing.Color.Black;
            this.btnhuybaocao.UseVisualStyleBackColor = false;
            this.btnhuybaocao.Click += new System.EventHandler(this.btnhuybaocao_Click);
            // 
            // btnluubaocao
            // 
            this.btnluubaocao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnluubaocao.BackColor = System.Drawing.Color.Snow;
            this.btnluubaocao.BackgroundColor = System.Drawing.Color.Snow;
            this.btnluubaocao.BorderColor = System.Drawing.Color.Black;
            this.btnluubaocao.BorderRadius = 20;
            this.btnluubaocao.BorderSize = 2;
            this.btnluubaocao.FlatAppearance.BorderSize = 0;
            this.btnluubaocao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnluubaocao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnluubaocao.ForeColor = System.Drawing.Color.Black;
            this.btnluubaocao.Location = new System.Drawing.Point(52, 95);
            this.btnluubaocao.Margin = new System.Windows.Forms.Padding(4);
            this.btnluubaocao.Name = "btnluubaocao";
            this.btnluubaocao.Size = new System.Drawing.Size(140, 50);
            this.btnluubaocao.TabIndex = 16;
            this.btnluubaocao.Text = "Lưu";
            this.btnluubaocao.TextColor = System.Drawing.Color.Black;
            this.btnluubaocao.UseVisualStyleBackColor = false;
            this.btnluubaocao.Click += new System.EventHandler(this.btnluubaocao_Click);
            // 
            // btnsuabaocao
            // 
            this.btnsuabaocao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnsuabaocao.BackColor = System.Drawing.Color.Snow;
            this.btnsuabaocao.BackgroundColor = System.Drawing.Color.Snow;
            this.btnsuabaocao.BorderColor = System.Drawing.Color.Black;
            this.btnsuabaocao.BorderRadius = 20;
            this.btnsuabaocao.BorderSize = 2;
            this.btnsuabaocao.FlatAppearance.BorderSize = 0;
            this.btnsuabaocao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsuabaocao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsuabaocao.ForeColor = System.Drawing.Color.Black;
            this.btnsuabaocao.Location = new System.Drawing.Point(52, 35);
            this.btnsuabaocao.Margin = new System.Windows.Forms.Padding(4);
            this.btnsuabaocao.Name = "btnsuabaocao";
            this.btnsuabaocao.Size = new System.Drawing.Size(140, 50);
            this.btnsuabaocao.TabIndex = 15;
            this.btnsuabaocao.Text = "Sửa";
            this.btnsuabaocao.TextColor = System.Drawing.Color.Black;
            this.btnsuabaocao.UseVisualStyleBackColor = false;
            this.btnsuabaocao.Click += new System.EventHandler(this.btnsuabaocao_Click);
            // 
            // btnbclop
            // 
            this.btnbclop.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnbclop.BackColor = System.Drawing.Color.Snow;
            this.btnbclop.BackgroundColor = System.Drawing.Color.Snow;
            this.btnbclop.BorderColor = System.Drawing.Color.Black;
            this.btnbclop.BorderRadius = 20;
            this.btnbclop.BorderSize = 2;
            this.btnbclop.FlatAppearance.BorderSize = 0;
            this.btnbclop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbclop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbclop.ForeColor = System.Drawing.Color.Black;
            this.btnbclop.Location = new System.Drawing.Point(19, 532);
            this.btnbclop.Margin = new System.Windows.Forms.Padding(4);
            this.btnbclop.Name = "btnbclop";
            this.btnbclop.Size = new System.Drawing.Size(200, 50);
            this.btnbclop.TabIndex = 10;
            this.btnbclop.Text = "Báo cáo theo lớp";
            this.btnbclop.TextColor = System.Drawing.Color.Black;
            this.btnbclop.UseVisualStyleBackColor = false;
            this.btnbclop.Click += new System.EventHandler(this.btnbclop_Click);
            // 
            // btnbcmon
            // 
            this.btnbcmon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnbcmon.BackColor = System.Drawing.Color.Snow;
            this.btnbcmon.BackgroundColor = System.Drawing.Color.Snow;
            this.btnbcmon.BorderColor = System.Drawing.Color.Black;
            this.btnbcmon.BorderRadius = 20;
            this.btnbcmon.BorderSize = 2;
            this.btnbcmon.FlatAppearance.BorderSize = 0;
            this.btnbcmon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbcmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbcmon.ForeColor = System.Drawing.Color.Black;
            this.btnbcmon.Location = new System.Drawing.Point(19, 618);
            this.btnbcmon.Margin = new System.Windows.Forms.Padding(4);
            this.btnbcmon.Name = "btnbcmon";
            this.btnbcmon.Size = new System.Drawing.Size(205, 50);
            this.btnbcmon.TabIndex = 14;
            this.btnbcmon.Text = "Báo cáo theo môn";
            this.btnbcmon.TextColor = System.Drawing.Color.Black;
            this.btnbcmon.UseVisualStyleBackColor = false;
            this.btnbcmon.Click += new System.EventHandler(this.btnbcmon_Click);
            // 
            // btndadoc
            // 
            this.btndadoc.BackColor = System.Drawing.Color.White;
            this.btndadoc.BackgroundColor = System.Drawing.Color.White;
            this.btndadoc.BorderColor = System.Drawing.Color.Black;
            this.btndadoc.BorderRadius = 20;
            this.btndadoc.BorderSize = 2;
            this.btndadoc.FlatAppearance.BorderSize = 0;
            this.btndadoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndadoc.ForeColor = System.Drawing.Color.Black;
            this.btndadoc.Location = new System.Drawing.Point(434, 671);
            this.btndadoc.Name = "btndadoc";
            this.btndadoc.Size = new System.Drawing.Size(208, 68);
            this.btndadoc.TabIndex = 22;
            this.btndadoc.Text = "Đánh dấu đã đọc";
            this.btndadoc.TextColor = System.Drawing.Color.Black;
            this.btndadoc.UseVisualStyleBackColor = false;
            this.btndadoc.Click += new System.EventHandler(this.btndadoc_Click);
            // 
            // btnchuadoc
            // 
            this.btnchuadoc.BackColor = System.Drawing.Color.White;
            this.btnchuadoc.BackgroundColor = System.Drawing.Color.White;
            this.btnchuadoc.BorderColor = System.Drawing.Color.Black;
            this.btnchuadoc.BorderRadius = 20;
            this.btnchuadoc.BorderSize = 2;
            this.btnchuadoc.FlatAppearance.BorderSize = 0;
            this.btnchuadoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnchuadoc.ForeColor = System.Drawing.Color.Black;
            this.btnchuadoc.Location = new System.Drawing.Point(421, 671);
            this.btnchuadoc.Name = "btnchuadoc";
            this.btnchuadoc.Size = new System.Drawing.Size(233, 69);
            this.btnchuadoc.TabIndex = 21;
            this.btnchuadoc.Text = "Đánh dấu chưa đọc";
            this.btnchuadoc.TextColor = System.Drawing.Color.Black;
            this.btnchuadoc.UseVisualStyleBackColor = false;
            this.btnchuadoc.Click += new System.EventHandler(this.btnchuadoc_Click);
            // 
            // frmgv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1942, 1020);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmgv";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmgv_Load);
            this.tabtrogiup.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabbaocao.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbc)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Picsbaocaodiemdanh)).EndInit();
            this.grbtim.ResumeLayout(false);
            this.grbtim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbaithi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbangdiem)).EndInit();
            this.tabquanly.ResumeLayout(false);
            this.panelcauhoi.ResumeLayout(false);
            this.grbchitietch.ResumeLayout(false);
            this.grbchitietch.PerformLayout();
            this.grbcauhoi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvmenu)).EndInit();
            this.grbtimch.ResumeLayout(false);
            this.grbtimch.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsdiemdanh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picmonthi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picsv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccauhoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tHITRACNGHIEMDataSet)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabphanhoi.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.grbphanhoidgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvphanhoi)).EndInit();
            this.grbphanhoi.ResumeLayout(false);
            this.grbphanhoi.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.grbtimphanhoi.ResumeLayout(false);
            this.grbtimphanhoi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsphanhoi)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mONTHIBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAUHOIBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabtrogiup;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel linkthemsv;
        private System.Windows.Forms.LinkLabel linktimmt;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.LinkLabel linkxoasv;
        private System.Windows.Forms.LinkLabel linksuasv;
        private System.Windows.Forms.LinkLabel linktimsv;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.LinkLabel linkxoamt;
        private System.Windows.Forms.LinkLabel linksuamt;
        private System.Windows.Forms.LinkLabel linkthemmt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.LinkLabel linkxoach;
        private System.Windows.Forms.LinkLabel linksuach;
        private System.Windows.Forms.LinkLabel linkthemch;
        private System.Windows.Forms.LinkLabel linktimch;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbltrogiup;
        private System.Windows.Forms.TabPage tabbaocao;
        private System.Windows.Forms.DataGridView dgvbc;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox grbtim;
        private System.Windows.Forms.ComboBox cmbtenmon;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtmsv;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox picbaithi;
        private System.Windows.Forms.PictureBox picbangdiem;
        private System.Windows.Forms.TabPage tabquanly;
        private System.Windows.Forms.Panel panelcauhoi;
        private System.Windows.Forms.GroupBox grbchitietch;
        private System.Windows.Forms.Label lblmonthi;
        private System.Windows.Forms.TextBox txtnoidung;
        private System.Windows.Forms.TextBox txtthoigian;
        private System.Windows.Forms.ComboBox cmbdapan;
        private System.Windows.Forms.Label lbldapan;
        private System.Windows.Forms.DateTimePicker dtptgthi;
        private System.Windows.Forms.Label lbltgthi;
        private System.Windows.Forms.Label lblthoigian;
        private System.Windows.Forms.TextBox txtsocau;
        private System.Windows.Forms.Label lblsocau;
        private System.Windows.Forms.Label lblnoidungch;
        private System.Windows.Forms.TextBox txttenmon;
        private System.Windows.Forms.ComboBox cmbmon;
        private System.Windows.Forms.Label lbltenmon;
        private System.Windows.Forms.TextBox txtmach;
        private System.Windows.Forms.TextBox txtmamon;
        private System.Windows.Forms.Label lblmamon;
        private System.Windows.Forms.Label lblmach;
        private System.Windows.Forms.GroupBox grbcauhoi;
        private System.Windows.Forms.DataGridView dgvmenu;
        private System.Windows.Forms.GroupBox grbtimch;
        private System.Windows.Forms.ComboBox cmbloc;
        private System.Windows.Forms.Label lblloc;
        private System.Windows.Forms.TextBox txttim;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picmonthi;
        private System.Windows.Forms.PictureBox picsv;
        private System.Windows.Forms.PictureBox piccauhoi;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMalop;
        private System.Windows.Forms.BindingSource tHITRACNGHIEMDataSetBindingSource;
        private THITRACNGHIEMDataSet tHITRACNGHIEMDataSet;
        private System.Windows.Forms.BindingSource mONTHIBindingSource;
        private THITRACNGHIEMDataSetTableAdapters.MONTHITableAdapter mONTHITableAdapter;
        private System.Windows.Forms.TabControl tabControl1;
        private THITRACNGHIEMDataSetTableAdapters.GVTableAdapter gvTableAdapter1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.BindingSource cAUHOIBindingSource;
        private THITRACNGHIEMDataSetTableAdapters.CAUHOITableAdapter cAUHOITableAdapter;
        private System.Windows.Forms.Label lblchuong;
        private System.Windows.Forms.ComboBox comboBoxChuong;
        private System.Windows.Forms.PictureBox picsdiemdanh;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.TabPage tabphanhoi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox Picsbaocaodiemdanh;
        private System.Windows.Forms.Label lbltrangthai;
        private System.Windows.Forms.ComboBox cmbtrangthai;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox grbphanhoi;
        private System.Windows.Forms.Label lblnoidung_phanhoi;
        private System.Windows.Forms.Label lbllop_phanhoi;
        private System.Windows.Forms.Label lblngay_phanhoi;
        private System.Windows.Forms.Label lblten_phanhoi;
        private System.Windows.Forms.Label lblhodem_phanhoi;
        private System.Windows.Forms.Label lblmssv_phahoi;
        private System.Windows.Forms.TextBox txtlop_phanhoi;
        private System.Windows.Forms.TextBox txtten_phanhoi;
        private System.Windows.Forms.TextBox txthodem_phanhoi;
        private System.Windows.Forms.TextBox txtmssv_phanhoi;
        private System.Windows.Forms.RichTextBox txtnoidung_phanhoi;
        private System.Windows.Forms.DateTimePicker dptthoigianketthuc;
        private System.Windows.Forms.DateTimePicker dptthoigianbatdau;
        private System.Windows.Forms.ToolStripMenuItem RefreshData;
        private RJButton btndiemdanh;
        private RJButton btnExit;
        private RJButton btnhuy;
        private RJButton btnsua;
        private RJButton btnxoa;
        private RJButton btnluu;
        private RJButton btnthem;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox picsphanhoi;
        private System.Windows.Forms.GroupBox grbtimphanhoi;
        private System.Windows.Forms.TextBox txttimkiemlop_phanhoi;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox txttimkiemmon_phanhoi;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txttimkiemmssv_phanhoi;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtngay_phanhoi;
        private System.Windows.Forms.DateTimePicker dtptimkiem_phanhoi;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox grbphanhoidgv;
        private System.Windows.Forms.DataGridView dgvphanhoi;
        private RJButton btndadoc;
        private RJButton btnchuadoc;
        private System.Windows.Forms.TextBox txtmamonhoc;
        private System.Windows.Forms.Label lblmamonhoc;
        private System.Windows.Forms.DateTimePicker dpttimkiembaocao;
        private System.Windows.Forms.Label lblngaytimkiembaocao;
        private System.Windows.Forms.TextBox txtmon_phanhoi;
        private System.Windows.Forms.Label lblmon_phanhoi;
        private System.Windows.Forms.Panel panel6;
        private RJButton btnbcmon;
        private RJButton btnbclop;
        private RJButton btnsuabaocao;
        private RJButton btnhuybaocao;
        private RJButton btnluubaocao;
        private System.Windows.Forms.Label lbltrangthai_baocao;
        private System.Windows.Forms.ComboBox cmbtrangthai_baocao;
        private System.Windows.Forms.Label lbl_ID_phien_baocao;
        private System.Windows.Forms.TextBox txt_ID_phien_baocao;
    }
}