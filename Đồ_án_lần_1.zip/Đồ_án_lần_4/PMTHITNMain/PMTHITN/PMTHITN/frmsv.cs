﻿using PMTHITN.Class;
using PMTHITN.Data;
using PMTHITN.frmgvcontrol;
using PMTHITN.frmsvcontrol;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace PMTHITN
{
    public partial class frmsv : MetroFramework.Forms.MetroForm
    {
        SqlConnection conn = new SqlConnection();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand cmd = new SqlCommand();
        DataTable dt = new DataTable();
        SqlCommand lenh = new SqlCommand();
        string sql;
        private DatabaseHelper dbHelper;
        private Timer timer; // Định kỳ kiểm tra thông báo mới
        private Thongbao thongbao; // Class kiểm tra thông báo mới
        public frmsv()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper("MSI\\MSSQLSERVER01", "THITRACNGHIEM");

            // Khởi tạo class Thongbao và sử dụng NotifyIcon có sẵn trong form
            thongbao = new Thongbao(dbHelper, notifyIcon1);

            // Khởi tạo Timer
            timer = new Timer();
            timer.Interval = 10000; // 10 giây
            timer.Tick += Timer_Tick; // Gán sự kiện Tick cho Timer
            timer.Start(); // Bắt đầu chạy Timer
        }

        private void frmsv_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = dbHelper.GetConnection())
            {
                // Thực hiện các thao tác cần thiết với cơ sở dữ liệu nếu cần
            }

            Hidebtnsv hideControl = new Hidebtnsv();
            hideControl.SetControlVisibilityAndEnablementsv(
                panelcauhoi,
                panel5,
                txtmaphien, txttenlopsv, txttenmonsv, txtngaytaophien, txtsolan, txttrangthai,
                txtmssv_phanhoisv, txthodem_phanhoisv, txtten_phanhoisv, txtlop_phanhoisv,
                txtmon_phanhoisv, txtnoidung_phanhoisv, txtngay_phanhoisv, txtnoidunggui_phanhoi,
                btnthem_phanhoi, btngui_phanhoi, btnhuy_phanhoi, btnxacnhan, btnlambai
            );
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Kiểm tra thông báo mới nhất và hiển thị nếu có
            thongbao.KiemTraThongBaoMoi(thongtinsv.MSV);
        }

        // Cấu hình NotifyIcon cho frmsv
        private void InitializeNotifyIcon()
        {
            notifyIcon1.Visible = true;
            notifyIcon1.Icon = SystemIcons.Information; // Đặt biểu tượng cho NotifyIcon
            notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
            notifyIcon1.BalloonTipTitle = "Thông báo từ hệ thống";
        }

        // Sự kiện khi người dùng click vào thông báo
        private void NotifyIcon1_BalloonTipClicked(object sender, EventArgs e)
        {
            // Thực hiện các hành động khi người dùng nhấp vào thông báo nếu cần
        }





        //private void frmsv_Shown(object sender, EventArgs e)
        //{
        //     string maSV = thongtinsv.MSV; // Lấy mã sinh viên từ struct thongtinsv

        //    if (string.IsNullOrEmpty(maSV))
        //    {
        //        MessageBox.Show("Mã sinh viên không có sẵn. Vui lòng đăng nhập lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //        return; // Không tiếp tục nếu mã sinh viên không có
        //    }

        //    thongbao.LoadNotifications(maSV, notifyIcon1); // Gọi LoadNotifications sau khi form được hiển thị
        //}
        private void LoadDuLieuforsv(string sql)
        {
            dbHelper.LoadDuLieuforsv(sql, dgvdiemdanhsv);
            dbHelper.LoadDuLieuforsv(sql, dgvphanhoisv);

        }

        private void Chitiet(bool a)
        {
            Control[] controls = { txtmaphien, txttenlopsv, txttenmonsv, txtngaytaophien, txtsolan, txttrangthai, txtmssv_phanhoisv, txthodem_phanhoisv, txtten_phanhoisv, txtlop_phanhoisv, txtngay_phanhoisv, txtnoidung_phanhoisv, txtnoidunggui_phanhoi };
            dbHelper.Chitiet(a, controls);
        }

        private void Lamsach()
        {
            Control[] controls = { txtmaphien, txttenlopsv, txttenmonsv, txtngaytaophien, txtsolan, txttrangthai, txtmssv_phanhoisv, txthodem_phanhoisv, txtten_phanhoisv, txtlop_phanhoisv, txtngay_phanhoisv, txtnoidung_phanhoisv, txtnoidunggui_phanhoi };
            dbHelper.Lamsach(controls);
        }


        //PHẦN CÂU HỎI CỦA QUẢN LÝ
        private void CapNhatTrangThaiNut(bool them, bool luu, bool huy, bool xacnhan, bool lambai)
        {
            Hidebtnsv hidebnt = new Hidebtnsv();

            // Ví dụ cập nhật trạng thái của các nút
            hidebnt.CapNhatTrangThaiNut_Class(them, luu, huy, xacnhan, lambai,
                btnthem_phanhoi, btngui_phanhoi, btnhuy_phanhoi, btnxacnhan, btnlambai);
        }



        private void piccauhoi_Click(object sender, EventArgs e)
        {

            // Câu hỏi
            panelcauhoi.Visible = true;
            lbltenlop.Visible = true;
            lbltenmon.Visible = true;
            lblmaphien.Visible = true;
            txttenlopsv.Visible = true;
            txttenmonsv.Visible = true;
            txtmaphien.Visible = true;
            lblngaytaophien.Visible = true;
            btnxacnhan.Visible = true;

            btnlambai.Visible = false;

            //// Làm sạch
            //Lamsach();

            // Datagridview
            grbdiemdanh.Text = "Phiên điểm danh";
            sql = @" SELECT 
            pdd.ID_phien AS[ID],
            gv.Hodem AS[Họ đệm giảng viên],
            gv.Ten AS[Tên giảng viên],
            l.TenL AS[Tên lớp],
            mh.Tenmonhoc AS [Tên môn học],
            pdd.Ngay AS [Ngày], 
            pdd.Gio_batdau AS [Thời gian bắt đầu], 
            pdd.Gio_ketthuc AS [Thời gian kết thúc],
            pdd.SoLan AS [Lần],
            pdd.Trangthai AS [Trạng thái]
        FROM 
            PHIENDIEMDANH pdd
        JOIN
            GV gv ON pdd.ID_gv = gv.ID_gv
        JOIN 
            LOP l ON pdd.MaL = l.MaL
        JOIN 
            MONHOC mh ON pdd.MaMH = mh.MaMH
        ORDER BY 
            pdd.Ngay DESC";

            LoadDuLieuforsv(sql); ;
            type = "DiemDanhsv";
            RefreshDatasv_Click(sender, e);

        }

        private void picmonthi_Click(object sender, EventArgs e)
        {
            // Môn thi
            panelcauhoi.Visible = true;
            lblmaphien.Visible = true;
            lbltenlop.Visible = true;
            lbltenmon.Visible = true;
            lblngaytaophien.Visible = true;
            txtmaphien.Visible = true;
            txttenlopsv.Visible = true;
            txttenmonsv.Visible = true;
            txtngaytaophien.Visible = true;
            btnlambai.Visible = true;

            lblsolan.Visible = false;
            txtsolan.Visible = false;
            lbltrangthai.Visible = false;
            txttrangthai.Visible = false;
            btnxacnhan.Visible = false;



            // Đổi tên lbl
            lblmaphien.Text = "Mã môn:";
            lbltenlop.Text = "Tên môn:";
            lbltenmon.Text = "Thời gian thi:";
            lblngaytaophien.Text = "Số câu:";


            // Datagridview
            grbdiemdanh.Text = "Danh sách môn thi";
            sql = @"
            SELECT 
                MaM AS 'Mã Môn', 
                Tenmon AS 'Tên Môn', 
                Socau AS 'Số Câu', 
                TGlambai AS 'Thời Gian Làm Bài', 
                Thoigianthi AS 'Ngày Thi' 
            FROM 
                MONTHI";

            LoadDuLieuforsv(sql);
            type = "MonThi";
            RefreshDatasv_Click(sender, e);
        }
        private void btnxacnhan_Click(object sender, EventArgs e)
        {
            string maSV = thongtinsv.MSV; // Lấy mã sinh viên từ struct
            int idPhien;

            // Kiểm tra và lấy ID_phien từ TextBox
            if (int.TryParse(txtmaphien.Text, out idPhien))
            {
                // Kiểm tra trạng thái của phiên
                string checkSessionQuery = "SELECT TrangThai FROM PHIENDIEMDANH WHERE ID_phien = @ID_phien";
                SqlParameter[] checkSessionParameters = new SqlParameter[]
                {
            new SqlParameter("@ID_phien", idPhien)
                };

                string sessionStatus = dbHelper.ExecuteScalar(checkSessionQuery, checkSessionParameters)?.ToString();

                // Nếu trạng thái là "Đóng", không cho phép điểm danh
                if (sessionStatus == "Đóng")
                {
                    MessageBox.Show("Phiên điểm danh đã bị đóng! Không thể xác nhận.");
                    return; // Ngừng thực hiện nếu phiên đã đóng
                }

                // Kiểm tra trạng thái xác nhận
                string checkQuery = "SELECT COUNT(*) FROM DIEMDANH WHERE MaSV = @MaSV AND ID_phien = @ID_phien AND IsConfirmed = 1";

                SqlParameter[] checkParameters = new SqlParameter[]
                {
            new SqlParameter("@MaSV", maSV),
            new SqlParameter("@ID_phien", idPhien)
                };

                int confirmedCount = (int)dbHelper.ExecuteScalar(checkQuery, checkParameters);

                if (confirmedCount > 0)
                {
                    MessageBox.Show("Phiên điểm danh đã được xác nhận trước đó!");
                    return; // Ngừng thực hiện nếu đã xác nhận
                }

                // Câu lệnh SQL để chèn trạng thái mới
                string insertQuery = "INSERT INTO DIEMDANH (MaSV, ID_phien, Trangthai, Thoigian_xacnhan, IsConfirmed) VALUES (@MaSV, @ID_phien, 'Có mặt', GETDATE(), 1)";

                // Khởi tạo tham số
                SqlParameter[] insertParameters = new SqlParameter[]
                {
            new SqlParameter("@MaSV", maSV),
            new SqlParameter("@ID_phien", idPhien)
                };

                // Gọi phương thức ExecuteNonQuery từ DatabaseHelper
                try
                {
                    dbHelper.ExecuteNonQuery(insertQuery, insertParameters);
                    MessageBox.Show("Thêm trạng thái thành công!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi thêm trạng thái: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("ID phiên không hợp lệ!");
            }

        }

        private void btnlambai_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ẩn form hiện tại

            // Tạo instance của form mới
            frminfo newForm = new frminfo();

            // Gán sự kiện khi form mới được đóng
            newForm.FormClosed += (s, args) =>
            {
                // Chỉ đóng form hiện tại
                this.Close();
            };

            // Hiển thị form mới
            newForm.Show();


        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            // Thực hiện hành động khi nhấp đúp vào NotifyIcon
            // Ví dụ: Mở form thông báo chi tiết
            MessageBox.Show("Thông báo chi tiết ở đây.");
        }

        private void notifyIcon1_BalloonTipShown(object sender, EventArgs e)
        {

        }

        int ID_phien = 0;

        //THAY ĐỔI NỘI DUNG Ở PHẦN NGÂN HÀNG CÂU HỎI
        private void dgvdiemdanhsv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvdiemdanhsv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvdiemdanhsv.Rows.Count)
            {
                // PHIÊN ĐIỂM DANH
                if (grbdiemdanh.Text == "Phiên điểm danh")
                {
                    // Kiểm tra nếu cột chứa ID_phien không phải là DBNull
                    if (dgvdiemdanhsv.Rows[e.RowIndex].Cells[0].Value != DBNull.Value)
                    {
                        // Lấy ID_phien từ DataGridView
                        int idPhien = Convert.ToInt32(dgvdiemdanhsv[0, e.RowIndex].Value);
                        txtmaphien.Text = idPhien.ToString();

                        // Kiểm tra trạng thái phiên
                        string checkSessionQuery = "SELECT TrangThai FROM PHIENDIEMDANH WHERE ID_phien = @ID_phien";
                        SqlParameter[] checkSessionParameters = new SqlParameter[]
                        {
                    new SqlParameter("@ID_phien", idPhien)
                        };

                        string sessionStatus = dbHelper.ExecuteScalar(checkSessionQuery, checkSessionParameters)?.ToString();

                        // Nếu phiên đã đóng, vô hiệu hóa nút xác nhận
                        if (sessionStatus == "Đóng")
                        {
                            btnxacnhan.Enabled = false; // Vô hiệu hóa nút xác nhận
                            MessageBox.Show("Phiên điểm danh đã bị đóng! Không thể xác nhận.");
                        }
                        else
                        {
                            btnxacnhan.Enabled = true; // Bật nút xác nhận nếu phiên mở
                        }

                        // Hiển thị thông tin lên các TextBox tương ứng
                        txttenlopsv.Text = dgvdiemdanhsv[3, e.RowIndex].Value.ToString();
                        txttenmonsv.Text = dgvdiemdanhsv[4, e.RowIndex].Value.ToString();
                        txtngaytaophien.Text = dgvdiemdanhsv[5, e.RowIndex].Value.ToString();
                        txtsolan.Text = dgvdiemdanhsv[8, e.RowIndex].Value.ToString();
                        txttrangthai.Text = dgvdiemdanhsv[9, e.RowIndex].Value.ToString();
                    }
                }
                // DANH SÁCH MÔN THI
                else if (grbdiemdanh.Text == "Danh sách môn thi")
                {
                    // Hiển thị thông tin môn thi lên các TextBox
                    txtmaphien.Text = dgvdiemdanhsv[0, e.RowIndex].Value.ToString();
                    txttenlopsv.Text = dgvdiemdanhsv[1, e.RowIndex].Value.ToString();
                    txttenmonsv.Text = dgvdiemdanhsv[2, e.RowIndex].Value.ToString();
                    txtngaytaophien.Text = dgvdiemdanhsv[3, e.RowIndex].Value.ToString();

                    // Kích hoạt nút làm bài
                    btnlambai.Enabled = true;
                }
            }
        }


        private void picsphanhoi_Click(object sender, EventArgs e)
        {
            // Kiểm tra giá trị của thongtinsv.MSV
            if (string.IsNullOrWhiteSpace(thongtinsv.MSV))
            {
                MessageBox.Show("Không tìm thấy Mã sinh viên! Vui lòng kiểm tra lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Ghi log hoặc hiển thị giá trị của thongtinsv.MSV
            Console.WriteLine($"Mã SV: {thongtinsv.MSV}");

            // Hiển thị panel và ẩn nút gửi phản hồi
            panel5.Visible = true;
            btngui_phanhoi.Visible = false;

            // Load dữ liệu
            grbphanhoisv_dgv.Text = "Danh sách phản hồi";

            // Tạo câu lệnh SQL với tham số @MaSV
            string sql = @"SELECT ph.ID_phanhoi AS [ID], sv.MaSV AS [Mã SV], sv.Hodem AS [Họ đệm], sv.Ten AS [Tên], 
                   l.TenL AS [Tên lớp], mh.Tenmonhoc AS [Tên môn học], ph.Noidung AS [Nội dung], ph.Ngaytao AS [Ngày tạo], 
                   ph.[Trangthai] AS [Trạng thái]
                   FROM PHANHOI ph
                   JOIN SV sv ON ph.MaSV = sv.MaSV
                   JOIN LOPSV lsv ON lsv.MaSV = sv.MaSV
                   JOIN LOP l ON l.MaL = lsv.MaL
                   JOIN MONHOC mh ON mh.MaL = l.MaL
                   WHERE sv.MaSV = @MaSV
                   ORDER BY ph.ID_phanhoi";

            // Sử dụng SqlParameter để truyền @MaSV vào câu lệnh SQL
            SqlParameter[] parameters = new SqlParameter[]
            {
        new SqlParameter("@MaSV", thongtinsv.MSV)
            };

            // Gọi phương thức LoadDuLieuforsv với tham số SQL và DataGridView
            dbHelper.LoadDuLieuforsv(sql, dgvphanhoisv, parameters);
            type = "Phanhoisv";

            // Làm mới dữ liệu
            RefreshDatasv_Click(sender, e);
        }



        int ID_phanhoi = 0;
        private void dgv_phanhoi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (grbphanhoisv_dgv.Text == "Danh sách phản hồi")
            {
                // Kiểm tra xem hàng được nhấp có hợp lệ hay không
                if (e.RowIndex >= 0 && e.RowIndex < dgvphanhoisv.Rows.Count)
                {
                    // Lấy ID_phien từ dòng đã chọn
                    if (dgvphanhoisv.Rows[e.RowIndex].Cells["ID"].Value != DBNull.Value)
                    {
                        ID_phanhoi = Convert.ToInt32(dgvphanhoisv.Rows[e.RowIndex].Cells["ID"].Value);
                    }

                    // Hiển thị nội dung từ các ô tương ứng
                    txtmssv_phanhoisv.Text = dgvphanhoisv[1, e.RowIndex].Value?.ToString() ?? "";  // MSSV
                    txthodem_phanhoisv.Text = dgvphanhoisv[2, e.RowIndex].Value?.ToString() ?? "";  // Họ đệm
                    txtten_phanhoisv.Text = dgvphanhoisv[3, e.RowIndex].Value?.ToString() ?? "";   // Tên
                    txtlop_phanhoisv.Text = dgvphanhoisv[4, e.RowIndex].Value?.ToString() ?? "";   // Lớp
                    txtmon_phanhoisv.Text = dgvphanhoisv[5, e.RowIndex].Value?.ToString() ?? "";  // Môn
                    txtnoidung_phanhoisv.Text = dgvphanhoisv[6, e.RowIndex].Value?.ToString() ?? ""; // Nội dung
                    txtngay_phanhoisv.Text = dgvphanhoisv[7, e.RowIndex].Value?.ToString() ?? ""; // Ngày


                }
            }
        }


        //NÚT PHẦN PHẢN HỒI

        private bool isThemMode = false;

        // NÚT THÊM
        private void btnthem_phanhoi_Click(object sender, EventArgs e)
        {

            lblhodem_phanhoi.Text = "Nội dung phản hồi:";

            btngui_phanhoi.Visible = true;

            if (dgvphanhoisv.Rows.Count > 0)
            {
                dgvphanhoisv.CurrentCell = dgvphanhoisv[0, dgvphanhoisv.RowCount - 1];
                txtmssv_phanhoisv.Focus();
                txthodem_phanhoisv.Focus();
            }
            else
            {
                MessageBox.Show("Không có dữ liệu để thêm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Hoặc thực hiện xử lý khác tùy thuộc vào logic ứng dụng của bạn.
            }
            btnhuy_phanhoi.Enabled = true;
            btngui_phanhoi.Enabled = true;
            txtnoidunggui_phanhoi.Visible = true;

            lblmssv_phahoi.Visible = false;
            lblten_phanhoi.Visible = false;
            lbllop_phanhoi.Visible = false;
            lblngay_phanhoi.Visible = false;
            lblnoidung_phanhoi.Visible = false;

            txtmssv_phanhoisv.Visible = false;
            txthodem_phanhoisv.Visible = false;
            txtten_phanhoisv.Visible = false;
            txtlop_phanhoisv.Visible = false;
            txtngay_phanhoisv.Visible = false;
            txtnoidung_phanhoisv.Visible = false;

            Chitiet(true);
            Lamsach();
            //RefreshData_Click(sender, e);
            isThemMode = true; // Kích hoạt chế độ Thêm
        }



        // NÚT HUỶ
        private void btnhuy_phanhoi_Click(object sender, EventArgs e)
        {

            lblhodem_phanhoi.Text = "Họ đệm:";
            lblmssv_phahoi.Visible = true;
            lblten_phanhoi.Visible = true;
            lbllop_phanhoi.Visible = true;
            lblngay_phanhoi.Visible = true;
            lblnoidung_phanhoi.Visible = true;

            txtmssv_phanhoisv.Visible = true;
            txthodem_phanhoisv.Visible = true;
            txtten_phanhoisv.Visible = true;
            txtlop_phanhoisv.Visible = true;
            txtngay_phanhoisv.Visible = true;
            txtnoidung_phanhoisv.Visible = true;

            txtnoidunggui_phanhoi.Visible = false;
            btngui_phanhoi.Visible = false;
            btngui_phanhoi.Enabled = false;
            btnhuy_phanhoi.Enabled = false;
            Chitiet(false);
            btnthem_phanhoi.Enabled = true;
            // Sau khi lưu dữ liệu thành công
            isThemMode = false; // Tắt chế độ Thêm
        }


        // NÚT LƯU
        private void btngui_phanhoi_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu đang ở chế độ thêm mới
            if (btnthem_phanhoi.Enabled == true)
            {
                try
                {
                    // Kiểm tra thông tin phản hồi
                    if (string.IsNullOrWhiteSpace(txtnoidunggui_phanhoi.Text))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi gửi!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Kiểm tra giá trị của thongtinsv.MSV
                    if (string.IsNullOrWhiteSpace(thongtinsv.MSV))
                    {
                        MessageBox.Show("Không tìm thấy Mã sinh viên! Vui lòng kiểm tra lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Tạo câu lệnh SQL
                    string sql = "INSERT INTO PHANHOI (MaSV, Noidung) VALUES (@MaSV, @Noidung)";
                    SqlParameter[] parameters = new SqlParameter[]
                    {
                new SqlParameter("@MaSV", thongtinsv.MSV),
                new SqlParameter("@Noidung", txtnoidunggui_phanhoi.Text)
                    };

                    // Gọi phương thức thực thi
                    dbHelper.ExecuteNonQuery(sql, parameters);

                    // Thông báo thành công
                    MessageBox.Show("Thêm mới thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Gọi lại phương thức picsphanhoi_Click để làm mới dữ liệu
                    picsphanhoi_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



        private string type;
        private void RefreshDatasv_Click(object sender, EventArgs e)
        {

            var refresh = new Refreshsv(type, dbHelper);
            refresh.ExecuteRefreshsv(dgvdiemdanhsv, dgvphanhoisv, type,
            txtmaphien,
            txttenlopsv,
            txttenmonsv,
            txtngaytaophien,
            txtsolan,
            txttrangthai,

            txtmssv_phanhoisv,
            txthodem_phanhoisv,
            txtten_phanhoisv,
            txtlop_phanhoisv,
            txtmon_phanhoisv,
            txtngay_phanhoisv,
            txtnoidung_phanhoisv);

        }


        // NÚT PHẦN BÁO CÁO

        private void picbangdiemsv_Click(object sender, EventArgs e)
        {
            lblngaytimkiembaocao_sv.Visible = false;
            dpttimkiembaocao_sv.Visible = false;
            try
            {
                // Kiểm tra giá trị của thongtinsv.MSV
                if (string.IsNullOrWhiteSpace(thongtinsv.MSV))
                {
                    MessageBox.Show("Không tìm thấy Mã sinh viên! Vui lòng kiểm tra lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                grbtim.Text = "Bảng điểm";
                // Tạo câu lệnh SQL với điều kiện WHERE
                string sql = @"
            SELECT 
                KETQUA.MaSV AS 'Mã SV', 
                SV.Hodem AS 'Họ đệm', 
                SV.Ten AS 'Tên', 
                LOP.TenL AS 'Tên Lớp', 
                MONTHI.Tenmon AS 'Tên Môn', 
                AVG(KETQUA.Diem) AS 'Điểm Trung Bình', 
                COUNT(KETQUA.LanThi) AS 'Số Lần Thi' 
            FROM 
                KETQUA 
            INNER JOIN 
                SV ON KETQUA.MaSV = SV.MaSV 
            INNER JOIN 
                LOPSV ON KETQUA.MaSV = LOPSV.MaSV 
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL 
            INNER JOIN 
                MONTHI ON KETQUA.MaM = MONTHI.MaM 
            WHERE 
                KETQUA.MaSV = @MaSV
            GROUP BY 
                KETQUA.MaSV, SV.Hodem, SV.Ten, LOP.TenL, MONTHI.Tenmon;";

                // Sử dụng SqlParameter để truyền @MaSV vào câu lệnh SQL
                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@MaSV", thongtinsv.MSV)
                };

                // Thực thi truy vấn và lấy dữ liệu
                DataTable dt = dbHelper.ExecuteQuery(sql, parameters);
                dgvbc_sv.DataSource = dt;

                // Định vị lại thứ tự hiển thị cột
                dgvbc_sv.Columns["Tên"].DisplayIndex = 2;
                dgvbc_sv.Columns["Tên Môn"].DisplayIndex = 3;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }

        private void picbaithisv_Click(object sender, EventArgs e)
        {
            lblngaytimkiembaocao_sv.Visible = true;
            dpttimkiembaocao_sv.Visible = true;
            try
            {
                grbtim.Text = "Bài làm";

                // Kiểm tra giá trị của thongtinsv.MSV
                if (string.IsNullOrWhiteSpace(thongtinsv.MSV))
                {
                    MessageBox.Show("Không tìm thấy Mã sinh viên! Vui lòng kiểm tra lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string sql = @"
            SELECT DISTINCT 
                SV.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                MONTHI.Tenmon AS 'Tên môn', 
                KETQUA.SoCauDung AS 'Số câu đúng', 
                KETQUA.SoCauSai AS 'Số câu sai', 
                KETQUA.SoCauKhongLam AS 'Số câu không làm', 
                KETQUA.Diem AS 'Điểm', 
                KETQUA.Lanthi AS 'Lần thi', 
                BAILAM.NgayThi AS 'Ngày thi' 
            FROM 
                KETQUA 
            INNER JOIN 
                SV ON KETQUA.MaSV = SV.MaSV 
            INNER JOIN 
                LOPSV ON SV.MaSV = LOPSV.MaSV 
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL 
            INNER JOIN 
                CAUHOI ON KETQUA.MaM = CAUHOI.MaM 
            INNER JOIN 
                MONTHI ON CAUHOI.MaM = MONTHI.MaM 
            INNER JOIN 
                BAILAM ON KETQUA.MaSV = BAILAM.MaSV 
            WHERE 
                KETQUA.MaSV = @MaSV;"; // Thêm điều kiện WHERE

                // Sử dụng SqlParameter để truyền @MaSV vào câu lệnh SQL
                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@MaSV", thongtinsv.MSV)
                };

                // Thực thi truy vấn và lấy dữ liệu
                DataTable dt = dbHelper.ExecuteQuery(sql, parameters);
                dgvbc_sv.DataSource = dt;

                // Định dạng cột "Ngày thi" để hiển thị ngày và giờ
                dgvbc_sv.Columns["Ngày thi"].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm"; // Định dạng theo ngày/tháng/năm giờ:phút
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }

        private void picsbaocaodiemdanhsv_Click(object sender, EventArgs e)
        {
            lblngaytimkiembaocao_sv.Visible = true;
            dpttimkiembaocao_sv.Visible = true;
            try
            {
                // Thiết lập tên nút
                grbtim.Text = "Báo cáo điểm danh";

                // Kiểm tra giá trị của thongtinsv.MSV
                if (string.IsNullOrWhiteSpace(thongtinsv.MSV))
                {
                    MessageBox.Show("Không tìm thấy Mã sinh viên! Vui lòng kiểm tra lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Truy vấn SQL để lấy thông tin điểm danh
                string sql = @"
            SELECT 
                PHIENDIEMDANH.ID_phien AS 'ID Phiên', 
                DIEMDANH.MaSV AS 'Mã SV', 
                SV.Hodem + ' ' + SV.Ten AS 'Họ Tên', 
                LOP.TenL AS 'Tên lớp', 
                DIEMDANH.Thoigian_xacnhan AS 'Ngày xác nhận', 
                PHIENDIEMDANH.SoLan AS 'Lần',
                DIEMDANH.Trangthai AS 'Trạng thái'
            FROM 
                DIEMDANH
            INNER JOIN 
                PHIENDIEMDANH ON DIEMDANH.ID_phien = PHIENDIEMDANH.ID_phien
            INNER JOIN 
                SV ON DIEMDANH.MaSV = SV.MaSV
            INNER JOIN 
                LOPSV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN 
                LOP ON LOPSV.MaL = LOP.MaL
            WHERE 
                DIEMDANH.MaSV = @MaSV
            ORDER BY 
                PHIENDIEMDANH.SoLan, DIEMDANH.Thoigian_xacnhan;"; // Thêm điều kiện WHERE

                // Sử dụng SqlParameter để truyền @MaSV vào câu lệnh SQL
                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@MaSV", thongtinsv.MSV)
                };

                // Thực thi truy vấn và lấy dữ liệu
                DataTable dt = dbHelper.ExecuteQuery(sql, parameters);

                // Gán DataTable cho DataGridView hoặc xử lý theo nhu cầu
                dgvbc_sv.DataSource = dt; // Giả sử bạn có DataGridView tên dgvData
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message);
            }
        }



        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // đóng form này
            Form f = new frmlogin(); // mở lại form đăng nhập
            f.ShowDialog();
        }

        private void btnexit2_Click(object sender, EventArgs e)
        {
            this.Close(); // đóng form này
            Form f = new frmlogin(); // mở lại form đăng nhập
            f.ShowDialog();
        }

        private void thoátChươngTrìnhToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close(); // đóng form này
            Form f = new frmlogin(); // mở lại form đăng nhập
            f.ShowDialog();
        }


        private void btnbclop_Click(object sender, EventArgs e)
        {
            try
            {
                rptlop rpt = new rptlop();
                string query = @"
            SELECT DISTINCT 
                LOP.MaL, 
                LOP.TenL, 
                SV.MaSV, 
                SV.Hodem, 
                SV.Ten, 
                KETQUA.Diem, 
                KETQUA.Lanthi
            FROM LOP
            INNER JOIN LOPSV ON LOPSV.MaL = LOP.MaL
            INNER JOIN SV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN KETQUA ON KETQUA.MaSV = SV.MaSV
            WHERE LOP.TenL = @TenLop
            AND SV.MaSV = @MaSV";

                // Lấy thông tin MaSV từ struct thongtinsv
                string maSV = thongtinsv.MSV;

                // Sử dụng cả TenLop từ textbox và MaSV từ struct trong truy vấn
                DataTable datarpt = dbHelper.ExecuteQuery(
                    query,
                    new SqlParameter[]
                    {
                new SqlParameter("@TenLop", txtMalopsv.Text),
                new SqlParameter("@MaSV", maSV)
                    }
                );

                rpt.SetDataSource(datarpt);

                rptlopprv rp = new rptlopprv(rpt);
                rp.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }




        private void btnbcmon_Click(object sender, EventArgs e)
        {
            try
            {
                rptmon rpt = new rptmon();
                string query = @"
            SELECT DISTINCT 
                MONTHI.MaM, 
                MONTHI.Tenmon, 
                SV.MaSV, 
                SV.Hodem, 
                SV.Ten, 
                KETQUA.Diem, 
                KETQUA.Lanthi
            FROM MONTHI
            INNER JOIN LOP ON LOP.MaM = MONTHI.MaM
            INNER JOIN LOPSV ON LOPSV.MaL = LOP.MaL
            INNER JOIN SV ON SV.MaSV = LOPSV.MaSV
            INNER JOIN KETQUA ON KETQUA.MaSV = SV.MaSV
            WHERE MONTHI.Tenmon = @TenMon
            AND SV.MaSV = @MaSV";

                // Lấy thông tin MaSV từ struct thongtinsv
                string maSV = thongtinsv.MSV;

                // Sử dụng cả TenMon từ combobox và MaSV từ struct trong truy vấn
                DataTable datarpt = dbHelper.ExecuteQuery(
                    query,
                    new SqlParameter[]
                    {
                new SqlParameter("@TenMon", cmbtenmonsv.Text),
                new SqlParameter("@MaSV", maSV)
                    }
                );

                rpt.SetDataSource(datarpt);

                rptmonprv rp = new rptmonprv(rpt);
                rp.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thực hiện truy vấn: {ex.Message}");
            }
        }



        //NÚT TÌM KIẾM TAB QUẢN LÝ SV
        private void txttimsv_TextChanged(object sender, EventArgs e)
        {
            Filtersv filter = new Filtersv(dbHelper);
            string searchText = txttimsv.Text;
            string loai = grbdiemdanh.Text;

            filter.TimKiemTheoLoaisv(searchText, loai, dgvdiemdanhsv);
        }

        private void cmblocsv_SelectedIndexChanged(object sender, EventArgs e)
        {
            Filtersv filter = new Filtersv(dbHelper);
            string tenMonsv = cmblocsv.Text;

            filter.TimKiemTheoMonHocsv(tenMonsv, dgvdiemdanhsv);

        }


        //NÚT TÌM KIẾM BÁO CÁO
        private void cmbtenmonsv_TextChanged(object sender, EventArgs e)
        {
            Filter filter = new Filter(dbHelper);
            string loaiTimKiem = grbtim.Text; // Giả định có thuộc tính để lấy loại tìm kiếm
            string tenMon = cmbtenmonsv.Text;

            // Gọi phương thức tìm kiếm
            filter.TimKiemTenMonBaoCao(tenMon, loaiTimKiem, dgvbc_sv);

        }

        private void txtMalopsv_TextChanged(object sender, EventArgs e)
        {
            Filtersv filter = new Filtersv(dbHelper);
            string loaiTimKiem = grbtim.Text; // Giả định có thuộc tính để lấy loại tìm kiếm
            string tenLopsv = txtMalopsv.Text;

            // Gọi phương thức tìm kiếm
            filter.TimKiemTenLopBaoCaosv(tenLopsv, loaiTimKiem, dgvbc_sv);

        }

        private void dpttimkiembaocaosv_ValueChanged(object sender, EventArgs e)
        {
            Filtersv filter = new Filtersv(dbHelper);
            string ngayBaoCao_sv = dpttimkiembaocao_sv.Value.ToString("yyyy-MM-dd"); // Định dạng ngày nếu cần
            string loaiTimKiem = grbtim.Text; // Giả định có thuộc tính để lấy loại tìm kiếm


            // Gọi phương thức TimKiemNgayBaoCao
            filter.TimKiemNgayBaoCaosv(ngayBaoCao_sv, loaiTimKiem, dgvbc_sv); // dgvbc là DataGridView bạn muốn gán dữ liệu
        }


        //TÌM KIẾM PHẢN HỒI
        private void txttimkiemmon_phanhoisv_SelectedIndexChanged(object sender, EventArgs e)
        {
            Filtersv filter = new Filtersv(dbHelper);
            filter.TimKiemLopPhanHoisv(txttimkiemlop_phanhoisv, dgvphanhoisv);
        }

        private void txttimkiemlop_phanhoisv_TextChanged(object sender, EventArgs e)
        {
            Filtersv filter = new Filtersv(dbHelper);
            filter.TimKiemMonPhanHoisv(txttimkiemmon_phanhoisv, dgvphanhoisv);
        }
        private void dtptimkiem_phanhoisv_ValueChanged(object sender, EventArgs e)
        {
            Filtersv filter = new Filtersv(dbHelper);
            filter.TimKiemNgayPhanHoisv(dtptimkiem_phanhoisv, dgvphanhoisv);
        }

        // CÁC NÚT Ở PHẦN TRỢ GIÚP
        private void linktimch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Tìm kiếm câu hỏi" + Environment.NewLine + "1.Nhập thông tin tìm kiếm (mã câu hỏi hoặc mã môn) vào ô tìm kiếm " + Environment.NewLine + "2.Thông tin sẽ hiện ra bảng danh sách câu hỏi ở bên dưới" + Environment.NewLine + "3.Chọn tên môn thi tương ứng để lọc các câu hỏi theo từng môn";
        }

        private void linkthemch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Thêm câu hỏi " + Environment.NewLine + "1.Nhấp chuột vào Thêm " + Environment.NewLine + "2.nhập thông tin vào các ô tương ứng " + Environment.NewLine + "3.sau khi nhập đầy đủ thông tin thì nhấp chuột vào Lưu";
        }

        private void linksuach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Sửa câu hỏi " + Environment.NewLine + "1.nhấp vào câu hỏi cần sửa " + Environment.NewLine + "2.thông tin câu hỏi sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Sửa " + Environment.NewLine + "4.sửa thông tin cần thay đổi" + Environment.NewLine + "5.sau khi sửa xong nhấp vào Lưu";

        }

        private void linkxoach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xóa câu hỏi" + Environment.NewLine + "1.nhấp vào câu hỏi cần xóa " + Environment.NewLine + " 2.thông tin câu hỏi sẽ hiện vào ô tương ứng" + Environment.NewLine + " 3.nhấp vào Xóa ";

        }

        private void linktimmt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Tìm kiếm môn thi" + Environment.NewLine + "1.Nhập thông tin tìm kiếm (mã môn hoặc tên môn) vào ô tìm kiếm " + Environment.NewLine + " 2.Thông tin sẽ hiện ra bảng danh sách Môn thi ở bên dưới";

        }

        private void linkthemmt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Thêm môn thi" + Environment.NewLine + "1.Nhấp chuột vào Thêm " + Environment.NewLine + " 2.nhập thông tin vào các ô tương ứng" + Environment.NewLine + " 3.sau khi nhập đầy đủ thông tin thì nhấp chuột vào Lưu";

        }

        private void linksuamt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Sửa môn thi" + Environment.NewLine + "1.nhấp vào môn thi cần sửa" + Environment.NewLine + " 2.thông tin môn thi sẽ hiện vào ô tương ứng" + Environment.NewLine + " 3.nhấp vào Sửa " + Environment.NewLine + "4.sửa thông tin cần thay đổi" + Environment.NewLine + " 5.sau khi sửa xong nhấp vào Lưu";

        }

        private void linkxoamt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xóa môn thi" + Environment.NewLine + "1.nhấp vào môn thi cần xóa" + Environment.NewLine + " 2.thông tin môn thi sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Xóa";

        }

        private void linktimsv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Tìm kiếm sinh viên" + Environment.NewLine + "1.Nhập thông tin tìm kiếm (mã sinh viên hoặc tên sinh viên) vào ô tìm kiếm" + Environment.NewLine + " 2.Thông tin sẽ hiện ra bảng ";

        }

        private void linkthemsv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Thêm sinh viên" + Environment.NewLine + "1.Nhấp chuột vào Thêm" + Environment.NewLine + " 2.nhập thông tin vào các ô tương ứng" + Environment.NewLine + " 3.sau khi nhập đầy đủ thông tin thì nhấp chuột vào Lưu";

        }

        private void linksuasv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Sửa thông tin sinh viên" + Environment.NewLine + "1.nhấp vào sinh viên cần sửa" + Environment.NewLine + " 2.thông tin sinh viên sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Sửa" + Environment.NewLine + " 4.sửa thông tin cần thay đổi" + Environment.NewLine + "5.sau khi sửa xong nhấp vào Lưu";

        }

        private void linkxoasv_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "* Xóa thông tin sinh viên" + Environment.NewLine + "1.nhấp vào sinh viên cần xóa" + Environment.NewLine + " 2.thông tin sinh viên sẽ hiện vào ô tương ứng" + Environment.NewLine + "3.nhấp vào Xóa ";

        }

        private void label12_Click(object sender, EventArgs e)
        {
            lbltrogiup.Text = "*Xem bảng điểm " + Environment.NewLine + "1.Nhập tên lớp cần xem bảng điểm." + Environment.NewLine + "2.Chọn tên môn học." + Environment.NewLine + "3.Nhập vào MSV nếu cần xem điểm của 1 sinh viên." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bảng điểm đã chọn.";

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xem bảng điểm " + Environment.NewLine + "1.Nhập tên lớp cần xem bảng điểm." + Environment.NewLine + "2.Chọn tên môn học." + Environment.NewLine + "3.Nhập vào MSV nếu cần xem điểm của 1 sinh viên." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bảng điểm đã chọn.";

        }

        private void label13_Click(object sender, EventArgs e)
        {
            lbltrogiup.Text = "*Xem bài thi " + Environment.NewLine + "1.Nhập MSV." + Environment.NewLine + "2.Chọn tên môn." + Environment.NewLine + "3.Chọn ngày thi." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bài thi của sinh viên đó.";

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lbltrogiup.Text = "*Xem bài thi " + Environment.NewLine + "1.Nhập MSV." + Environment.NewLine + "2.Chọn tên môn." + Environment.NewLine + "3.Chọn ngày thi." + Environment.NewLine + "4.Nhấn nút In nếu muốn in ra bài thi của sinh viên đó.";

        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////

        private void txtmach_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbmon_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbtenmon_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbltrogiup_Click(object sender, EventArgs e)
        {

        }

        private void tabtrogiup_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void dgvbc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void grbtim_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panelcauhoi_Paint(object sender, PaintEventArgs e)
        {

        }

        private void grbchitietch_Enter(object sender, EventArgs e)
        {

        }

        private void lblmonthi_Click(object sender, EventArgs e)
        {

        }

        private void txttenmon_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnoidung_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtthoigian_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbdapan_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbldapan_Click(object sender, EventArgs e)
        {

        }

        private void lbltgthi_Click(object sender, EventArgs e)
        {

        }

        private void lblthoigian_Click(object sender, EventArgs e)
        {

        }

        private void txtsocau_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblsocau_Click(object sender, EventArgs e)
        {

        }

        private void lblnoidungch_Click(object sender, EventArgs e)
        {

        }

        private void lbltenmon_Click(object sender, EventArgs e)
        {

        }

        private void txtmamon_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblmach_Click(object sender, EventArgs e)
        {

        }

        private void lblmamon_Click(object sender, EventArgs e)
        {

        }

        private void grbcauhoi_Enter(object sender, EventArgs e)
        {

        }

        private void lblloc_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tHITRACNGHIEMDataSetBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void mONTHIBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxChuong_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabphanhoi_Click(object sender, EventArgs e)
        {

        }

        private void grbphanhoidgv_Enter(object sender, EventArgs e)
        {

        }

        private void rjButton1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void tabquanly_Click(object sender, EventArgs e)
        {

        }

        private void grbtimch_Enter(object sender, EventArgs e)
        {

        }

        private void cmbtenmon_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnxoa_Click(object sender, EventArgs e)
        {

        }


        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void tabbaocao_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

    }

}
